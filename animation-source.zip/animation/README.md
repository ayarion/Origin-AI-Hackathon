# TO:ME hamster (Rive)

The user-provided gray-hamster reference is redrawn from behind as editable vector parts in `hamster/scene.rml`: a continuous curved gray silhouette, subtle dorsal stripe, white bobtail, folded ears and pink gripping paws. No face or belly is shown. This is an interpretation, not a cropped bitmap of the character sheet.

Built using official Rive CLI 1.1.1. `Hang` is a 3-second eased loop: fixed paw anchors, weighted torso sway, a brief asymmetric struggle and a quieter recovery. Ears, tail and feet lag the torso; restrained squash/stretch adds weight. `Delivery` receives `drop` and enters the one-shot `Fall` timeline (0.8 seconds): a short anticipation, releasing arms and accelerating descent. The legacy trigger is used for compatibility with the pinned RiveViewModel API in RiveRuntime 6.27.0; no scripts, hosted assets, or CDN requests are used.

Commands (use an installed official `rive` CLI):

```sh
rive animation/hamster --verify
rive inspect animation/hamster --summary
rive animation/hamster --once
rive animation/hamster --screenshot=/tmp/hamster.png --advance=20
cp animation/hamster/build/hamster.riv ios/MorningReceipt/hamster.riv
```

The shipping SwiftUI wrapper only tracks the moving paper edge and fires `drop`; limb motion and falling are actually in the `.riv` file. The artboard is taller than the visible character to provide space for the fall. The background is transparent.
