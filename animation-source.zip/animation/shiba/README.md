# 柴犬・ペイント調 Rive アニメーション

参考画像の毛並み、茶色と白の配色、赤い首輪、顔と身体の比率を重視した5種類のアニメーションです。参考シートからimagegenで透過素材を作成し、Riveの画像メッシュにボーンをバインドしています。元画像そのもののピクセルを切り抜いた素材ではありません。

| Artboard | 動き | 周期 |
|---|---|---|
| 01 Idle - breathe | 待機・呼吸・小さな耳の動き | 4秒 |
| 02 Happy - tail wag | 喜ぶ・しっぽ振り | 3秒 |
| 03 Run - gallop | 走る・小さな脚の屈伸と上下動 | 0.8秒 |
| 04 Jump - soft landing | ジャンプ・着地 | 2.5秒 |
| 05 Sleep - breathing | 眠る・ゆっくりした呼吸 | 5秒 |

各アートボードは46本のボーン、2,401頂点、4,608三角形。頂点あたり最大4本のボーンの影響を使用します。顔の中央はほぼ剛体、脚としっぽの付け根は重みをぼかして絵の伸びや境目を抑えています。動きは絵の形を優先した控えめなループです。背景は透過です。

## ファイル

- `build/shiba-painted-animation.rev`: Riveエディタに読み込める編集用ファイル。
- `build/shiba-painted-animation.riv`: Riveランタイムで使用するファイル。現在のアカウントの書き出しではRiveの透かしが付きます。
- `scene.rml`: 編集可能なRiveソース。
- `assets/`: 透過PNGテクスチャ3点。
- `build_scene.py`: ボーン・メッシュ・タイムラインを再生成するスクリプト。

## Riveで見る

アートボードを選択し、Animateに切り替えて同名のアニメーションを再生します。各アートボードの既定ステートマシンでもループ再生できます。

## 再生成

```sh
python3 build_scene.py
~/.rive/bin/rive . --verify
~/.rive/bin/rive . --publish --rev=build/shiba-painted-animation.rev
```

生成スクリプトを再実行すると`scene.rml`を再生成します。Rive上で加えた手修正を自動で取り込む処理はありません。既存のRiveファイルへの保存先は`rive.yaml`に保持されます。
