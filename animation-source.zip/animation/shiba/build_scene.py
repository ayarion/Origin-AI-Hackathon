"""Build native Rive image meshes. Source texture pixels are never rewritten."""
from pathlib import Path
import math, base64, json
import xml.etree.ElementTree as E

HERE=Path(__file__).parent
counter=100
def ident():
    global counter
    counter+=1
    return f'0:{counter}'
def add(p,t,**a):
    return E.SubElement(p,t,{k:str(v) for k,v in a.items()})
def named(p,t,name,**a):
    return add(p,t,name=name,id=ident(),**a)
def varints(nums):
    out=bytearray()
    for n in nums:
        while n>=128: out.append((n&127)|128); n>>=7
        out.append(n)
    return base64.b64encode(out).decode()

# Coordinates are in a 1000 x 1000 normalized texture space.
STAND={
 'spine':[(350,600),(430,580),(515,580),(600,590),(690,610),(780,650)],
 'neck':[(355,555),(350,520),(340,480),(335,435)],
 'head':[(335,425),(345,260)],
 'ear_L':[(155,200),(145,155),(140,110),(135,65)],
 'ear_R':[(435,155),(443,115),(446,75),(448,42)],
 'tail':[(810,465),(865,422),(889,365),(889,300),(865,245),(820,220),(770,233),(735,268),(741,309),(780,336)],
 'front_far':[(212,570),(228,675),(246,775),(241,865),(236,934)],
 'front_near':[(464,592),(435,710),(402,821),(382,906),(364,966)],
 'hind_far':[(600,680),(580,738),(567,790),(550,845),(530,885)],
 'hind_near':[(765,613),(808,710),(849,795),(877,858),(875,916)],
 'chest':[(305,565),(300,630),(310,699),(330,760)],
 'muzzle':[(390,343),(405,383)],
 'tongue':[(403,348),(402,369),(400,390)],
}
RUN={
 'spine':[(385,505),(465,495),(555,490),(650,490),(730,520),(798,575)],
 'neck':[(372,503),(345,450),(318,400),(290,351)],
 'head':[(290,365),(235,267)],
 'ear_L':[(225,210),(222,170),(218,138),(215,112)],
 'ear_R':[(300,229),(295,191),(287,151),(279,113)],
 'tail':[(800,440),(844,384),(861,325),(856,264),(831,221),(790,211),(746,235),(719,269),(719,304),(748,323)],
 'front_far':[(310,575),(253,649),(188,699),(127,742),(81,773)],
 'front_near':[(435,566),(368,661),(293,740),(221,804),(177,861)],
 'hind_far':[(672,636),(719,701),(771,754),(798,805),(819,850)],
 'hind_near':[(777,549),(822,608),(877,661),(925,710),(950,765)],
 'chest':[(302,521),(291,561),(282,597),(277,632)],
 'muzzle':[(116,405),(144,446)],
 'tongue':[(114,442),(108,463),(101,484)],
}
SLEEP={
 'spine':[(430,526),(493,451),(569,399),(655,402),(733,450),(783,546)],
 'neck':[(450,604),(420,575),(390,550),(364,533)],
 'head':[(301,611),(301,557)],
 'ear_L':[(149,544),(148,507),(148,472),(148,436)],
 'ear_R':[(399,516),(400,485),(403,455),(407,421)],
 'tail':[(795,681),(844,701),(894,684),(931,640),(930,592),(898,554),(853,559),(815,594),(803,640),(815,679)],
 'front_far':[(163,706),(149,735),(139,756),(130,767),(125,776)],
 'front_near':[(357,716),(350,745),(345,765),(335,783),(326,790)],
 'hind_far':[(625,700),(617,712),(608,723),(602,735),(596,744)],
 'hind_near':[(787,578),(756,617),(717,657),(679,687),(643,714)],
 'chest':[(420,633),(445,675),(460,713),(466,751)],
 'muzzle':[(301,649),(302,687)],
 'tongue':[(306,665),(306,673),(306,680)],
}

def region(x,y,pose):
    if pose=='stand':
        if x>665 and y<467: return 'tail'
        if y<210 and x<245: return 'ear_L'
        if y<167 and x>355 and x<530:return 'ear_R'
        if y<480 and x<570:return 'head'
        if y>635:
            if x<310:return 'front_far'
            if x<490:return 'front_near'
            if x<640 and y>746:return 'hind_far'
            if x>700:return 'hind_near'
        if x<400 and y<750:return 'chest'
    elif pose=='run':
        if x>685 and y<448:return 'tail'
        if y<232 and x<252:return 'ear_L'
        if y<245 and x<342:return 'ear_R'
        if x<365 and y<500:return 'head'
        if y>590:
            if x<290 and y<800:return 'front_far'
            if x<460:return 'front_near'
            if x>810:return 'hind_near'
            if x>610 and y>683:return 'hind_far'
        if x<345:return 'chest'
    else:
        if x>758 and y>526:return 'tail'
        if x<220 and y<551:return 'ear_L'
        if x>350 and x<475 and y<530:return 'ear_R'
        if x<470 and y>520:
            if y>726 and x<227:return 'front_far'
            if y>743:return 'front_near'
            return 'head'
        if y>699 and x>530 and x<700:return 'hind_far'
    return 'spine'

def make_art(root,label,pose,clip,asset,index):
    chains={'stand':STAND,'run':RUN,'sleep':SLEEP}[pose]
    sy,oy=(2/3,166.6666667) if pose=='run' else (1,0)
    chains={g:[(x,y*sy+oy) for x,y in pts] for g,pts in chains.items()}
    w,h=1000,1100
    art=named(root,'Artboard',label,width=w,height=h,x=(index%3)*1150,y=(index//3)*1250)
    sty=named(art,'LayoutComponentStyle','Artboard style');art.set('styleId',sty.get('id'))
    rig=named(art,'Node','Character • artwork preserved',y=80)
    bones=[]
    for group,points in chains.items():
        parent=rig; previous_angle=0
        for j,(p,q) in enumerate(zip(points,points[1:])):
            angle=math.atan2(q[1]-p[1],q[0]-p[0]); length=math.dist(p,q)
            typ='RootBone' if j==0 else 'Bone'
            kwargs={'length':length,'rotation':angle-previous_angle}
            if j==0:kwargs.update(x=p[0],y=p[1])
            b=named(parent,typ,f'{group} {j+1:02}',**kwargs)
            bones.append(dict(id=b.get('id'),group=group,j=j,p=p,q=q,angle=angle,rotation=angle-previous_angle))
            previous_angle=angle;parent=b
    # 49 x 49 vertices allow local smooth deformation with 4 influences each.
    n=48
    boundary=[(i,0) for i in range(n+1)]+[(n,j) for j in range(1,n+1)]+[(i,n) for i in range(n-1,-1,-1)]+[(0,j) for j in range(n-1,0,-1)]
    points=boundary+[(i,j) for j in range(1,n) for i in range(1,n)]
    ids={p:i for i,p in enumerate(points)}
    tris=[]
    for j in range(n):
        for i in range(n):
            a,b,c,d=[ids[p] for p in [(i,j),(i+1,j),(i+1,j+1),(i,j+1)]]
            tris.extend([a,b,c,a,c,d])
    img=named(rig,'Image',f'{pose} original painted texture',assetId=asset,x=500,y=500)
    mesh=named(img,'Mesh','Fine deformation mesh',triangleIndexBytes=varints(tris))
    for k,(i,j) in enumerate(points):
        x,y=i/n*1000,j/n*1000
        membership={}
        for dx in [-60,-30,0,30,60]:
            for dy in [-60,-30,0,30,60]:
                g=region(x+dx,y+dy,pose)
                w=math.exp(-(dx*dx+dy*dy)/1800)
                membership[g]=membership.get(g,0)+w
        ms=sum(membership.values())
        membership={g:v/ms for g,v in membership.items()}
        y=y*sy+oy
        def distance(b):
            # Distance to segment, with cross-region influence strongly limited.
            p,q=b['p'],b['q']; dx=q[0]-p[0];dy=q[1]-p[1]
            t=max(0,min(1,((x-p[0])*dx+(y-p[1])*dy)/(dx*dx+dy*dy)))
            d=math.hypot(x-p[0]-dx*t,y-p[1]-dy*t)
            return d
        if membership.get('head',0)>.999:
            selected=[(k,b) for k,b in enumerate(bones) if b['group']=='head'];weights=[255]
        else:
            def influence(b):
                return (0.025+membership.get(b['group'],0))/(distance(b)**2+55**2)**1.5
            selected=sorted(enumerate(bones),key=lambda z:-influence(z[1]))[:4]
            raw=[influence(b) for _,b in selected];total=sum(raw)
            weights=[round(v/total*255) for v in raw];weights[0]+=255-sum(weights)
        vi=sum((k+1)<<(slot*8) for slot,(k,b) in enumerate(selected))
        va=sum(v<<(slot*8) for slot,v in enumerate(weights))
        v=add(mesh,'ContourMeshVertex' if k<len(boundary) else 'MeshVertex',x=x-500,y=y-500,u=i/n,v=j/n)
        add(v,'Weight',indices=vi,values=va)
    skin=named(mesh,'Skin','Four influences per vertex',tx=500,ty=580)
    for b in bones:
        c,s=math.cos(b['angle']),math.sin(b['angle'])
        add(skin,'Tendon',name=b['group']+str(b['j']),boneId=b['id'],xx=c,xy=s,yx=-s,yy=c,tx=b['p'][0],ty=b['p'][1]+80)
    duration={'Idle':240,'Happy':180,'Run':48,'Jump':150,'Sleep':300}[clip]
    anim=named(art,'LinearAnimation',clip,fps=60,duration=duration,loopValue='loop')
    def key(obj,prop,values,smooth=True):
        ko=add(anim,'KeyedObject',objectId=obj);kp=add(ko,'KeyedProperty',propertyKey=prop)
        for frame,value in values:
            f=add(kp,'KeyFrameDouble',frame=frame,value=value,interpolationType='cubic' if smooth else 'linear')
            if smooth:add(f,'CubicEaseInterpolator',x1=.42,y1=0,x2=.58,y2=1)
    if clip=='Jump':
        key(rig.get('id'),14,[(0,80),(22,90),(32,85),(54,-30),(67,-40),(90,80),(100,93),(117,80),(150,80)])
    elif clip=='Run':
        key(rig.get('id'),14,[(0,80),(12,65),(24,80),(36,65),(48,80)])
    else:
        key(rig.get('id'),14,[(0,80),(duration//2,78 if clip=='Sleep' else 77),(duration,80)])
    for b in bones:
        g,j=b['group'],b['j'];amp=0.; cycles=1;phase=0
        if clip=='Idle':
            amp={'spine':.005,'neck':.006,'head':.009,'tail':.012,'ear_L':.012,'ear_R':.010,'chest':.009,'tongue':.012}.get(g,.0015)
            phase=j*.3
        elif clip=='Happy':
            amp={'spine':.008,'neck':.009,'head':.018,'tail':.055,'ear_L':.019,'ear_R':.019,'chest':.01,'tongue':.03}.get(g,.002)
            cycles=4 if g=='tail' else 2; phase=j*.33
        elif clip=='Run':
            amp={'spine':.009,'neck':.014,'head':.018,'tail':.02,'ear_L':.018,'ear_R':.021,'chest':.012,'tongue':.018}.get(g,.015 if j else .045)
            phase=(math.pi if g in ['front_far','hind_near'] else 0)+j*.22
        elif clip=='Sleep':
            amp={'spine':.008,'neck':.003,'head':.002,'tail':.004,'ear_L':.007,'ear_R':.005,'chest':.014}.get(g,.0007)
            phase=j*.22
        else:
            amp={'spine':.008,'neck':.012,'head':.018,'tail':.02,'ear_L':.018,'ear_R':.018,'chest':.01}.get(g,.018 if j else .04)
            if g=='tail':amp=.012 if j==0 else 0
            if g=='spine':amp=.002 if j==0 else 0
            vals=[(0,0),(22,-.4),(32,0),(54,1),(67,1),(90,0),(100,-.5),(117,0),(150,0)]
            key(b['id'],15,[(f,b['rotation']+v*amp) for f,v in vals]);continue
        if g=='tail':
            amp=({'Idle':.025,'Happy':.10,'Run':.018,'Sleep':.009}[clip] if j==0 else 0)
            phase=0
        if g=='spine':amp=.004 if j==0 else 0
        count=min(duration,cycles*32)
        key(b['id'],15,[(round(duration*k/count),b['rotation']+amp*(math.sin(2*math.pi*cycles*k/count+phase)-math.sin(phase))) for k in range(count+1)],smooth=False)
    sm=named(art,'StateMachine',clip+' playback');art.set('defaultStateMachineId',sm.get('id'))
    layer=named(sm,'StateMachineLayer','Animation')
    add(layer,'AnyState',x=200,y=-140);add(layer,'ExitState',x=400,y=-140)
    en=add(layer,'EntryState',x=0,y=0);st=add(layer,'AnimationState',id=ident(),x=200,y=0,animationId=anim.get('id'))
    add(en,'StateTransition',stateToId=st.get('id'))
    return dict(artboard=label,clip=clip,bones=len(bones),vertices=len(points),triangles=len(tris)//3,durationSeconds=duration/60)

root=E.Element('Rive',version='1',kind='fragment')
assets={p:named(root,'ImageAsset',p+' texture',file='assets/'+f+'.png').get('id') for p,f in [('stand','standing'),('sleep','sleeping'),('run','running')]}
report=[]
for i,(label,pose,clip) in enumerate([('01 Idle - breathe','stand','Idle'),('02 Happy - tail wag','stand','Happy'),('03 Run - gallop','run','Run'),('04 Jump - soft landing','stand','Jump'),('05 Sleep - breathing','sleep','Sleep')]):
    report.append(make_art(root,label,pose,clip,assets[pose],i))
E.indent(root)
E.ElementTree(root).write(HERE/'scene.rml',encoding='utf-8',xml_declaration=True)
if not (HERE/'rive.yaml').exists():
    (HERE/'rive.yaml').write_text('name: shiba-painted-animation\nlogs:\n  file: build/rive.log\n  problems: build/problems.log\n')
(HERE/'rig-report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
