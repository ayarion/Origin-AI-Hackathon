import WidgetKit
import SwiftUI
import ActivityKit

struct ToMeEntry: TimelineEntry { let date: Date; let edition: NewspaperEdition? }
struct ToMeProvider: TimelineProvider {
    func placeholder(in context: Context) -> ToMeEntry { .init(date: .now, edition: .preview) }
    func getSnapshot(in context: Context, completion: @escaping (ToMeEntry) -> Void) { completion(.init(date: .now, edition: context.isPreview ? .preview : NewspaperBridge.read())) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<ToMeEntry>) -> Void) { completion(Timeline(entries: [.init(date: .now, edition: NewspaperBridge.read())], policy: .after(.now.addingTimeInterval(3600)))) }
}
struct ToMeWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: ToMeEntry
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("朝刊", systemImage: "newspaper").font(.headline).widgetAccentable()
            if let edition = entry.edition {
                Text(edition.day + " 朝刊").font(.subheadline).foregroundStyle(.secondary)
                Text(edition.headlines.first?.title ?? "朝刊を開く").font(.headline).lineLimit(3)
                if family != .systemSmall, let second = edition.headlines.dropFirst().first { Text(second.title).font(.subheadline).lineLimit(2) }
            } else { Text("アプリを開いて、あなたの朝刊を受け取ろう。").font(.headline) }
            Spacer(minLength: 0)
        }.containerBackground(for: .widget) { Color(uiColor: .secondarySystemBackground) }
            .widgetURL(URL(string: "tome://home"))
    }
}
struct MorningNewspaperWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: WidgetBridge.kind, provider: ToMeProvider()) { ToMeWidgetView(entry: $0) }
            .configurationDisplayName("TO:ME · あなたの朝刊").description("地域のニュースと暮らしの制度を、ホーム画面へ。表示日は朝刊の発行日です。")
            .supportedFamilies([.systemSmall, .systemMedium])
    }
}
private struct ToMeActivityIcon: View {
    let size: CGFloat
    var body: some View {
        Image("LiveActivityIcon")
            .resizable()
            .renderingMode(.original)
            .scaledToFill()
            .frame(width: size, height: size)
            .clipShape(RoundedRectangle(cornerRadius: size * 0.24))
            .accessibilityHidden(true)
    }
}
struct MorningLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: MorningPaperActivity.self) { context in
            ZStack {
                RoundedRectangle(cornerRadius: 28).fill(.white.opacity(0.86)).background(.ultraThinMaterial)
                LinearGradient(colors: [.white.opacity(0.55), Color(red: 0.10, green: 0.31, blue: 0.67).opacity(0.07)], startPoint: .topLeading, endPoint: .bottomTrailing)
                HStack(alignment: .top, spacing: 16) {
                    ToMeActivityIcon(size: 60).shadow(color: .blue.opacity(0.16), radius: 10, y: 5)
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("TO:ME").font(.headline.weight(.bold))
                            Spacer()
                            Text("新規 +\(context.state.count)件").font(.caption.weight(.semibold))
                        }.foregroundStyle(Color(red: 0.08, green: 0.23, blue: 0.50))
                        Text(context.state.headline).font(.headline).lineLimit(2)
                    }
                }.padding(18).foregroundStyle(Color(red: 0.12, green: 0.18, blue: 0.32))
            }
            .clipShape(RoundedRectangle(cornerRadius: 28))
            .overlay(RoundedRectangle(cornerRadius: 28).stroke(LinearGradient(colors: [.white.opacity(0.95), .white.opacity(0.15), .white.opacity(0.7)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1))
            .activityBackgroundTint(.clear)
            .activitySystemActionForegroundColor(.primary)
            .widgetURL(URL(string: "tome://home"))
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    HStack(spacing: 8) { ToMeActivityIcon(size: 28); Text("TO:ME").font(.headline) }
                }
                DynamicIslandExpandedRegion(.trailing) { Text("新規 +\(context.state.count)件").font(.subheadline) }
                DynamicIslandExpandedRegion(.bottom) { Text(context.state.headline).font(.headline).lineLimit(2).padding(.vertical, 8) }
            } compactLeading: { ToMeActivityIcon(size: 18) } compactTrailing: { Text("+\(context.state.count)件") } minimal: { ToMeActivityIcon(size: 18) }
                .widgetURL(URL(string: "tome://home"))
        }
    }
}
@main struct ToMeWidgets: WidgetBundle {
    var body: some Widget { MorningNewspaperWidget(); MorningLiveActivity() }
}
