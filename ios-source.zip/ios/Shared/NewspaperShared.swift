import Foundation
import ActivityKit

struct NewspaperHeadline: Codable, Hashable, Identifiable {
    var id: String
    var title: String
    var summary: String
    var source: String
    var url: URL
    var publishedAt: Date?
    var tags: [String]
    var reason: String
    var isGuide: Bool = false
    var imageURL: URL? = nil
    var support: SupportInsight? = nil
}

struct SupportInsight: Codable, Hashable {
    var benefit: String
    var check: String
    var action: String
    var documents: String
    var origin: String
}

struct NewspaperEdition: Codable, Equatable {
    var day: String
    var createdAt: Date
    var region: String
    var headlines: [NewspaperHeadline]
    var status: String
    var opened: Bool = false
    static let preview = NewspaperEdition(day: "プレビュー", createdAt: .now, region: "あなたの地域", headlines: [NewspaperHeadline(id: "preview", title: "まちの知らせと、暮らしのヒント。", summary: "地域・年齢層・関心から、あなたの朝刊を。", source: "表示イメージ", url: URL(string: "tome://home")!, tags: [], reason: "")], status: "表示イメージ")
}

enum NewspaperBridge {
    static let key = "tome.newspaper.edition.v1"
    static func read() -> NewspaperEdition? {
        guard let data = UserDefaults(suiteName: WidgetBridge.group)?.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(NewspaperEdition.self, from: data)
    }
    static func write(_ edition: NewspaperEdition?) {
        let defaults = UserDefaults(suiteName: WidgetBridge.group)
        if let edition, let data = try? JSONEncoder().encode(edition) { defaults?.set(data, forKey: key) }
        else { defaults?.removeObject(forKey: key) }
    }
}

struct MorningPaperActivity: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        var headline: String
        var secondHeadline: String
        var source: String
        var count: Int
        var editionDay: String

        init?(edition: NewspaperEdition) {
            guard let first = edition.headlines.first else { return nil }
            headline = String(first.title.prefix(100))
            secondHeadline = ""
            source = first.source
            count = edition.headlines.count
            editionDay = edition.day
        }
    }
    var editionID: String
}
