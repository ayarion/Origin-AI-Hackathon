import Foundation

struct WidgetDocument: Codable, Identifiable, Equatable {
    var id: UUID
    var title: String
    var action: String
    var deadline: String
    var sample: Bool
    var url: URL { URL(string: "tome://document/\(id.uuidString)")! }
}

struct WidgetSnapshot: Codable {
    var documents: [WidgetDocument]
    var updatedAt: Date
    static let empty = WidgetSnapshot(documents: [], updatedAt: .distantPast)
    static let preview = WidgetSnapshot(documents: [WidgetDocument(id: UUID(), title: "奨学金の申請", action: "在学証明書を用意する", deadline: "10/30〆", sample: true)], updatedAt: .now)
}

enum WidgetBridge {
    static let group = "group.com.demo.morningreceipt"
    static let key = "tome.widget.snapshot.v1"
    static let kind = "ToMeNextAction"
    static func read() -> WidgetSnapshot {
        guard let data = UserDefaults(suiteName: group)?.data(forKey: key),
              let value = try? JSONDecoder().decode(WidgetSnapshot.self, from: data) else { return .empty }
        return value
    }
    static func write(_ snapshot: WidgetSnapshot) {
        guard let data = try? JSONEncoder().encode(snapshot) else { return }
        UserDefaults(suiteName: group)?.set(data, forKey: key)
    }
}

enum ToMeRoute: Equatable {
    case home, capture, document(UUID)
    init?(url: URL) {
        guard url.scheme == "tome" else { return nil }
        switch url.host {
        case "home": self = .home
        case "capture": self = .capture
        case "document":
            guard let id = UUID(uuidString: url.lastPathComponent) else { return nil }
            self = .document(id)
        default: return nil
        }
    }
}
