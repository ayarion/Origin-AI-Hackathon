import XCTest
@testable import MorningReceipt

final class DocumentTests: XCTestCase {
    func testReceiptDeadlineFormatting() {
        XCTAssertEqual(ReceiptDeadline.compact("2026年10月2日"), "10/2〆")
        XCTAssertEqual(ReceiptDeadline.compact("2026/10/02"), "10/2〆")
        XCTAssertEqual(ReceiptDeadline.compact("１０月２日"), "10/2〆")
        XCTAssertEqual(ReceiptDeadline.compact(""), "")
        XCTAssertEqual(ReceiptDeadline.compact("未定"), "要確認")
    }
    func testConservativeExtraction() {
        let doc = DocumentExtractor.extract("給付のご案内\n発行日：2026年9月1日\n申請期限：２０２６年１０月３０日\n給付額：４８，０００円\n申請方法：窓口に提出")
        XCTAssertEqual(doc.deadlineText, "2026年10月30日")
        XCTAssertEqual(doc.amountText, "48,000円")
        XCTAssertEqual(doc.nextAction, "窓口に提出")
        let missing = DocumentExtractor.extract("お知らせ\n発行日：2026年9月1日")
        XCTAssertTrue(missing.deadlineText.isEmpty)
        XCTAssertTrue(missing.amountText.isEmpty)
    }
    func testAmbiguousValuesRequireReview() {
        let doc = DocumentExtractor.extract("申請期限：10月1日\n提出期限：10月3日\n給付額：100円\n金額：200円")
        XCTAssertTrue(doc.deadlineText.isEmpty)
        XCTAssertTrue(doc.amountText.isEmpty)
        XCTAssertEqual(doc.extractionNotes.count, 2)
    }
    func testDeadlineAndRequiredDocumentsAcrossLines() {
        let doc = DocumentExtractor.extract("給付金の申請案内\n提出締切\n2026/10/2 必着\n必要書類\n①本人確認書類\n②在学証明書\n申請方法\n窓口に提出")
        XCTAssertEqual(doc.deadlineText, "2026/10/2")
        XCTAssertEqual(doc.requiredDocuments, "本人確認書類、在学証明書")
    }
    @MainActor func testImageActuallyPassesThroughOCR() async throws {
        let text = try await DocumentOCR.recognize(SampleDocument.imageData())
        let doc = DocumentExtractor.extract(text)
        XCTAssertEqual(doc.deadlineText, "2026年10月30日")
        XCTAssertEqual(doc.amountText, "48,000円")
        XCTAssertTrue(text.contains("学生ポータル"))
        XCTAssertTrue(doc.requiredDocuments?.contains("在学証明書") == true)
    }
    @MainActor func testImportedDocumentDeduplicatesAndPersists() {
        let name = "capture.tests.\(UUID())"
        let defaults = UserDefaults(suiteName: name)!
        defer { defaults.removePersistentDomain(forName: name) }
        let store = ReceiptStore(defaults: defaults)
        store.openReceipt()
        let doc = DocumentExtractor.extract("給付のご案内\n給付額：100円")
        let id = store.importDocument(doc)
        store.importDocument(doc)
        XCTAssertEqual(store.documents.count, 1)
        XCTAssertFalse(store.hasOpenedToday)
        XCTAssertEqual(ReceiptStore(defaults: defaults).documents.first?.id, id)
        store.toggleHandled(id)
        XCTAssertTrue(store.receiptDocuments.isEmpty)
    }
}
