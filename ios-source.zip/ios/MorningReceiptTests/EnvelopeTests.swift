import XCTest
@testable import MorningReceipt

final class EnvelopeTests: XCTestCase {
    func testKnownIssuerOnlySuggestsCategory() {
        let result = EnvelopeClassifier.predict("日本年金機構\n親展\n兵庫県芦屋市", imageData: Data())
        XCTAssertEqual(result.sender, "日本年金機構")
        XCTAssertEqual(result.category, "年金に関する案内")
        XCTAssertTrue(result.explanation.contains("推測"))
        XCTAssertFalse(result.possibilities.contains(where: { $0.contains("申請期限") }))
    }
    func testRecipientAddressDoesNotBecomeSender() {
        let result = EnvelopeClassifier.predict("〒659-0000\n兵庫県芦屋市○○町\n山田様\n親展", imageData: Data())
        XCTAssertEqual(result.category, "内容は開封後に確認")
        XCTAssertNil(result.officialURL)
    }
    func testCityIssuerHasOnlyBroadPrediction() {
        let result = EnvelopeClassifier.predict("芦屋市役所 市民課\n山田様", imageData: Data())
        XCTAssertEqual(result.sender, "芦屋市")
        XCTAssertTrue(result.possibilities.first?.contains("行政手続き") == true)
    }
}
