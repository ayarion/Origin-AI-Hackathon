import XCTest
@testable import MorningReceipt

final class ReceiptStoreTests: XCTestCase {
    private var suiteName = ""
    private var defaults: UserDefaults!

    override func setUp() {
        super.setUp()
        suiteName = "receipt.tests.\(UUID().uuidString)"
        defaults = UserDefaults(suiteName: suiteName)!
    }

    override func tearDown() {
        defaults.removePersistentDomain(forName: suiteName)
        defaults = nil
        super.tearDown()
    }

    @MainActor func testProfileFiltersAndEmptyReceipt() {
        let store = ReceiptStore(defaults: defaults)
        XCTAssertEqual(store.articles.count, 3)
        XCTAssertEqual(store.potentialAmount, 48000)
        var profile = store.profile
        profile.university = false
        store.updateProfile(profile)
        XCTAssertEqual(store.articles.map(\.source), [.city, .company])
        XCTAssertEqual(store.potentialAmount, 0)
        profile.city = false
        profile.company = false
        profile.name = "  "
        store.updateProfile(profile)
        XCTAssertTrue(store.articles.isEmpty)
        XCTAssertEqual(store.profile.name, "あなた")
    }

    @MainActor func testProcedureLifecycleAndPersistence() {
        let store = ReceiptStore(defaults: defaults)
        let article = Article.samples[0]
        store.add(article)
        store.add(article)
        XCTAssertEqual(store.activeProcedures.count, 1, "Adding the same article must be idempotent")
        XCTAssertEqual(store.upcomingCount, 1)
        store.complete(article.id)
        XCTAssertEqual(store.completedProcedures.count, 0, "Incomplete preparations cannot be completed")
        for index in article.steps.indices { store.toggleStep(procedureID: article.id, index: index) }
        store.setReminder(procedureID: article.id, days: 3)
        store.complete(article.id)
        XCTAssertEqual(store.completedProcedures.count, 1)
        XCTAssertEqual(store.upcomingCount, 0)
        let restored = ReceiptStore(defaults: defaults)
        XCTAssertEqual(restored.procedures, store.procedures)
        XCTAssertEqual(restored.procedures[0].reminderDays, 3)
        restored.reopen(article.id)
        XCTAssertEqual(restored.activeProcedures.count, 1)
    }

    @MainActor func testReadingPersistsButNewDayGetsNewReceipt() {
        let store = ReceiptStore(defaults: defaults)
        store.openReceipt()
        XCTAssertTrue(ReceiptStore(defaults: defaults).hasOpenedToday)
        store.refreshDay(now: store.date(after: 1))
        XCTAssertFalse(store.hasOpenedToday)
        store.openReceipt()
        XCTAssertTrue(store.hasOpenedToday)
        store.replay()
        XCTAssertFalse(store.hasOpenedToday)
    }

    func testTearingRequiresIntentionalDownwardPull() {
        XCTAssertFalse(ReceiptGesture.shouldTear(vertical: -120))
        XCTAssertFalse(ReceiptGesture.shouldTear(vertical: 45))
        XCTAssertTrue(ReceiptGesture.shouldTear(vertical: 94))
        XCTAssertTrue(ReceiptGesture.shouldTear(vertical: 150))
    }
}
