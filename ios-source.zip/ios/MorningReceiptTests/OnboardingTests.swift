import XCTest
@testable import MorningReceipt

final class OnboardingTests: XCTestCase {
    func testPostalLookupAndSchoolDirectory() async throws {
        let regions = try await OnboardingCatalog.shared.regions(postcode: "6590093")
        XCTAssertEqual(regions, ["兵庫県芦屋市"])
        let schools = try await OnboardingCatalog.shared.schools(matching: "甲南大学")
        XCTAssertTrue(schools.contains { $0.name == "甲南大学" && $0.region.contains("神戸市") })
        XCTAssertEqual(OnboardingCatalog.digits("６５９-００９３"), "6590093")
    }
    func testValidationAndAffiliationClearing() {
        var record = OnboardingRecord()
        record.stage = .age; record.age = "121"
        XCTAssertFalse(record.canContinue)
        record.age = "21"; XCTAssertTrue(record.canContinue)
        record.stage = .region; record.region = "  \n "
        XCTAssertFalse(record.canContinue)
        record.region = "兵庫県芦屋市"; XCTAssertTrue(record.canContinue)
        record.affiliation = .other
        record.school = "甲南大学"; record.employer = "会社"
        let profile = record.profile(from: NewspaperProfile())
        XCTAssertNil(profile.university); XCTAssertNil(profile.employer); XCTAssertNil(profile.studentYear)
    }
    @MainActor func testResumeAndCompletion() {
        let suite = "tome.onboarding.test.\(UUID().uuidString)"
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        let store = OnboardingStore(defaults: defaults)
        var record = OnboardingRecord(); record.stage = .region; record.age = "21"
        XCTAssertTrue(store.save(record))
        let restored = OnboardingStore(defaults: defaults)
        XCTAssertEqual(restored.record.stage, .region)
        XCTAssertEqual(restored.record.age, "21")
        XCTAssertFalse(restored.record.welcomeCompleted)
        XCTAssertTrue(restored.finish(profile: NewspaperProfile()))
        XCTAssertTrue(OnboardingStore(defaults: defaults).record.welcomeCompleted)
    }
}
