import XCTest
@testable import MorningReceipt

final class NewspaperTests: XCTestCase {
    func testMorningBoundary() {
        let formatter = ISO8601DateFormatter()
        XCTAssertEqual(NewspaperCuration.day(formatter.date(from: "2026-09-23T05:59:59+09:00")!), "2026-09-22")
        XCTAssertEqual(NewspaperCuration.day(formatter.date(from: "2026-09-23T06:00:00+09:00")!), "2026-09-23")
    }
    @MainActor func testRefreshAndSettingsDoNotReplayReceivedEdition() async {
        let name = "newspaper.tests.\(UUID())"
        let defaults = UserDefaults(suiteName: name)!
        defer { defaults.removePersistentDomain(forName: name) }
        let store = NewspaperStore(defaults: defaults, shares: false)
        var profile = NewspaperProfile(); profile.feedURL = ""
        store.configure(profile)
        let date = ISO8601DateFormatter().date(from: "2026-09-23T08:00:00+09:00")!
        await store.prepare(now: date); store.receive()
        await store.prepare(force: true, now: date)
        XCTAssertEqual(store.edition?.opened, true)
        profile.ageBand = "30〜49歳"; store.configure(profile)
        await store.prepare(now: date)
        XCTAssertEqual(store.edition?.opened, true)
        let restored = NewspaperStore(defaults: defaults, shares: false)
        XCTAssertEqual(restored.edition?.opened, true)
    }
    func testOfficialFeedHostsOnly() {
        XCTAssertTrue(NewspaperFeed.allowed(URL(string: "https://www.city.ashiya.lg.jp/shinchaku/shinchaku.xml")!))
        for address in ["http://www.city.ashiya.lg.jp/a", "https://city.lg.jp.evil.com/a", "https://user:pass@city.lg.jp/a", "https://city.lg.jp:123/a"] { XCTAssertFalse(NewspaperFeed.allowed(URL(string: address)!)) }
    }
    func testRSSOneParsesDateAndRejectsExternalArticle() throws {
        let xml = """
        <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:dc="http://purl.org/dc/elements/1.1/">
        <item><title>学生の学び</title><link>https://www.city.ashiya.lg.jp/student.html</link><description><![CDATA[<p>公式のお知らせ</p>]]></description><dc:date>2026-09-22T09:00:00+09:00</dc:date><dc:subject>学生</dc:subject></item>
        <item><title>外部</title><link>https://example.com/</link></item></rdf:RDF>
        """
        let items = try NewspaperFeed.parse(Data(xml.utf8), source: "芦屋市")
        XCTAssertEqual(items.count, 1)
        XCTAssertEqual(items[0].title, "学生の学び")
        XCTAssertNotNil(items[0].publishedAt)
        XCTAssertTrue(items[0].summary.contains("公式のお知らせ"))
        XCTAssertThrowsError(try NewspaperFeed.parse(Data("broken".utf8), source: "芦屋市"))
    }
    func testCurationDeduplicatesAndExplainsStudentGuide() {
        let articles = NewspaperCuration.guides + NewspaperCuration.guides
        let selected = NewspaperCuration.select(articles, profile: NewspaperProfile())
        XCTAssertEqual(selected.count, 3)
        XCTAssertTrue(selected.first?.support != nil)
        XCTAssertTrue(selected.contains { $0.id == "support-pension-student" && $0.reason.contains("大学生") })
        XCTAssertTrue(selected.allSatisfy(\.isGuide))
    }
    func testSupportNeedsPromoteEmergencyGuideWithoutClaimingEligibility() {
        var profile = NewspaperProfile()
        profile.supportNeeds = ["support-jasso-emergency"]
        let selected = NewspaperCuration.select(NewspaperCuration.guides(for: profile), profile: profile)
        XCTAssertEqual(selected.first?.id, "support-jasso-emergency")
        XCTAssertTrue(selected.first?.reason.contains("未確認") == true)
        XCTAssertTrue(selected.first?.url.host == "www.jasso.go.jp")
    }
    @MainActor func testDailyEditionAndProfileInvalidation() async throws {
        let name = "newspaper.tests.\(UUID())"
        let defaults = UserDefaults(suiteName: name)!
        defer { defaults.removePersistentDomain(forName: name) }
        let store = NewspaperStore(defaults: defaults, shares: false)
        var profile = NewspaperProfile(); profile.feedURL = ""
        store.configure(profile)
        let today = ISO8601DateFormatter().date(from: "2026-09-22T23:00:00Z")!
        await store.prepare(now: today)
        XCTAssertEqual(store.edition?.day, "2026-09-23")
        store.receive()
        await store.prepare(now: today)
        XCTAssertEqual(store.edition?.opened, true)
        XCTAssertEqual(NewspaperStore(defaults: defaults, shares: false).edition?.opened, true)
        await store.prepare(now: today.addingTimeInterval(86400))
        XCTAssertEqual(store.edition?.opened, false)
        profile.region = "別の地域"; store.configure(profile)
        XCTAssertNil(store.edition)
    }
}
