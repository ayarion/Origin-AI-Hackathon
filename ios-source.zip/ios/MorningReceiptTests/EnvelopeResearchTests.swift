import XCTest
@testable import MorningReceipt

final class EnvelopeResearchTests: XCTestCase {
    func testDoesNotSearchPersonalInformation() {
        for value in ["山田様のご案内", "住所：兵庫県芦屋市", "番号123456789", "hello@example.com"] {
            XCTAssertFalse(EnvelopeResearch.safeLabel(value))
        }
        XCTAssertTrue(EnvelopeResearch.safeLabel("2026年度 給付奨学金のご案内"))
    }
    func testRequiresSameProgramIssuerAndExplicitYear() {
        let labels = EnvelopeLabels(sender: "甲南大学", notice: "2026年度 給付奨学金のご案内", status: "")
        var source = OfficialSource(title: "検索結果", url: URL(string: "https://www.konan-u.ac.jp/news/a")!, fetchedAt: .now, summary: "", requiredDocuments: "在学証明書", deadline: "", applicationLinks: [], pageTitle: "2026年度 給付奨学金の募集", evidenceText: "甲南大学")
        XCTAssertTrue(EnvelopeResearch.matches(labels, source: source))
        source.pageTitle = "2025年度 給付奨学金の募集"
        XCTAssertFalse(EnvelopeResearch.matches(labels, source: source))
        source.pageTitle = "2026年度 留学募集"
        XCTAssertFalse(EnvelopeResearch.matches(labels, source: source))
    }
    func testCityAddressCannotBecomeSearchSender() {
        let labels = EnvelopeResearch.fallback("兵庫県芦屋市○○町\n山田様\n重要なお知らせ")
        XCTAssertTrue(labels.sender.isEmpty)
        XCTAssertTrue(labels.notice.isEmpty)
    }
    func testStudentPensionPreviewRequiresKnownAdultStudent() {
        var profile = NewspaperProfile()
        profile.age = 21
        profile.university = "甲南大学"
        XCTAssertEqual(EnvelopeResearch.likelyPrograms(sender: "日本年金機構", profile: profile).first?.title, "学生納付特例")
        profile.age = 19
        XCTAssertTrue(EnvelopeResearch.likelyPrograms(sender: "日本年金機構", profile: profile).isEmpty)
        profile.age = nil
        XCTAssertTrue(EnvelopeResearch.likelyPrograms(sender: "日本年金機構", profile: profile).isEmpty)
        profile.age = 21
        profile.university = nil
        profile.studentYear = nil
        XCTAssertTrue(EnvelopeResearch.likelyPrograms(sender: "日本年金機構", profile: profile).isEmpty)
    }
    func testPreviewDoesNotAssumeEveryCityLetterIsAProgram() {
        let profile = NewspaperProfile()
        XCTAssertTrue(EnvelopeResearch.likelyPrograms(sender: "芦屋市", profile: profile).isEmpty)
    }
}
