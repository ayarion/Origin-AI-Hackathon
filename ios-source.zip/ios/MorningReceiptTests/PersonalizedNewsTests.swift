import XCTest
@testable import MorningReceipt

final class PersonalizedNewsTests: XCTestCase {
    func testOneSourceCannotFillEntireEdition() {
        var input: [NewspaperHeadline] = []
        for index in 0..<15 {
            var item = NewspaperCuration.guides[0]
            item.id = "item-\(index)"; item.source = "甲南大学"
            input.append(item)
        }
        input.append(NewspaperCuration.guides[2])
        let result = NewspaperCuration.select(input, profile: NewspaperProfile())
        XCTAssertEqual(result.filter { $0.source == "甲南大学" }.count, 6)
        XCTAssertTrue(result.contains { $0.id == "guide-disaster" })
    }
    func testArticleImageReadsRealMetadataAndRejectsExternalHosts() {
        let base = URL(string: "https://test.ac.jp/news")!
        XCTAssertEqual(NewsImageLoader.image(in: "<meta content='/photo.jpg' property='og:image'>", base: base)?.absoluteString, "https://test.ac.jp/photo.jpg")
        XCTAssertNil(NewsImageLoader.image(in: "<meta property='og:image' content='https://evil.com/photo.jpg'>", base: base))
    }
    func testOldProfileDecodesWithoutPersonalFields() throws {
        let data = try JSONEncoder().encode(NewspaperProfile())
        let profile = try JSONDecoder().decode(NewspaperProfile.self, from: data)
        XCTAssertNil(profile.university)
        XCTAssertNil(profile.employer)
        XCTAssertNil(profile.searchEnabled)
    }
    func testExactAgeOverridesOldBand() {
        var profile = NewspaperProfile()
        profile.age = 70
        XCTAssertEqual(profile.effectiveAgeBand, "65歳以上")
        XCTAssertTrue(NewspaperCuration.keywords(profile).contains("介護"))
    }
    func testQueriesKeepOrganizationsSeparateAndNeverSendAge() {
        var profile = NewspaperProfile()
        profile.age = 21; profile.university = "テスト大学"; profile.employer = "テスト株式会社"
        let queries = PersonalizedNews.queries(profile)
        XCTAssertEqual(queries.count, 3)
        XCTAssertFalse(queries.contains(where: { $0.contains("21歳") }))
        XCTAssertFalse(queries.contains(where: { $0.contains("テスト大学") && $0.contains("テスト株式会社") }))
    }
    func testAIOrderRejectsInventedOrDuplicateIndices() {
        let input = NewspaperCuration.guides
        XCTAssertNil(PersonalizedNews.reordered(input, indices: [0, 0]))
        XCTAssertNil(PersonalizedNews.reordered(input, indices: [99]))
        XCTAssertNil(PersonalizedNews.reordered(input, indices: [-1]))
        let sorted = PersonalizedNews.reordered(input, indices: [2, 0])!
        XCTAssertEqual(sorted.map(\.id), [input[2].id, input[0].id, input[1].id])
        XCTAssertEqual(Set(sorted.map(\.url)), Set(input.map(\.url)))
    }
    func testGenresSeparateStudySupportAndWork() {
        var item = NewspaperCuration.guides[0]
        XCTAssertEqual(NewsGenre.classify(item), .study)
        item.title = "住居確保給付金"; item.summary = ""; item.tags = []
        XCTAssertEqual(NewsGenre.classify(item), .support)
        item.title = "職員採用のお知らせ"
        XCTAssertEqual(NewsGenre.classify(item), .work)
        item.title = "熱中症対策"; item.tags = ["教育"]
        XCTAssertEqual(NewsGenre.classify(item), .health)
    }
    func testIrrelevantProcurementIsExcluded() {
        var item = NewspaperCuration.guides[0]
        item.title = "令和8年 競争入札の案内"
        XCTAssertTrue(NewspaperCuration.select([item], profile: NewspaperProfile()).isEmpty)
    }
    func testRSSImageRequiresSameOfficialHost() throws {
        let xml = """
        <rss xmlns:media="http://search.yahoo.com/mrss/"><channel><item><title>大学のお知らせ</title><link>https://test.ac.jp/news</link><media:thumbnail url="https://test.ac.jp/photo.jpg"/><pubDate>Wed, 23 Sep 2026 10:00:00 +0900</pubDate></item></channel></rss>
        """
        let result = try NewspaperFeed.parse(Data(xml.utf8), source: "テスト大学")
        XCTAssertEqual(result.first?.imageURL?.absoluteString, "https://test.ac.jp/photo.jpg")
        let bad = xml.replacingOccurrences(of: "https://test.ac.jp/photo.jpg", with: "https://evil.com/photo.jpg")
        XCTAssertNil(try NewspaperFeed.parse(Data(bad.utf8), source: "テスト大学").first?.imageURL)
    }
}
