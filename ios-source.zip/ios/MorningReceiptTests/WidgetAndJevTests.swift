import XCTest
@testable import MorningReceipt

final class WidgetAndJevTests: XCTestCase {
    func testLiveActivityUsesTopPersonalizedHeadlineAndEditionCount() {
        var edition = NewspaperEdition.preview
        edition.headlines.append(NewspaperHeadline(id: "other", title: "2番目の情報", summary: "", source: "公式", url: URL(string: "https://example.org")!, tags: [], reason: ""))
        let state = MorningPaperActivity.ContentState(edition: edition)
        XCTAssertEqual(state?.headline, edition.headlines[0].title)
        XCTAssertEqual(state?.count, 2)
        XCTAssertEqual(state?.secondHeadline, "")
        edition.headlines = []
        XCTAssertNil(MorningPaperActivity.ContentState(edition: edition))
    }
    func testDeadlineSortingDoesNotInventYearOrNormalizeInvalidDays() {
        XCTAssertNotNil(ReceiptDeadline.date("2026年10月2日"))
        XCTAssertNil(ReceiptDeadline.date("10月2日"))
        XCTAssertNil(ReceiptDeadline.date("2026年2月30日"))
    }
    @MainActor func testWidgetAttentionExcludesHandledAndPrioritizesRealDocuments() {
        let name = "widget.tests.\(UUID())"
        let defaults = UserDefaults(suiteName: name)!
        defer { defaults.removePersistentDomain(forName: name) }
        let store = ReceiptStore(defaults: defaults)
        var sample = DocumentExtractor.extract("サンプル申請\n期限：2026年10月1日", isSample: true)
        sample.reviewedAt = .now
        var actual = DocumentExtractor.extract("本当の申請\n期限：2026年10月2日")
        actual.reviewedAt = .now
        store.importDocument(sample); store.importDocument(actual)
        XCTAssertEqual(store.attentionDocuments.first?.id, actual.id)
        store.toggleHandled(actual.id)
        XCTAssertEqual(store.attentionDocuments.map(\.id), [sample.id])
    }
    func testAutomaticJevCandidatesAreBoundedAndExcludeExplicitIdentifiers() {
        let lines = ["申請期限：10月2日", "対象者氏名：山田", "必要書類：在学証明書", "口座の提出期限：10月3日"]
        let blocks = lines.enumerated().map { OCRBlock(id: String($0.offset), text: $0.element, rect: .zero) }
        XCTAssertEqual(JevImportance.candidates(blocks).map(\.id), ["0", "2"])
    }
    func testRoutesRejectInvalidAndPreserveDocumentIdentity() {
        let id = UUID()
        XCTAssertEqual(ToMeRoute(url: URL(string: "tome://document/\(id)")!), .document(id))
        XCTAssertEqual(ToMeRoute(url: URL(string: "tome://capture")!), .capture)
        XCTAssertNil(ToMeRoute(url: URL(string: "https://document/\(id)")!))
        XCTAssertNil(ToMeRoute(url: URL(string: "tome://document/not-an-id")!))
    }
    func testJevContractSendsOnlySelectedText() throws {
        let block = OCRBlock(id: "line1", text: "申請期限：10月2日", rect: .zero)
        let request = try JevImportance.request(blocks: [block], key: "fixture-not-real")
        XCTAssertEqual(request.httpMethod, "POST")
        XCTAssertEqual(request.url?.absoluteString, "https://api.typesafe.ai/v1/systemone")
        let body = try XCTUnwrap(request.httpBody)
        let json = try XCTUnwrap(JSONSerialization.jsonObject(with: body) as? [String: Any])
        XCTAssertEqual(json["model"] as? String, "jev-latest")
        XCTAssertNotNil(json["questions"])
        XCTAssertNil(json["image"])
        XCTAssertFalse(String(data: body, encoding: .utf8)!.contains("fixture-not-real"))
        XCTAssertThrowsError(try JevImportance.request(blocks: [block], key: ""))
    }
    func testJevRejectsFabricatedOrIncompleteBlockIDs() throws {
        let valid = Data(#"{"model":"jev-1.13.0","answers":{"line1":{"type":"choice","choice":"important","confidence":0.9},"line2":{"type":"choice","choice":"ordinary","confidence":0.9}},"usage":{"input_tokens":1,"output_tokens":1}}"#.utf8)
        XCTAssertEqual(try JevImportance.decode(valid, allowed: ["line1", "line2"]), ["line1"])
        XCTAssertThrowsError(try JevImportance.decode(valid, allowed: ["line1"]))
        XCTAssertThrowsError(try JevImportance.decode(valid, allowed: ["line1", "line2", "line3"]))
        XCTAssertThrowsError(try JevImportance.decode(Data(#"{"model":"jev-1.13.0","answers":{}}"#.utf8), allowed: ["line1"]))
    }
    func testDocumentURLsDoNotSendPrivateQueryTokens() {
        let urls = OfficialSearchPolicy.documentURLs("https://www.mext.go.jp/apply https://www.mext.go.jp/private?token=abc https://evil.com/apply")
        XCTAssertEqual(urls.map(\.absoluteString), ["https://www.mext.go.jp/apply"])
    }
    func testOldDocumentsDecodeWithoutNewEvidenceFields() throws {
        let original = DocumentExtractor.extract("申請のお知らせ\n期限：10月2日")
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(original)) as? [String: Any])
        for key in ["pages", "importantBlockIDs", "importanceStatus", "reviewedAt"] { object.removeValue(forKey: key) }
        let restored = try JSONDecoder().decode(CapturedDocument.self, from: JSONSerialization.data(withJSONObject: object))
        XCTAssertEqual(restored.id, original.id)
        XCTAssertNil(restored.pages)
        XCTAssertNil(restored.reviewedAt)
    }
    @MainActor func testOCRRetainsNormalizedBoundsAndOriginalImage() async throws {
        let result = try await DocumentOCR.scan(SampleDocument.imageData())
        XCTAssertFalse(result.imageData.isEmpty)
        XCTAssertFalse(result.blocks.isEmpty)
        XCTAssertTrue(result.blocks.contains { $0.text.contains("申請期限") })
        for block in result.blocks {
            XCTAssertTrue((0...1).contains(block.rect.minX))
            XCTAssertTrue((0...1).contains(block.rect.maxY))
            XCTAssertGreaterThan(block.rect.height, 0)
        }
    }
}
