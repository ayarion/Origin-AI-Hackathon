import SwiftUI
import UserNotifications
import MapKit

struct ToMeLaunchView: View {
    @Environment(OnboardingStore.self) private var onboarding
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var titleVisible = true
    var body: some View {
        ZStack {
            if titleVisible { ToMeTitleView() }
            else if onboarding.record.welcomeCompleted { RootView() }
            else { DiagnosisView() }
        }
        .task {
            do { try await Task.sleep(for: .milliseconds(1500)) } catch { return }
            withAnimation(reduceMotion ? nil : .easeOut(duration: 0.25)) { titleVisible = false }
        }
        .alert("設定を確認してください", isPresented: Binding(get: { onboarding.error != nil }, set: { if !$0 { onboarding.error = nil } })) {
            Button("もう一度確認") { onboarding.error = nil; onboarding.reload() }
            Button("閉じる", role: .cancel) { onboarding.error = nil }
        } message: { Text(onboarding.error ?? "") }
    }
}

struct ToMeTitleView: View {
    var body: some View {
        VStack(spacing: 24) {
            Text("TO:ME").font(.system(size: 60, weight: .black, design: .serif)).foregroundStyle(Palette.blue)
                .accessibilityLabel("トゥーミー")
            FrontHamsterView().frame(width: 160, height: 176)
        }.frame(maxWidth: .infinity, maxHeight: .infinity).background { GlassBackdrop() }
    }
}

struct DiagnosisView: View {
    @Environment(OnboardingStore.self) private var onboarding
    @Environment(NewspaperStore.self) private var paper
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @State private var draft = OnboardingRecord()
    @State private var introductionPage = 0
    @State private var goingForward = true
    @State private var postal = ""
    @State private var municipality = ""
    @State private var manualRegion = false
    @State private var regions: [String] = []
    @State private var regionError: String?
    @State private var regionBusy = false
    @State private var organization: OrganizationKind?
    @State private var widgetGuide = false
    @State private var notificationStatus: UNAuthorizationStatus = .notDetermined
    @State private var notificationBusy = false
    @State private var notificationError: String?
    @FocusState private var focused: Input?
    @AccessibilityFocusState private var headingFocused: Bool
    private enum Input { case age, region }
    private var title: String {
        switch draft.stage {
        case .introduction: "TO:MEへようこそ"
        case .age: "年齢を教えてください"
        case .region: "あなたの地域を教えてください"
        case .affiliation: "あなたに関係する情報を見つけるために"
        case .permissions: "気づける場所を増やそう"
        case .welcome, .finished: "これからよろしくね"
        }
    }
    private var transition: AnyTransition {
        reduceMotion ? .identity : .asymmetric(insertion: .move(edge: goingForward ? .trailing : .leading), removal: .move(edge: goingForward ? .leading : .trailing))
    }
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack(spacing: 14) {
                    ProgressView(value: Double(draft.stage == .introduction ? introductionPage + 1 : draft.stage.progress), total: Double(draft.stage == .introduction ? 2 : 5)).tint(Palette.blue)
                        .accessibilityLabel(draft.stage == .introduction ? "紹介の進捗" : "設定の進捗")
                    Text(draft.stage == .introduction ? "\(introductionPage + 1)/2" : "\(draft.stage.progress)/5")
                        .font(.body.monospacedDigit()).foregroundStyle(.secondary)
                }.frame(maxWidth: 512).padding(.horizontal, 24).padding(.vertical, 12)
                ScrollViewReader { proxy in
                    ScrollView {
                        VStack(alignment: .leading, spacing: 24) {
                            if draft.stage != .introduction {
                                Text(title).font(.largeTitle.bold()).foregroundStyle(Palette.blue)
                                    .accessibilityAddTraits(.isHeader).accessibilityFocused($headingFocused).id("heading")
                            }
                            content
                        }.frame(maxWidth: 512, alignment: .leading).padding(24).frame(maxWidth: .infinity)
                            .id(draft.stage).transition(transition)
                    }.scrollDismissesKeyboard(.interactively)
                        .onChange(of: focused) { _, value in
                            guard value != nil else { return }
                            withAnimation(reduceMotion ? nil : .easeOut(duration: 0.2)) { proxy.scrollTo("input", anchor: .center) }
                        }
                        .onChange(of: draft.stage) { _, _ in proxy.scrollTo("heading", anchor: .top) }
                }
            }
            .background { GlassBackdrop() }
            .safeAreaInset(edge: .bottom, spacing: 0) {
                if focused == nil {
                    Button(footerTitle, action: advance).buttonStyle(SoftButtonStyle(primary: true))
                        .disabled(!draft.canContinue || notificationBusy)
                        .opacity(draft.canContinue ? 1 : 0.5)
                        .frame(maxWidth: 300).padding(.horizontal, 24).padding(.vertical, 16)
                        .frame(maxWidth: .infinity).background(.ultraThinMaterial)
                }
            }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    if draft.stage != .introduction || introductionPage > 0 {
                        Button(action: back) { Label("戻る", systemImage: "chevron.left").frame(minHeight: 44) }
                    }
                }
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer(); Button("入力を終える") { focused = nil }.frame(minHeight: 44)
                }
            }
            .sheet(item: $organization) { kind in
                OrganizationPicker(kind: kind) { name, schoolKind in
                    if kind == .school { draft.school = name; draft.schoolKind = schoolKind }
                    else { draft.employer = name }
                    organization = nil
                }
            }
            .sheet(isPresented: $widgetGuide) { NavigationStack { WidgetGuideView().toolbar { ToolbarItem(placement: .confirmationAction) { Button("完了") { widgetGuide = false } } } } }
            .task { draft = onboarding.record; await refreshNotifications(); headingFocused = true }
            .onChange(of: draft) { _, value in onboarding.save(value) }
            .onChange(of: scenePhase) { _, value in
                if value != .active { onboarding.save(draft) }
                else { Task { await refreshNotifications() } }
            }
            .task(id: "\(manualRegion)|\(postal)|\(municipality)") { await findRegion() }
        }.tint(Palette.blue)
    }
    @ViewBuilder private var content: some View {
        switch draft.stage {
        case .introduction:
            ValueIntroductionView(page: $introductionPage)
        case .age:
            Text("年齢に合う制度を見つけるために使います。").font(.body)
            FrontHamsterView().frame(width: 96, height: 108).frame(maxWidth: .infinity)
            HStack(alignment: .firstTextBaseline, spacing: 12) {
                TextField("21", text: $draft.age).keyboardType(.numberPad).focused($focused, equals: .age)
                    .font(.system(.largeTitle, design: .rounded).bold()).multilineTextAlignment(.center)
                    .accessibilityLabel("現在の年齢")
                    .onChange(of: draft.age) { _, value in draft.age = String(OnboardingCatalog.digits(value).prefix(3)) }
                Text("歳").font(.title2)
            }.padding(24).softSurface().id("input")
            if !draft.age.isEmpty && draft.validAge == nil { Text("0〜120歳で入力してください。").foregroundStyle(.red) }
        case .region:
            Text("近くの制度やお知らせを見つけるために使います。").font(.body)
            FrontHamsterView().frame(width: 84, height: 94).frame(maxWidth: .infinity)
            VStack(alignment: .leading, spacing: 14) {
                Text(manualRegion ? "市区町村から探す" : "郵便番号からお住まいの地域を設定").font(.headline)
                if manualRegion {
                    TextField("例：芦屋市", text: $municipality).focused($focused, equals: .region)
                        .onChange(of: municipality) { _, _ in draft.region = "" }
                } else {
                    TextField("郵便番号 7桁", text: $postal).keyboardType(.numberPad).focused($focused, equals: .region)
                        .onChange(of: postal) { _, value in
                            postal = String(OnboardingCatalog.digits(value).prefix(7)); draft.region = ""
                        }
                }
            }.font(.title3).padding(22).softSurface().id("input")
            Button(manualRegion ? "郵便番号で探す" : "市区町村から探す") {
                manualRegion.toggle(); focused = nil; regions = []; regionError = nil
            }.frame(minHeight: 44)
            if regionBusy { ProgressView("地域を確認しています") }
            if let regionError { Text(regionError).font(.body).foregroundStyle(.secondary) }
            ForEach(regions, id: \.self) { region in
                Button {
                    draft.region = region; focused = nil
                } label: {
                    HStack { Text(region).multilineTextAlignment(.leading); Spacer(); Image(systemName: draft.region == region ? "checkmark.circle.fill" : "circle") }
                        .frame(minHeight: 44).padding(16).softSurface()
                }.buttonStyle(.plain)
            }
            if !draft.region.isEmpty && !regions.contains(draft.region) { Label(draft.region, systemImage: "checkmark.circle.fill").font(.headline) }
            Text("個人情報は外部に送られません。").font(.subheadline).foregroundStyle(.secondary)
        case .affiliation:
            ForEach(Affiliation.allCases) { value in
                Button { draft.affiliation = value } label: {
                    HStack { Text(value.rawValue); Spacer(); Image(systemName: draft.affiliation == value ? "largecircle.fill.circle" : "circle") }
                        .font(.headline).frame(minHeight: 44).padding(14).softSurface()
                }.buttonStyle(.plain).accessibilityAddTraits(draft.affiliation == value ? .isSelected : [])
            }
            if draft.affiliation?.hasSchool == true { organizationButton(.school, value: draft.school) }
            if draft.affiliation?.hasWork == true { organizationButton(.work, value: draft.employer) }
            Text("学校名・勤務先は任意です。あとから変更できます。").font(.subheadline).foregroundStyle(.secondary)
        case .permissions:
            VStack(alignment: .leading, spacing: 16) {
                Label("ウィジェット", systemImage: "rectangle.3.group").font(.title2.bold())
                Text("ホーム画面にもあなたに届いた情報を。").font(.body)
                Button("追加方法を見る") { widgetGuide = true }.buttonStyle(SoftButtonStyle())
            }.padding(22).softSurface()
            VStack(alignment: .leading, spacing: 16) {
                Label("通知", systemImage: "bell").font(.title2.bold())
                Text(notificationStatus == .authorized || notificationStatus == .provisional ? "通知は許可されています。" : "大切なお知らせに気づけるよう通知を設定します。").font(.body)
                if notificationStatus == .notDetermined {
                    Button(notificationBusy ? "確認中…" : "通知を許可する") { Task { await requestNotifications() } }
                        .buttonStyle(SoftButtonStyle(primary: true)).disabled(notificationBusy)
                } else if notificationStatus == .denied {
                    Text("通知なしでも、アプリを開いて情報を確認できます。").font(.body)
                    Link("iPhoneの設定を開く", destination: URL(string: UIApplication.openSettingsURLString)!).frame(minHeight: 44)
                }
                if let notificationError { Text(notificationError).font(.body).foregroundStyle(.red) }
            }.padding(22).softSurface()
        case .welcome, .finished:
            PartnerOpeningMessage()
        }
    }
    private func organizationButton(_ kind: OrganizationKind, value: String) -> some View {
        Button { organization = kind } label: {
            HStack { Image(systemName: "magnifyingglass"); Text(value.isEmpty ? kind.placeholder : value).multilineTextAlignment(.leading); Spacer(); Image(systemName: "chevron.right") }
                .font(.body).frame(minHeight: 44).padding(18).softSurface()
        }.buttonStyle(.plain)
    }
    private var footerTitle: String {
        if draft.stage == .introduction { return introductionPage == 0 ? "次へ" : "設定する" }
        if draft.stage == .welcome { return "はじめる" }
        if draft.stage == .permissions && notificationStatus != .authorized && notificationStatus != .provisional { return "通知なしで続ける" }
        return "次へ"
    }
    private func advance() {
        if draft.stage == .introduction && introductionPage == 0 {
            withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.25)) { introductionPage = 1 }; return
        }
        if draft.stage == .welcome {
            let profile = draft.profile(from: paper.profile)
            if onboarding.finish(profile: profile) { paper.configure(profile) }
            return
        }
        if draft.stage == .age { draft.ageConfirmedAt = .now }
        if draft.stage == .permissions { draft.notificationChoice = notificationStatus == .authorized || notificationStatus == .provisional ? "allowed" : "skipped" }
        guard draft.canContinue, let next = Stage(rawValue: draft.stage.rawValue + 1) else { return }
        move(to: next, forward: true)
    }
    private func back() {
        focused = nil
        if draft.stage == .introduction { introductionPage = 0; return }
        guard let previous = Stage(rawValue: draft.stage.rawValue - 1) else { return }
        if previous == .introduction { introductionPage = 1 }
        move(to: previous, forward: false)
    }
    private func move(to stage: Stage, forward: Bool) {
        var value = draft; value.stage = stage
        guard onboarding.save(value) else { return }
        goingForward = forward
        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.28)) { draft = value }
        Task { try? await Task.sleep(for: .milliseconds(reduceMotion ? 0 : 350)); headingFocused = true }
    }
    private func findRegion() async {
        regions = []; regionError = nil
        guard manualRegion ? !municipality.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty : postal.count == 7 else { regionBusy = false; return }
        regionBusy = true
        do {
            try await Task.sleep(for: .milliseconds(150))
            let values = try await (manualRegion ? OnboardingCatalog.shared.regions(matching: municipality) : OnboardingCatalog.shared.regions(postcode: postal))
            guard !Task.isCancelled else { return }
            regions = values
            if values.isEmpty { regionError = "地域が見つかりません。市区町村名でも探せます。" }
        } catch { if !Task.isCancelled { regionError = "地域データを読み込めませんでした。" } }
        if !Task.isCancelled { regionBusy = false }
    }
    private func refreshNotifications() async {
        notificationStatus = await UNUserNotificationCenter.current().notificationSettings().authorizationStatus
    }
    private func requestNotifications() async {
        notificationBusy = true; notificationError = nil
        do { _ = try await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) }
        catch { notificationError = "通知の設定を確認できませんでした。通知なしでも続けられます。" }
        await refreshNotifications(); notificationBusy = false
    }
}

struct ValueIntroductionView: View {
    @Binding var page: Int
    @Environment(\.dynamicTypeSize) private var typeSize
    var body: some View {
        TabView(selection: $page) {
            introduction("知らなかった支援に気づける", text: "住む地域と今の暮らしに合うニュースや制度を届けます。", symbol: "sparkles.rectangle.stack").tag(0)
            introduction("届いた封筒から次の一歩へ", text: "封筒をかざすと関係しそうな手続きを公式情報から探します。開封後は必要なものと期限も確認できます。", symbol: "envelope.open").tag(1)
        }.tabViewStyle(.page(indexDisplayMode: .never))
            .frame(height: typeSize.isAccessibilitySize ? 900 : 500)
            .accessibilityValue("\(page + 1)ページ目、全2ページ")
    }
    private func introduction(_ title: String, text: String, symbol: String) -> some View {
        VStack(alignment: .center, spacing: 20) {
            ZStack {
                Image(systemName: symbol).font(.system(size: 112, weight: .ultraLight))
                    .foregroundStyle(Palette.blue.opacity(0.10)).offset(x: 82, y: -30)
                FrontHamsterView().frame(width: 170, height: 180)
            }.frame(maxWidth: .infinity).frame(height: 205).softSurface(radius: 32)
                .accessibilityHidden(true)
            Text(title).font(.largeTitle.bold()).foregroundStyle(Palette.blue)
                .multilineTextAlignment(.center).frame(maxWidth: .infinity)
                .frame(minHeight: typeSize.isAccessibilitySize ? 150 : 90, alignment: .top)
                .accessibilityAddTraits(.isHeader)
            Text(text).font(.body).lineSpacing(5).multilineTextAlignment(.center)
                .frame(maxWidth: .infinity).frame(minHeight: typeSize.isAccessibilitySize ? 180 : 95, alignment: .top)
        }.padding(.horizontal, 4).frame(maxWidth: .infinity)
            .frame(height: typeSize.isAccessibilitySize ? 900 : 500, alignment: .top)
    }
}

struct PartnerOpeningMessage: View {
    var body: some View {
        VStack(spacing: 28) {
            FrontHamsterView().frame(width: 160, height: 180)
            Text("あなたの暮らしに合う情報を\nいっしょに見つけていこう。").font(.title2.weight(.medium)).multilineTextAlignment(.center).lineSpacing(8)
        }.frame(maxWidth: .infinity).padding(.vertical, 24)
    }
}

enum OrganizationKind: String, Identifiable { case school, work
    var id: String { rawValue }
    var placeholder: String { self == .school ? "学校名を検索" : "勤務先を検索" }
    var searchPlaceholder: String { self == .school ? "例：東京大学" : "例：会社・団体名" }
}

struct OrganizationPicker: View {
    let kind: OrganizationKind
    let onSelect: (String, String) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    @State private var schools: [SchoolOption] = []
    @State private var workplaces: [MKMapItem] = []
    @State private var busy = false
    @State private var message: String?
    @State private var mapSearch: MKLocalSearch?
    @FocusState private var focused: Bool
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    TextField(kind.searchPlaceholder, text: $query).font(.body).padding(18).softSurface().focused($focused)
                        .submitLabel(.search).onSubmit { if kind == .work { searchWork() } }
                        .onChange(of: query) { _, value in query = String(value.prefix(100)) }
                    if kind == .work {
                        Text("候補の検索時に、入力した名称をAppleマップへ送信します。").font(.subheadline).foregroundStyle(.secondary)
                        Button("候補を検索", action: searchWork).buttonStyle(SoftButtonStyle(primary: true)).disabled(query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || busy)
                    }
                    if busy { ProgressView("候補を探しています") }
                    if let message { Text(message).font(.body) }
                    ForEach(schools) { school in
                        Button { onSelect(school.name, school.kind) } label: { option(school.name, region: school.region) }.buttonStyle(.plain)
                    }
                    ForEach(Array(workplaces.enumerated()), id: \.offset) { _, workplace in
                        Button { onSelect(workplace.name ?? query, "") } label: {
                            option(workplace.name ?? query, region: [workplace.placemark.administrativeArea, workplace.placemark.locality].compactMap { $0 }.joined())
                        }.buttonStyle(.plain)
                    }
                    if !query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                        Button("「\(query.trimmingCharacters(in: .whitespacesAndNewlines))」をそのまま登録") { onSelect(String(query.trimmingCharacters(in: .whitespacesAndNewlines).prefix(100)), "") }
                            .font(.body).frame(minHeight: 44)
                    }
                    if kind == .school { Text("出典：文部科学省 学校コード（2026年公開版）").font(.subheadline).foregroundStyle(.secondary) }
                    Button("登録せずに戻る") { dismiss() }.frame(minHeight: 44)
                }.padding(24).frame(maxWidth: 560).frame(maxWidth: .infinity)
            }.background { GlassBackdrop() }.navigationTitle(kind == .school ? "学校" : "勤務先").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("入力を終える") { focused = false } } }
                .task(id: query) {
                    guard kind == .school else { workplaces = []; return }
                    do {
                        try await Task.sleep(for: .milliseconds(200))
                        let values = try await OnboardingCatalog.shared.schools(matching: query)
                        guard !Task.isCancelled else { return }
                        schools = values; message = values.isEmpty && !query.isEmpty ? "候補がなければ、入力した名前で登録できます。" : nil
                    } catch { if !Task.isCancelled { message = "学校一覧を読み込めませんでした。名前を入力して登録できます。" } }
                }
                .onDisappear { mapSearch?.cancel() }
        }.tint(Palette.blue)
    }
    private func option(_ title: String, region: String) -> some View {
        VStack(alignment: .leading, spacing: 6) { Text(title).font(.headline); Text(region).font(.body).foregroundStyle(.secondary) }
            .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading).padding(18).softSurface()
    }
    private func searchWork() {
        focused = false; busy = true; message = nil; workplaces = []
        let searchedQuery = query
        let request = MKLocalSearch.Request(); request.naturalLanguageQuery = query; request.resultTypes = .pointOfInterest
        let search = MKLocalSearch(request: request); mapSearch = search
        Task {
            do {
                let response = try await search.start()
                if query == searchedQuery { workplaces = Array(response.mapItems.prefix(10)); message = workplaces.isEmpty ? "候補がなければ、入力した名前で登録できます。" : nil }
            } catch { if !Task.isCancelled { message = "候補を取得できませんでした。入力した名前でも登録できます。" } }
            busy = false
        }
    }
}
