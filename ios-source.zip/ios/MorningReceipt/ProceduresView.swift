import SwiftUI

struct ProceduresView: View {
    @Environment(ReceiptStore.self) private var store
    let scan: () -> Void
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                if store.documents.isEmpty {
                    EmptyCard(symbol: "doc.viewfinder", title: "書類をここに。", description: "取り込んだ書類を保管できます。")
                    Button("書類を取り込む", action: scan).buttonStyle(SoftButtonStyle(primary: true))
                }
                ForEach(store.documents) { document in
                    VStack(alignment: .leading, spacing: 12) {
                        DocumentReceiptRow(document: document)
                        Button(document.isHandled ? "未確認に戻す" : "確認済みにする") { store.toggleHandled(document.id) }.buttonStyle(SoftButtonStyle())
                    }.padding(22).softSurface()
                }
                if !store.procedures.isEmpty {
                    Text("保存した手続き").font(.title2.bold())
                    ForEach(store.procedures) { procedure in
                        VStack(alignment: .leading, spacing: 16) {
                            Text(procedure.title).font(.title3.bold())
                            Text(procedure.isComplete ? "完了" : procedure.deadline.shortDate).font(.body)
                            DisclosureGroup("準備を確認") {
                                ForEach(procedure.steps.indices, id: \.self) { index in
                                    Button { store.toggleStep(procedureID: procedure.id, index: index) } label: {
                                        Label(procedure.steps[index], systemImage: procedure.checkedSteps.contains(index) ? "checkmark.circle.fill" : "circle").font(.body).frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 8)
                                    }
                                }
                                Button(procedure.isComplete ? "未完了に戻す" : "完了にする") {
                                    if procedure.isComplete { store.reopen(procedure.id) } else { store.complete(procedure.id) }
                                }.buttonStyle(SoftButtonStyle()).disabled(!procedure.isComplete && procedure.checkedSteps.count != procedure.steps.count)
                            }.font(.body)
                        }.padding(22).softSurface()
                    }
                }
            }.padding(24).frame(maxWidth: 580).frame(maxWidth: .infinity)
        }
    }
}
