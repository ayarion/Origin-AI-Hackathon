import SwiftUI

struct EnvelopePrediction: Identifiable {
    let id = UUID()
    let sender: String
    let category: String
    let possibilities: [String]
    let explanation: String
    let officialURL: URL?
    let imageData: Data
    var rawText: String = ""
}

enum EnvelopeClassifier {
    // An envelope only establishes a visible sender/label, not its contents.
    static func predict(_ text: String, imageData: Data) -> EnvelopePrediction {
        let lines = DocumentExtractor.normalize(text).components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        let joined = lines.joined(separator: " ")
        let rules: [(markers: [String], sender: String, category: String, possibilities: [String], url: String)] = [
            (["日本年金機構", "年金事務所"], "日本年金機構", "年金に関する案内", ["国民年金の加入・保険料に関する連絡", "学生なら納付特例も確認対象"], "https://www.nenkin.go.jp/tokusetsu/gakusei.html"),
            (["日本学生支援機構", "JASSO"], "日本学生支援機構", "奨学金に関する案内", ["奨学金の手続きや確認の連絡"], "https://www.jasso.go.jp/shogakukin/"),
            (["甲南大学", "KONAN UNIVERSITY"], "甲南大学", "大学からの連絡", ["学生生活・学費・奨学金などの連絡"], "https://www.konan-u.ac.jp/life/shien/sas/scholarship/"),
            (["芦屋市役所", "芦屋市長", "芦屋市教育委員会"], "芦屋市", "市からの連絡", ["暮らし・保険・税などの行政手続き"], "https://www.city.ashiya.lg.jp/"),
            (["兵庫県庁", "兵庫県知事", "兵庫県教育委員会"], "兵庫県", "県からの連絡", ["県の制度・手続きのお知らせ"], "https://web.pref.hyogo.lg.jp/"),
            (["税務署", "国税庁"], "税務署・国税庁", "税に関する案内", ["税の申告・納付などに関する連絡"], "https://www.nta.go.jp/")
        ]
        if let rule = rules.first(where: { rule in rule.markers.contains(where: joined.localizedCaseInsensitiveContains) }) {
            return EnvelopePrediction(sender: rule.sender, category: rule.category, possibilities: rule.possibilities,
                                      explanation: "封筒に見える差出人名から推測しています。中身を特定したわけではありません。",
                                      officialURL: URL(string: rule.url), imageData: imageData)
        }
        let senderLine = lines.first { line in
            ["差出人", "差出元", "差出"].contains(where: line.contains) && !line.contains("差出人不明")
        }
        let sender = senderLine.map { line in
            line.replacingOccurrences(of: #"^.*?差出(?:人|元)?\s*[:：]?\s*"#, with: "", options: .regularExpression)
        }?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return EnvelopePrediction(sender: sender.isEmpty ? "差出人を特定できませんでした" : String(sender.prefix(60)),
                                  category: "内容は開封後に確認", possibilities: [],
                                  explanation: "封筒の文字だけでは内容を安全に予測できません。",
                                  officialURL: nil, imageData: imageData)
    }
}

struct EnvelopePreviewView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(NewspaperStore.self) private var paper
    let prediction: EnvelopePrediction
    let onOpenDocument: () -> Void
    @State private var labels = EnvelopeLabels(sender: "", notice: "", status: "")
    @State private var sources: [OfficialSource] = []
    @State private var candidates: [OfficialSource] = []
    @State private var possibilities: [EnvelopePossibility] = []
    @State private var busy = false
    @State private var status = ""
    @State private var retry = 0
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Label("封筒からの予測", systemImage: "envelope.badge.shield.half.filled")
                        .font(.headline).foregroundStyle(Palette.blue)
                    Text(labels.notice.isEmpty ? prediction.category : labels.notice).font(.largeTitle.bold()).foregroundStyle(Palette.ink)
                    Text(labels.sender.isEmpty ? prediction.sender : labels.sender).font(.title3.weight(.medium)).foregroundStyle(Palette.blue)
                    if busy {
                        HStack { ProgressView("公式情報を調べています"); Spacer(); HamsterCompanion().frame(width: 74, height: 82) }
                    }
                    ForEach(sources) { source in EnvelopeSourceCard(source: source) }
                    if !possibilities.isEmpty {
                        Text("開封前に確認できること").font(.headline).foregroundStyle(Palette.blue)
                        ForEach(possibilities) { item in EnvelopePossibilityCard(item: item) }
                    }
                    if !status.isEmpty { Text(status).font(.body).foregroundStyle(.secondary) }
                    DisclosureGroup("差出人・案内名を確認") {
                        TextField("差出組織名", text: $labels.sender)
                        TextField("案内名", text: $labels.notice, axis: .vertical)
                        Button("この名前で調べ直す") { retry += 1 }.disabled(busy)
                        Text("検索するのは組織名と案内名だけです。氏名や住所は入力しないでください。").font(.subheadline)
                    }.font(.body).disabled(busy)
                    if !candidates.isEmpty {
                        DisclosureGroup("一致を確認できなかった候補") {
                            ForEach(candidates) { source in Link(source.pageTitle ?? source.title, destination: source.url).padding(.vertical, 6) }
                        }
                    }
                    if sources.isEmpty && possibilities.isEmpty && !busy {
                        Text("この差出人について、設定したプロフィールに合う公式制度を見つけられませんでした。").font(.body)
                        NavigationLink("検索の接続設定") { SearchSettingsView() }
                    }
                    if let url = prediction.officialURL {
                        Link(destination: url) { Label("差出人の公式情報", systemImage: "arrow.up.right.square") }
                            .buttonStyle(SoftButtonStyle())
                    }
                    Button { dismiss(); onOpenDocument() } label: {
                        Label("開封後に書類を確認", systemImage: "doc.viewfinder")
                    }.buttonStyle(SoftButtonStyle(primary: true))
                    if let image = UIImage(data: prediction.imageData) {
                        DisclosureGroup("撮影した封筒") {
                            Image(uiImage: image).resizable().scaledToFit().clipShape(RoundedRectangle(cornerRadius: 12))
                        }.font(.body)
                    }
                }.padding(24)
            }.background { GlassBackdrop() }
                .navigationTitle("封筒プレビュー").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("閉じる") { dismiss() } } }
                .task(id: retry) {
                    busy = true
                    if retry == 0 { labels = await EnvelopeResearch.labels(prediction.rawText) }
                    let profile = paper.profile
                    async let preview = EnvelopeResearch.preview(sender: labels.sender.isEmpty ? prediction.sender : labels.sender, profile: profile)
                    let result = await EnvelopeResearch.investigate(labels, text: prediction.rawText)
                    let probable = await preview
                    guard !Task.isCancelled else { return }
                    sources = result.0; candidates = result.1; possibilities = probable
                    status = probable.isEmpty ? result.2 : (result.0.isEmpty ? "封筒の案内名は未確認。以下は公開された制度の情報です。" : result.2)
                    busy = false
                }
        }
    }
}

struct EnvelopePossibilityCard: View {
    let item: EnvelopePossibility
    var body: some View {
        VStack(alignment: .leading, spacing: 13) {
            Label("関係するかもしれない制度", systemImage: "sparkle.magnifyingglass")
                .font(.headline).foregroundStyle(Palette.blue)
            Text(item.title).font(.title2.bold()).foregroundStyle(Palette.ink)
            Text(item.reason).font(.body)
            if !item.source.requiredDocuments.isEmpty {
                Text("公式サイトにある準備物").font(.headline)
                Text(item.source.requiredDocuments).font(.body).lineLimit(5)
            }
            Label(item.nextStep, systemImage: "envelope.open").font(.body.weight(.medium))
            Link(destination: item.source.url) { Label("公式情報を見る", systemImage: "arrow.up.right.square") }
                .font(.body.weight(.semibold))
            Text("この封筒の内容・対象資格・個別の期限は、開封して確認してください。")
                .font(.subheadline).foregroundStyle(.secondary)
        }.frame(maxWidth: .infinity, alignment: .leading).padding(22).softSurface()
    }
}

struct EnvelopeSourceCard: View {
    let source: OfficialSource
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Label("公式ページで確認", systemImage: "checkmark.seal").font(.headline).foregroundStyle(Palette.blue)
            Text("期限").font(.headline)
            Text(source.deadline.isEmpty ? "掲載ページからは特定できませんでした" : source.deadline).textSelection(.enabled)
            if let date = ReceiptDeadline.date(source.deadline), date < Calendar.current.startOfDay(for: .now) {
                Text("この掲載期限は経過しています").foregroundStyle(.orange)
            }
            Text("必要書類").font(.headline)
            Text(source.requiredDocuments.isEmpty ? "掲載ページからは特定できませんでした" : source.requiredDocuments).textSelection(.enabled)
            Link(source.pageTitle ?? source.title, destination: source.url).font(.headline)
            ForEach(source.applicationLinks, id: \.absoluteString) { url in Link("申請・様式を開く", destination: url) }
            Text("確認：" + source.fetchedAt.formatted(date: .abbreviated, time: .shortened)).font(.subheadline).foregroundStyle(.secondary)
        }.font(.body).frame(maxWidth: .infinity, alignment: .leading).padding(22).softSurface()
    }
}
