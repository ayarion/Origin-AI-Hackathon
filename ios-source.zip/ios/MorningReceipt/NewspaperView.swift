import SwiftUI

struct NewspaperHome: View {
    @Environment(NewspaperStore.self) private var paper
    @Environment(\.dynamicTypeSize) private var typeSize
    @State private var settings = false
    @State private var genre: NewsGenre = .all
    @State private var page = 0
    @State private var search = ""
    private var articles: [NewspaperHeadline] {
        (paper.edition?.headlines ?? []).filter {
            (genre == .all || NewsGenre.classify($0) == genre) &&
            (search.isEmpty || ($0.title + $0.summary + $0.source).localizedCaseInsensitiveContains(search))
        }
    }
    private var featuredCount: Int { articles.count > 4 ? 3 : min(1, articles.count) }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                HStack(spacing: 12) {
                    Image(systemName: "magnifyingglass").foregroundStyle(Palette.blue)
                    TextField("ニュースを検索", text: $search).font(.body).submitLabel(.search)
                        .accessibilityLabel("ニュースを検索")
                    if !search.isEmpty {
                        Button { search = "" } label: { Image(systemName: "xmark.circle.fill").frame(width: 44, height: 44) }
                            .accessibilityLabel("検索を消去")
                    }
                }.padding(.leading, 18).padding(.trailing, 64).frame(minHeight: 54)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22))
                    .overlay(RoundedRectangle(cornerRadius: 22).stroke(.white.opacity(0.9), lineWidth: 1))
                    .overlay(alignment: .bottomTrailing) {
                        HamsterCompanion().frame(width: 58, height: 65).offset(x: -7, y: 49)
                    }
                    .padding(.horizontal, 22).padding(.bottom, 16)
                if let edition = paper.edition {
                    Text(edition.day.replacingOccurrences(of: "-", with: "."))
                        .font(.subheadline.weight(.medium)).foregroundStyle(Palette.blue)
                        .padding(.horizontal, 22)
                }
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(NewsGenre.allCases) { item in
                            Button { genre = item; page = 0 } label: {
                                Text(item.rawValue).font(.body.weight(.semibold)).padding(.horizontal, 18).padding(.vertical, 11)
                                    .foregroundStyle(genre == item ? .white : Palette.blue)
                                    .background(genre == item ? Palette.blue : Color.white.opacity(0.85), in: Capsule())
                            }.buttonStyle(.plain).accessibilityAddTraits(genre == item ? .isSelected : [])
                        }
                    }.padding(.horizontal, 22)
                }
                if !articles.isEmpty {
                    if genre == .all && search.isEmpty {
                        HStack(spacing: 8) {
                            Image(systemName: "sparkles")
                            Text("見落としていた支援かも").font(.headline)
                            Spacer()
                            Button("条件を追加") { settings = true }.font(.subheadline.weight(.semibold))
                        }.foregroundStyle(Palette.blue).padding(.horizontal, 22)
                    }
                    VStack(spacing: 12) {
                        TabView(selection: $page) {
                            ForEach(Array(articles.prefix(featuredCount).enumerated()), id: \.element.id) { index, article in
                                NavigationLink { NewspaperArticleView(article: article) } label: {
                                    FeaturedNewsCard(article: article)
                                }.buttonStyle(.plain).padding(.horizontal, 22).tag(index)
                            }
                        }.tabViewStyle(.page(indexDisplayMode: .never)).frame(height: typeSize.isAccessibilitySize ? 450 : 300)
                        if featuredCount > 1 {
                            HStack(spacing: 7) {
                                ForEach(0..<featuredCount, id: \.self) { index in
                                    Capsule().fill(index == page ? Palette.blue : Palette.blue.opacity(0.15)).frame(width: index == page ? 22 : 7, height: 7)
                                }
                            }.accessibilityElement(children: .ignore).accessibilityLabel("\(featuredCount)件中\(page + 1)件目")
                        }
                    }
                    if articles.count > featuredCount {
                        VStack(alignment: .leading, spacing: 18) {
                            Text("おすすめ").font(.title2.bold())
                            VStack(spacing: 0) {
                                ForEach(Array(articles.dropFirst(featuredCount))) { article in
                                    NavigationLink { NewspaperArticleView(article: article) } label: {
                                        CompactNewsRow(article: article)
                                    }.buttonStyle(.plain)
                                    if article.id != articles.last?.id { Divider().padding(.vertical, 16) }
                                }
                            }
                        }.padding(.horizontal, 22)
                    }
                } else if paper.busy { ProgressView().frame(maxWidth: .infinity).padding(40) }
                else {
                    ContentUnavailableView("記事はまだありません", systemImage: genre.symbol)
                }
            }.padding(.top, 12).padding(.bottom, 28)
        }.background(Color(red: 0.97, green: 0.975, blue: 0.98))
            .navigationTitle("TO:ME").navigationBarTitleDisplayMode(.inline)
            .scrollDismissesKeyboard(.interactively)
            .onChange(of: search) { _, _ in page = 0 }
            .onChange(of: paper.edition?.headlines) { _, _ in page = 0 }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { settings = true } label: { Image(systemName: "slider.horizontal.3") }.accessibilityLabel("パーソナル設定")
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button("ロック画面に表示") { Task { await paper.startActivity() } }
                        Button("ロック画面の表示を終了") { Task { await paper.stopActivity() } }
                        Button("配信状況") { settings = true }
                    } label: { Image(systemName: "ellipsis") }.accessibilityLabel("朝刊のメニュー")
                }
            }
            .refreshable { await paper.prepare(force: true) }
            .sheet(isPresented: $settings) { NewspaperSettings() }
            .alert("ロック画面", isPresented: Binding(get: { paper.activityMessage != nil }, set: { if !$0 { paper.activityMessage = nil } })) {
                Button("OK") { paper.activityMessage = nil }
            } message: { Text(paper.activityMessage ?? "") }
    }
}

struct NewsArtwork: View {
    let article: NewspaperHeadline
    var large = false
    private var genre: NewsGenre { NewsGenre.classify(article) }
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                LinearGradient(colors: [Palette.sky, Palette.blue, Color(red: 0.04, green: 0.12, blue: 0.32)], startPoint: .topLeading, endPoint: .bottomTrailing)
                Circle().stroke(.white.opacity(0.14), lineWidth: large ? 30 : 12).frame(width: geometry.size.width * 0.85).offset(x: geometry.size.width * 0.40, y: -geometry.size.height * 0.22)
                Image(systemName: genre.symbol).font(.system(size: large ? 112 : 34, weight: .ultraLight))
                    .foregroundStyle(.white.opacity(large ? 0.3 : 0.85))
                    .position(x: geometry.size.width * (large ? 0.76 : 0.5), y: geometry.size.height * (large ? 0.32 : 0.5))
                if let url = article.imageURL, NewspaperFeed.allowed(url) {
                    AsyncImage(url: url) { image in image.resizable().scaledToFill() } placeholder: { Color.clear }
                        .frame(width: geometry.size.width, height: geometry.size.height).clipped()
                }
            }.clipped()
        }.accessibilityHidden(true)
    }
}

struct FeaturedNewsCard: View {
    let article: NewspaperHeadline
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            NewsArtwork(article: article, large: true)
            LinearGradient(colors: [.clear, .black.opacity(0.7)], startPoint: .top, endPoint: .bottom)
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text(article.support == nil ? NewsGenre.classify(article).rawValue : "使えるか確認").font(.body.weight(.semibold))
                        .padding(.horizontal, 14).padding(.vertical, 8).background(Palette.blue.opacity(0.9), in: Capsule())
                    Spacer()
                }
                Spacer(minLength: 20)
                Text(article.title).font(.title2.bold()).lineLimit(4).multilineTextAlignment(.leading)
                if let support = article.support { Text(support.origin).font(.subheadline.weight(.medium)).lineLimit(1) }
                HStack {
                    Text(article.source).lineLimit(1)
                    Spacer()
                    Image(systemName: "arrow.up.right")
                }.font(.body).foregroundStyle(.white.opacity(0.85))
            }.padding(24).foregroundStyle(.white)
        }.clipShape(RoundedRectangle(cornerRadius: 26))
            .overlay(RoundedRectangle(cornerRadius: 26).stroke(.white.opacity(0.45), lineWidth: 1))
    }
}

struct CompactNewsRow: View {
    let article: NewspaperHeadline
    var body: some View {
        HStack(alignment: .top, spacing: 15) {
            NewsArtwork(article: article).frame(width: 88, height: 96).clipShape(RoundedRectangle(cornerRadius: 16))
            VStack(alignment: .leading, spacing: 7) {
                Text(article.support == nil ? NewsGenre.classify(article).rawValue : "使えるか確認").font(.subheadline.weight(.medium)).foregroundStyle(Palette.blue)
                Text(article.title).font(.headline).foregroundStyle(Palette.ink).lineLimit(3).multilineTextAlignment(.leading)
                Text(article.source).font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
            }.frame(maxWidth: .infinity, alignment: .leading)
        }.contentShape(Rectangle())
    }
}

struct NewspaperArticleView: View {
    let article: NewspaperHeadline
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                Text(article.title).font(.system(.largeTitle, design: .serif).bold())
                Text(article.source).font(.body)
                if let date = article.publishedAt { Text(date.formatted(date: .abbreviated, time: .omitted)).font(.body) }
                else { Text(article.isGuide ? "制度ガイド" : "公開日未確認").font(.body).foregroundStyle(.secondary) }
                Divider()
                if let support = article.support {
                    Text("あなたに表示した理由").font(.headline)
                    Text(article.reason).font(.body)
                    Divider()
                    Text("受けられるかもしれない支援").font(.headline)
                    Text(support.benefit).font(.body)
                    Text("確認する条件").font(.headline)
                    Text(support.check).font(.body)
                    Text("次の一歩").font(.headline)
                    Text(support.action).font(.body)
                    Text("準備するもの").font(.headline)
                    Text(support.documents).font(.body)
                    Text("利用できると確定したわけではありません。条件・期限は必ず公式情報で確認してください。")
                        .font(.subheadline).foregroundStyle(.secondary)
                } else {
                    if !article.summary.isEmpty { Text(article.summary).font(.body).lineSpacing(6) }
                    DisclosureGroup("掲載理由") { Text(article.reason).font(.body) }
                }
                Link(destination: article.url) { Label("公式情報を確認", systemImage: "arrow.up.right.square") }.buttonStyle(SoftButtonStyle(primary: true))
            }.foregroundStyle(Palette.blue).padding(24).background(Palette.paper, in: RoundedRectangle(cornerRadius: 12)).padding(20)
        }.background { GlassBackdrop() }.navigationTitle("朝刊").navigationBarTitleDisplayMode(.inline)
    }
}

struct NewspaperSettings: View {
    @Environment(NewspaperStore.self) private var paper
    @Environment(\.dismiss) private var dismiss
    @State private var draft = NewspaperProfile()
    @State private var invalid = false
    var body: some View {
        NavigationStack {
            Form {
                Section("あなたについて") {
                    TextField("市区町村", text: $draft.region)
                    Picker("年齢", selection: $draft.age) {
                        Text("未設定").tag(nil as Int?)
                        ForEach(0...120, id: \.self) { Text("\($0)歳").tag(Optional($0)) }
                    }
                    if draft.age == nil { Picker("年齢層", selection: $draft.ageBand) { ForEach(NewspaperProfile.ages, id: \.self) { Text($0) } } }
                    TextField("大学（任意）", text: Binding(get: { draft.university ?? "" }, set: { draft.university = String($0.prefix(80)) }))
                    TextField("勤め先（任意）", text: Binding(get: { draft.employer ?? "" }, set: { draft.employer = String($0.prefix(80)) }))
                    Text("ニュースと封筒の候補選びに使用。氏名・番地・生年月日は不要です。設定は端末に保存され、いつでも変更できます。")
                        .font(.subheadline)
                }
                Section("気になること") {
                    ForEach(NewspaperProfile.topics, id: \.self) { topic in Toggle(topic, isOn: Binding(get: { draft.interests.contains(topic) }, set: { if $0 { draft.interests.insert(topic) } else { draft.interests.remove(topic) } })) }
                }
                Section("支援を見つける") {
                    ForEach(NewspaperProfile.supportChoices, id: \.id) { choice in
                        Toggle(choice.title, isOn: Binding(
                            get: { (draft.supportNeeds ?? []).contains(choice.id) },
                            set: { if $0 { draft.supportNeeds = (draft.supportNeeds ?? []).union([choice.id]) } else { draft.supportNeeds?.remove(choice.id) } }
                        ))
                    }
                    Text("ここで選んだことは、この端末で候補を並べ替えるために使います。申請資格の判定ではありません。")
                        .font(.subheadline)
                }
                DisclosureGroup("配信元") {
                    TextField("公式RSSのHTTPS URL", text: $draft.feedURL).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                    Button("芦屋市の公式RSSを使う") { draft.region = "兵庫県芦屋市"; draft.feedURL = "https://www.city.ashiya.lg.jp/shinchaku/shinchaku.xml" }
                    TextField("大学の公式RSS", text: Binding(get: { draft.universityFeed ?? "" }, set: { draft.universityFeed = $0 })).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                    TextField("勤め先の公式RSS", text: Binding(get: { draft.employerFeed ?? "" }, set: { draft.employerFeed = $0 })).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                }
                Section {
                    Toggle("公開情報を検索", isOn: Binding(get: { draft.searchEnabled ?? false }, set: { draft.searchEnabled = $0 }))
                    if draft.searchEnabled == true { Text("検索APIキーが必要です。地域・大学・勤め先を個別の検索語としてBraveに送信します。年齢は端末内で使用します。").font(.body) }
                    DisclosureGroup("選定・接続状況") { Text(paper.edition?.status ?? LocalDocumentAI.status).font(.body) }
                }
                Section("ポストの手触り") { Toggle("振動", isOn: $draft.haptics); Toggle("開封音", isOn: $draft.sound) }
                Section { NavigationLink("AI・検索とAPIキー") { SearchSettingsView() }; NavigationLink("ウィジェットとLive Activity") { WidgetGuideView() } }
                if invalid { Text("対応する公式サイトのHTTPS RSSを指定してください。").foregroundStyle(.red) }
            }.navigationTitle("朝刊の設定").navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("閉じる") { dismiss() } }
                    ToolbarItem(placement: .confirmationAction) { Button("保存") {
                        if draft.region != paper.profile.region && draft.feedURL == paper.profile.feedURL { draft.feedURL = "" }
                        if draft.university != paper.profile.university && draft.universityFeed == paper.profile.universityFeed { draft.universityFeed = nil }
                        if draft.employer != paper.profile.employer && draft.employerFeed == paper.profile.employerFeed { draft.employerFeed = nil }
                        guard [draft.feedURL, draft.universityFeed ?? "", draft.employerFeed ?? ""].allSatisfy({ $0.isEmpty || URL(string: $0).map(NewspaperFeed.allowed) == true }) else { invalid = true; return }
                        paper.configure(draft); Task { await paper.prepare() }; dismiss()
                    }.disabled(draft.region.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
                }
        }.onAppear { draft = paper.profile }
    }
}
