import SwiftUI
import UIKit

struct WatashiMark: View {
    var body: some View {
        // A folded letter whose lower fold becomes a small smile.
        GeometryReader { g in
            let w = g.size.width; let h = g.size.height
            ZStack {
                RoundedRectangle(cornerRadius: w * 0.22).stroke(lineWidth: w * 0.065)
                Path { p in
                    p.move(to: CGPoint(x: w * 0.16, y: h * 0.28))
                    p.addLine(to: CGPoint(x: w * 0.5, y: h * 0.55))
                    p.addLine(to: CGPoint(x: w * 0.84, y: h * 0.28))
                    p.move(to: CGPoint(x: w * 0.34, y: h * 0.72))
                    p.addQuadCurve(to: CGPoint(x: w * 0.66, y: h * 0.72), control: CGPoint(x: w * 0.5, y: h * 0.88))
                }.stroke(style: StrokeStyle(lineWidth: w * 0.065, lineCap: .round, lineJoin: .round))
            }
        }.aspectRatio(1.15, contentMode: .fit).accessibilityHidden(true)
    }
}

struct MorningView: View {
    @Environment(ReceiptStore.self) private var store
    let scan: () -> Void
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 12) {
                    WatashiMark().frame(width: 37, height: 33).foregroundStyle(Palette.blue)
                    Text("TO:ME").font(.title.bold())
                    Spacer()
                }.padding(.vertical, 24)
                Text(store.today.shortDate).font(.headline).foregroundStyle(Palette.muted)
                PaperDivider().padding(.top, 20)
                if store.receiptCount == 0 {
                    Text("今日の便はありません").font(.title3).padding(.vertical, 30)
                    Button("書類を取り込む", action: scan).buttonStyle(SoftButtonStyle(primary: true))
                }
                ForEach(store.receiptDocuments) { document in
                    DocumentReceiptRow(document: document); PaperDivider()
                }
                ForEach(store.receiptArticles) { article in
                    ArticleReceiptRow(article: article); PaperDivider()
                }
                ReceiptBarcode()
            }.padding(.horizontal, 24).padding(.bottom, 30)
                .background { PaperStock(tear: 1) }
                .padding(24).frame(maxWidth: 580).frame(maxWidth: .infinity)
        }
    }
}

struct DeliveryExperience: View {
    @Environment(ReceiptStore.self) private var store
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @State private var feed: CGFloat = 0
    @State private var ready = false
    @State private var detached = false
    @State private var progress: CGFloat = 0
    @State private var hint = false
    @State private var startedLeft = true
    @State private var lastHapticProgress: CGFloat = 0
    private let tearHaptic = UIImpactFeedbackGenerator(style: .heavy)
    @State private var finishTask: Task<Void, Never>?

    var body: some View {
        GeometryReader { geometry in
            let width = min(geometry.size.width - 48, 380)
            let feedHeight = max(160, geometry.size.height - 240)
            ZStack(alignment: .top) {
                ScrollView(showsIndicators: false) {
                    paper.frame(width: width - 18)
                        .rotationEffect(.degrees((startedLeft ? -1 : 1) * (detached ? 7 : Double(progress) * 5)), anchor: startedLeft ? .topTrailing : .topLeading)
                        .offset(x: detached ? (startedLeft ? -24 : 24) : 0, y: detached ? geometry.size.height : progress * 15)
                        .opacity(detached ? 0 : 1)
                        .padding(.bottom, 35)
                        .frame(maxWidth: .infinity)
                }
                .frame(height: feedHeight * feed, alignment: .top).clipped()
                .scrollDisabled(!ready || detached)
                .padding(.top, 92)

                HamsterAnimation(falling: detached)
                    .frame(width: 124, height: 269)
                    .offset(x: width / 2 - 42, y: 92 + feedHeight * feed - 14)
                    .opacity(reduceMotion && detached ? 0 : 1)

                RoundedRectangle(cornerRadius: 30)
                    .fill(LinearGradient(colors: [.white, Color(white: 0.93)], startPoint: .top, endPoint: .bottom))
                    .frame(width: width + 12, height: 106)
                    .overlay(alignment: .bottom) {
                        Capsule().fill(Color(white: 0.12)).frame(width: width - 6, height: 3)
                            .shadow(color: .black.opacity(0.35), radius: 3, y: 1).padding(.bottom, 10)
                    }
                    .overlay(RoundedRectangle(cornerRadius: 30).stroke(.white.opacity(0.8), lineWidth: 1))
                    .shadow(color: .black.opacity(0.25), radius: 23, y: 14)
                    .accessibilityHidden(true)

                if ready && !detached && progress == 0 {
                    Capsule().fill(.white.opacity(0.4)).frame(width: width - 24, height: 2)
                        .overlay(alignment: .leading) {
                            Circle().fill(.white).frame(width: 12, height: 12)
                                .shadow(color: .white, radius: 9).offset(x: hint ? width - 36 : 0)
                        }
                        .offset(y: 110).allowsHitTesting(false).accessibilityHidden(true)
                }
                // Separate tear band preserves scrolling of the long printed receipt.
                Color.clear.frame(width: width, height: 80).contentShape(Rectangle()).offset(y: 72)
                    .gesture(DragGesture(minimumDistance: 8)
                        .onChanged { value in
                            guard ready && !detached else { return }
                            if progress == 0 {
                                startedLeft = value.startLocation.x < width / 2
                                tearHaptic.prepare()
                            }
                            let next = min(0.95, max(abs(value.translation.width), max(0, value.translation.height)) / 120)
                            if next > lastHapticProgress + 0.07 {
                                tearHaptic.impactOccurred(intensity: 1)
                                lastHapticProgress = next
                            }
                            progress = next
                        }
                        .onEnded { value in
                            if max(abs(value.translation.width), value.translation.height) >= 94 { tear() }
                            else { withAnimation(.spring()) { progress = 0 }; lastHapticProgress = 0 }
                        })
                    .accessibilityLabel("TO:ME。上端をなぞってレシートをもぎる")
                    .accessibilityAddTraits(.isButton).accessibilityAction { tear() }
            }.frame(maxWidth: .infinity).padding(.top, 12)
        }
        .background(Palette.blue.ignoresSafeArea())
        .foregroundStyle(Palette.ink).statusBarHidden()
        .task {
            let light = UIImpactFeedbackGenerator(style: .light)
            light.prepare()
            do { try await Task.sleep(for: .milliseconds(100)) } catch { return }
            withAnimation(reduceMotion ? nil : .linear(duration: 6.0)) { feed = 1 }
            for _ in 0..<60 {
                guard !Task.isCancelled, scenePhase == .active else { break }
                light.impactOccurred(intensity: 0.45)
                do { try await Task.sleep(for: .milliseconds(100)) } catch { return }
            }
            guard !Task.isCancelled else { return }
            ready = true
            if !reduceMotion {
                withAnimation(.easeInOut(duration: 1.5).repeatForever(autoreverses: false)) { hint = true }
            }
        }
        .onDisappear { finishTask?.cancel() }
    }

    private var paper: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("TO:ME").font(.system(size: 34, weight: .heavy, design: .rounded))
                .tracking(3).frame(maxWidth: .infinity).padding(.top, 24).padding(.bottom, 16)
            PaperDivider()
            ForEach(store.receiptDocuments) { document in
                PrintSummary(category: document.isSample ? "書類・サンプル" : (document.documentKind ?? "書類"),
                             title: document.title,
                             summary: document.aiSummary ?? (document.nextAction.isEmpty ? document.issuer : document.nextAction),
                             deadline: ReceiptDeadline.compact(document.deadlineText))
                PaperDivider()
            }
            ForEach(store.receiptArticles) { article in
                PrintSummary(category: article.category.shortLabel + "・サンプル", title: article.title,
                             summary: article.summary,
                             deadline: article.deadlineDays.map { ReceiptDeadline.format(store.date(after: $0)) } ?? "")
                PaperDivider()
            }
            if store.receiptCount == 0 { Text("今日の便はありません").font(.headline).padding(.vertical, 24) }
            ReceiptBarcode()
        }
        .padding(.horizontal, 23).padding(.bottom, 26)
        .background { PaperStock(tear: progress).scaleEffect(x: startedLeft ? 1 : -1, y: 1) }
    }

    private func tear() {
        guard ready && !detached else { return }
        withAnimation(reduceMotion ? nil : .easeIn(duration: 0.55)) { progress = 1; detached = true }
        finishTask = Task { @MainActor in
            do { try await Task.sleep(for: .milliseconds(reduceMotion ? 50 : 1000)) } catch { return }
            store.openReceipt()
        }
    }
}

struct PrintSummary: View {
    let category: String
    let title: String
    let summary: String
    let deadline: String
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(category).font(.subheadline).foregroundStyle(Palette.blue)
            HStack(alignment: .top, spacing: 12) {
                Text(title).font(.headline).fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
                if !deadline.isEmpty { Text(deadline).font(.headline.monospacedDigit()).fixedSize() }
            }
            if !summary.isEmpty { Text(summary).font(.subheadline).foregroundStyle(Palette.muted).lineLimit(2) }
        }.frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 13)
    }
}

struct ArticleReceiptRow: View {
    @Environment(ReceiptStore.self) private var store
    let article: Article
    @State private var expanded = false

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(article.category.shortLabel).foregroundStyle(article.category.color)
                Spacer()
                Text(article.source.rawValue + "・サンプル").foregroundStyle(Palette.muted)
            }.font(.subheadline)
            HStack(alignment: .top) {
                Text(article.title).font(.title3.weight(.bold)).fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 8)
                if let days = article.deadlineDays { Text(ReceiptDeadline.format(store.date(after: days))).font(.headline.monospacedDigit()).fixedSize() }
            }
            Text(article.summary).font(.body).foregroundStyle(Palette.muted).lineSpacing(4).fixedSize(horizontal: false, vertical: true)
            HStack {
                Spacer(minLength: 0)
                if !article.steps.isEmpty {
                    Button { store.add(article) } label: {
                        Image(systemName: store.contains(article) ? "bookmark.fill" : "bookmark")
                            .font(.system(size: 20)).frame(width: 44, height: 44)
                    }.buttonStyle(.plain).foregroundStyle(Palette.blue)
                        .accessibilityLabel(store.contains(article) ? "保存済み" : article.title + "を保存")
                }
            }
            DisclosureGroup(isExpanded: $expanded) {
                VStack(alignment: .leading, spacing: 12) {
                    Text(article.reason)
                    Text(article.note)
                    Text("出典：\(article.publisher)（架空）")
                }.font(.body).foregroundStyle(Palette.muted).padding(.top, 10)
            } label: { Text("対象・必要書類").font(.subheadline) }
        }.padding(.vertical, 22)
    }
}

struct DocumentReceiptRow: View {
    @Environment(ReceiptStore.self) private var store
    let document: CapturedDocument
    @State private var expanded = false
    @State private var searchVisible = false

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label(document.isSample ? "読み取りサンプル" : "取り込んだ書類", systemImage: "doc.viewfinder")
                .font(.subheadline).foregroundStyle(Palette.blue)
            HStack(alignment: .top) {
                Text(document.title).font(.title3.weight(.bold)).fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 8)
                Text(ReceiptDeadline.compact(document.deadlineText)).font(.headline.monospacedDigit()).fixedSize()
            }
            if !document.nextAction.isEmpty { Text(document.nextAction).font(.body).lineSpacing(4).fixedSize(horizontal: false, vertical: true) }
            if document.deadlineText.isEmpty {
                Text("期限は原文を確認").font(.body).foregroundStyle(Palette.muted)
            }
            if !document.issuer.isEmpty { Text(document.issuer).font(.subheadline).foregroundStyle(Palette.muted) }
            if let summary = document.aiSummary, !summary.isEmpty {
                DisclosureGroup("AIの要約") { Text(summary).font(.body).padding(.top, 10) }.font(.body)
            }
            if let required = document.requiredDocuments, !required.isEmpty {
                DisclosureGroup("必要書類") { Text(required).font(.body).padding(.top, 10) }.font(.body)
            }
            DisclosureGroup(isExpanded: $expanded) {
                Text(document.rawText).font(.body).textSelection(.enabled).padding(.top, 12)
            } label: { Text("原文").font(.subheadline) }
            ForEach(document.officialSources ?? []) { source in
                DisclosureGroup("公式情報：" + source.title) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text(source.summary)
                        if !source.requiredDocuments.isEmpty { Text("必要書類：" + source.requiredDocuments) }
                        if !source.deadline.isEmpty { Text("期限：" + source.deadline) }
                        Link("出典を開く", destination: source.url)
                        ForEach(source.applicationLinks, id: \.absoluteString) { url in Link("申請・様式のリンク", destination: url) }
                        Text("確認日：" + source.fetchedAt.shortDate)
                    }.font(.body).padding(.top, 10)
                }.font(.body)
            }
            Button("公式の申請先を調べる") { searchVisible = true }.font(.body)
        }.padding(.vertical, 22)
            .sheet(isPresented: $searchVisible) {
                OfficialSearchView(onSelect: { source in
                    store.attachOfficialSource(source, documentID: document.id)
                }, query: document.publicSearchQuery ?? document.issuer + " " + (document.documentKind ?? document.title) + " 申請")
            }
    }
}
