import SwiftUI

struct InboxView: View {
    @Environment(ReceiptStore.self) private var store
    let scan: () -> Void
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                VStack(alignment: .leading, spacing: 10) {
                    Text(Date.now.formatted(.dateTime.locale(Locale(identifier: "ja_JP")).month().day().weekday())).font(.subheadline).foregroundStyle(.secondary)
                    Text("届いた紙を、\n次の一歩に。").font(.largeTitle.bold())
                    Text("気づくのはウィジェット。\n確かめるのは、ここで。").font(.body).foregroundStyle(.secondary)
                }.padding(.vertical, 12)
                if let document = store.attentionDocuments.first {
                    NavigationLink { DocumentDetail(documentID: document.id) } label: { DocumentCard(document: document) }.buttonStyle(.plain)
                } else {
                    VStack(alignment: .leading, spacing: 20) {
                        Image(systemName: "envelope.open").font(.largeTitle).foregroundStyle(Palette.blue)
                        Text(store.documents.isEmpty ? "最初の書類を取り込もう" : "確認待ちの書類はありません").font(.title3.bold())
                        Text("期限と必要な準備を、原文と一緒に整理します。").foregroundStyle(.secondary)
                        Button(action: scan) { Label("書類を取り込む", systemImage: "plus.viewfinder") }.buttonStyle(SoftButtonStyle(primary: true))
                    }.padding(24).softSurface()
                }
                NavigationLink { WidgetGuideView() } label: {
                    HStack(spacing: 16) {
                        Image(systemName: "rectangle.on.rectangle").font(.title2)
                        VStack(alignment: .leading, spacing: 5) { Text("次の一歩を、画面に。").font(.headline); Text("ウィジェットを追加する").font(.body).foregroundStyle(.secondary) }
                        Spacer(); Image(systemName: "chevron.right")
                    }.padding(22).softSurface()
                }.buttonStyle(.plain)
                if store.documents.filter({ !$0.isHandled }).count > 1 {
                    Text("ほかの確認待ち").font(.headline)
                    ForEach(store.attentionDocuments.dropFirst()) { document in
                        NavigationLink { DocumentDetail(documentID: document.id) } label: { DocumentCard(document: document) }.buttonStyle(.plain)
                    }
                }
            }.padding(24)
        }.background { GlassBackdrop() }.navigationTitle("TO:ME").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { NavigationLink { AppSettingsView() } label: { Image(systemName: "slider.horizontal.3") }.accessibilityLabel("設定") } }
    }
}

struct DocumentCard: View {
    let document: CapturedDocument
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label(document.isSample ? "サンプル" : "あなた宛の書類", systemImage: "doc.text").foregroundStyle(Palette.blue)
                Spacer()
                Text(document.deadlineText.isEmpty ? "期限要確認" : ReceiptDeadline.compact(document.deadlineText)).fontWeight(.semibold)
            }.font(.subheadline)
            Text(document.title).font(.title3.bold()).lineLimit(2)
            Text(document.suggestedAction ?? (document.nextAction.isEmpty ? "原文から次の行動を確認しましょう。" : document.nextAction)).font(.body).foregroundStyle(.secondary).lineLimit(2)
            HStack { Text("原文と準備を確認"); Spacer(); Image(systemName: "arrow.up.right") }.font(.body.weight(.medium)).foregroundStyle(Palette.blue)
        }.padding(24).softSurface()
    }
}

struct LibraryView: View {
    @Environment(ReceiptStore.self) private var store
    @State private var search = ""
    var body: some View {
        List {
            if store.documents.isEmpty {
                VStack(spacing: 12) {
                    HamsterCompanion().frame(width: 110, height: 120)
                    Text("書類はまだありません").font(.headline)
                }.frame(maxWidth: .infinity).padding(24)
            }
            ForEach(store.documents.filter { search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) || $0.issuer.localizedCaseInsensitiveContains(search) }) { document in
                NavigationLink { DocumentDetail(documentID: document.id) } label: {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(document.title).font(.headline)
                        Text(document.isHandled ? "対応済み" : (document.deadlineText.isEmpty ? "期限要確認" : document.deadlineText)).font(.body).foregroundStyle(.secondary)
                    }.padding(.vertical, 8)
                }
            }
        }.searchable(text: $search, prompt: "書類名・発行元").navigationTitle("書類")
    }
}

struct DocumentDetail: View {
    @Environment(ReceiptStore.self) private var store
    let documentID: UUID
    @State private var edit = false
    @State private var search = false
    private var document: CapturedDocument? { store.documents.first { $0.id == documentID } }
    var body: some View {
        Group {
            if let document {
                ScrollView {
                    VStack(alignment: .leading, spacing: 24) {
                        Text(document.title).font(.largeTitle.bold())
                        if document.isSample { Label("動作確認用の架空の書類", systemImage: "testtube.2").foregroundStyle(.secondary) }
                        Text(document.issuer).foregroundStyle(.secondary)
                        ProcedureSummary(document: document)
                        NavigationLink { EvidenceView(document: document) } label: { Label("原本", systemImage: "doc.text.magnifyingglass") }.buttonStyle(SoftButtonStyle())
                        Button { edit = true } label: { Label("確認・再調査", systemImage: "arrow.clockwise") }.buttonStyle(SoftButtonStyle(primary: true))
                        Button(document.isHandled ? "未対応に戻す" : "対応済みにする") { store.toggleHandled(documentID) }.buttonStyle(SoftButtonStyle())
                        DisclosureGroup("解析の状態") { Text(document.analysisStatus ?? "文字認識で整理しました。"); Text(document.importanceStatus ?? "重要箇所の判定は未実行です。") }
                    }.padding(24)
                }.background { GlassBackdrop() }
                .sheet(isPresented: $edit) { DocumentReview(document: document, onSaved: {}) }
                .sheet(isPresented: $search) { OfficialSearchView(onSelect: { store.attachOfficialSource($0, documentID: documentID) }, query: document.publicSearchQuery ?? "", documentText: document.rawText) }
            } else { ContentUnavailableView("書類が見つかりません", systemImage: "doc.questionmark") }
        }.navigationTitle("書類の詳細").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("確認・編集") { edit = true } } }
    }
    private func section(_ title: String, text: String, symbol: String) -> some View {
        VStack(alignment: .leading, spacing: 12) { Label(title, systemImage: symbol).font(.headline).foregroundStyle(Palette.blue); Text(text).font(.body).textSelection(.enabled) }.frame(maxWidth: .infinity, alignment: .leading).padding(22).softSurface()
    }
}

struct WidgetGuideView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                Text("朝刊").font(.largeTitle.bold())
                VStack(alignment: .leading, spacing: 12) { Label("朝刊", systemImage: "newspaper").font(.headline); Text("あなたのまちの朝刊").font(.title2.bold()); Text("ホーム画面にも、ロック画面にも朝刊の見出しを。").foregroundStyle(.secondary) }.frame(maxWidth: .infinity, alignment: .leading).padding(24).softSurface()
                Text("表示イメージ").font(.body).foregroundStyle(.secondary)
                Text("ホーム画面").font(.title2.bold())
                Text("ホーム画面の余白を長押し → 編集 → ウィジェットを追加 →「TO:ME」を選びます。")
                Text("ロック画面").font(.title2.bold())
                Text("朝刊を受け取り、メニューから「ロック画面に表示」を選びます。Live Activityとして見出しが表示されます。終了ボタンで消せます。")
                Text("毎朝アプリを開くと朝刊を更新します。アプリを開かず毎朝Live Activityを自動開始する機能は未対応です。表示時間やウィジェットの更新時刻はiOSが管理します。iOS 26ではホーム画面のクリア表示も利用できます。").foregroundStyle(.secondary)
            }.padding(24)
        }.background { GlassBackdrop() }.navigationTitle("ウィジェット").navigationBarTitleDisplayMode(.inline)
    }
}

struct AppSettingsView: View {
    var body: some View {
        Form {
            Section { NavigationLink("AI・検索の接続") { SearchSettingsView() }; NavigationLink("ウィジェットの追加方法") { WidgetGuideView() } }
            Section("Apple Intelligence") { Text(LocalDocumentAI.status); Text("利用できない場合も写真の文字認識・手動確認・ウィジェットを使えます。") }
            Section("プライバシー") { Text("原本画像は端末内に保存します。ウィジェットとLive Activityには取り込んだ書類ではなく、公開情報から作った朝刊を表示します。") }
        }.navigationTitle("設定")
    }
}
