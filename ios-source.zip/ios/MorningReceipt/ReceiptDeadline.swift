import Foundation

enum ReceiptDeadline {
    /// Only explicit Gregorian dates become sortable deadlines. Never guess a year.
    static func date(_ text: String) -> Date? {
        let value = DocumentExtractor.normalize(text)
        guard let regex = try? NSRegularExpression(pattern: #"(20\d{2})[年/.-]\s*(\d{1,2})[月/.-]\s*(\d{1,2})日?"#),
              let match = regex.firstMatch(in: value, range: NSRange(value.startIndex..., in: value)) else { return nil }
        let parts = (1...3).compactMap { index in Range(match.range(at: index), in: value).flatMap { Int(value[$0]) } }
        guard parts.count == 3 else { return nil }
        let calendar = Calendar(identifier: .gregorian)
        let components = DateComponents(year: parts[0], month: parts[1], day: parts[2])
        guard let date = calendar.date(from: components), calendar.dateComponents([.year, .month, .day], from: date) == components else { return nil }
        return date
    }
    static func format(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.locale = Locale(identifier: "ja_JP")
        formatter.dateFormat = "M/d"
        return formatter.string(from: date) + "〆"
    }
    static func compact(_ text: String) -> String {
        let normalized = DocumentExtractor.normalize(text)
        let pattern = #"(?:\d{4}[年/.-])?(\d{1,2})[月/.-](\d{1,2})日?"#
        guard let regex = try? NSRegularExpression(pattern: pattern),
              let match = regex.firstMatch(in: normalized, range: NSRange(normalized.startIndex..., in: normalized)),
              let mr = Range(match.range(at: 1), in: normalized), let dr = Range(match.range(at: 2), in: normalized),
              let month = Int(normalized[mr]), let day = Int(normalized[dr]),
              (1...12).contains(month), (1...31).contains(day) else { return text.isEmpty ? "" : "要確認" }
        return "\(month)/\(day)〆"
    }
}
