import SwiftUI

struct SearchSettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var key = ""
    @State private var jevKey = ""
    @AppStorage(JevImportance.automaticKey) private var automaticJev = false
    @State private var message: String?
    @State private var connectionBusy = false
    @State private var connectionMessage: String?
    var body: some View {
        Form {
            Section("端末内AI") { Text(LocalDocumentAI.status) }
            DisclosureGroup("APIキーの取得手順") {
                Text("朝刊の公式RSSにはキーも契約も不要です。以下は書類の重要箇所判定・公式サイト検索を追加する場合の設定です。")
                Text("Jev / TypeSafe：公式コンソールでサインイン → APIキーを作成 → この画面に貼り付けて保存。公式APIはTypeSafeの api.typesafe.ai を使います。")
                Text("Brave：設定ページで登録・メール認証 → PlansでSearchプランを有効化 → API Keysでキーを作成 → この画面に保存。カード登録や課金条件を確認し、Usage Limitsで上限を設定してください。")
                Text("キーはチャットに送らないでください。契約・支払いはご自身で行ってください。公開アプリでは運営側のサーバーでキーを管理する設計が別途必要です。")
            }
            Section("重要箇所の判定 · Jev / TypeSafe公式") {
                Text(JevCredential.read().isEmpty ? "未設定 · 原文の確認は利用できます" : "キー設定済み · 通信時に認証を確認します")
                Link(destination: URL(string: "https://console.typesafe.ai/")!) {
                    Label("TypeSafe公式コンソールでキーを取得", systemImage: "key.fill")
                }.buttonStyle(.borderedProminent)
                Link(destination: URL(string: "https://docs.typesafe.ai/introduction/quickstart")!) {
                    Label("公式クイックスタートを読む", systemImage: "book.closed")
                }
                SecureField("TypeSafe APIキー", text: $jevKey).textInputAutocapitalization(.never).autocorrectionDisabled()
                Button("この端末にキーを保存") {
                    do { try JevCredential.save(jevKey); jevKey = ""; message = "Jevキーを保存しました。" }
                    catch { message = error.localizedDescription }
                }.disabled(jevKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                Button {
                    connectionBusy = true
                    connectionMessage = nil
                    Task {
                        do {
                            try await JevImportance.checkConnection()
                            connectionMessage = "TypeSafe / Jevに接続できました。"
                        } catch {
                            connectionMessage = error.localizedDescription
                        }
                        connectionBusy = false
                    }
                } label: {
                    Label(connectionBusy ? "接続を確認中…" : "接続テスト（サンプル文章）", systemImage: "checkmark.shield")
                }.disabled(connectionBusy || JevCredential.read().isEmpty)
                if let connectionMessage { Text(connectionMessage).foregroundStyle(connectionMessage.contains("接続できました") ? .green : .red) }
                Text("写真は端末内で読み取ります。手動判定では、選んだ文章だけをJevに送ります。")
                Toggle("取り込み時に重要箇所の候補を自動送信", isOn: $automaticJev)
                Text("オンにすると、今後取り込む書類から期限・必要書類・申請方法など最大12行をJevへ送ります。個人情報の除外は完全ではありません。機密書類を扱う場合はオフにして手動で選んでください。初期設定はオフです。")
            }
            Section("公式サイト検索") {
                SecureField("Brave Search APIキー", text: $key).textInputAutocapitalization(.never).autocorrectionDisabled()
                Button("キーを保存") {
                    do { try SearchCredential.save(key); dismiss() }
                    catch { message = error.localizedDescription }
                }.disabled(key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                Text("キーはこの端末のKeychainに保存します。検索APIの利用料金・利用枠はご自身の契約に従います。")
                Text(SearchCredential.read().isEmpty ? "検索APIは未設定です。" : "検索APIは設定済みです。")
                Link("Brave Searchの設定ページ", destination: URL(string: "https://api-dashboard.search.brave.com/")!)
            }
            DisclosureGroup("プライバシー・対応サイト") {
                Text("画像とApple Intelligenceの要約処理は端末内に留まります。TypeSafe / Jevには選択した文章、Brave Searchには制度名・発行元を送信します。公式サイトの取得にも通信が発生します。キーはこの端末のKeychainに保存します。")
                Text("現在は政府・自治体・大学の .go.jp / .lg.jp / .ac.jp を対象とします。企業、その他の公式ドメイン、外部申請サービスは対象外です。")
            }
            if let message { Text(message).foregroundStyle(.red) }
        }.font(.body).navigationTitle("AI・検索設定").navigationBarTitleDisplayMode(.inline)
    }
}

struct OfficialSearchView: View {
    @Environment(\.dismiss) private var dismiss
    let onSelect: (OfficialSource) -> Void
    @State var query: String
    var documentText: String = ""
    @State private var candidates: [OfficialSearch.Candidate] = []
    @State private var selected: OfficialSource?
    @State private var busy = false
    @State private var error: String?
    @State private var task: Task<Void, Never>?
    @State private var matched = false
    var body: some View {
        NavigationStack {
            List {
                if !OfficialSearchPolicy.documentURLs(documentText).isEmpty {
                    Section("書類に記載された公式URL · 検索キー不要") {
                        ForEach(OfficialSearchPolicy.documentURLs(documentText), id: \.absoluteString) { url in
                            Button(url.absoluteString) {
                                busy = true; error = nil; selected = nil; matched = false
                                task = Task {
                                    do { selected = try await OfficialSearch.inspect(.init(title: "書類に記載された公式ページ", url: url.absoluteString, description: nil)) }
                                    catch { self.error = error.localizedDescription }
                                    busy = false
                                }
                            }.disabled(busy)
                        }
                    }
                }
                Section("公開情報だけで検索") {
                    TextField("例：東京都 授業料 支援 申請", text: $query, axis: .vertical).font(.body)
                    Text("氏名・住所・番号を含めないでください。このキーワードをBrave Searchへ送ります。")
                    Button("公式サイトを検索") {
                        busy = true; error = nil; candidates = []; selected = nil; matched = false
                        task = Task {
                            do {
                                candidates = try await OfficialSearch.search(query)
                                // Fetch the first official-domain candidate and organize it locally;
                                // retain other candidates so the user can check institution/year.
                                if let first = candidates.first { selected = try await OfficialSearch.inspect(first) }
                            }
                            catch { if !Task.isCancelled { self.error = error.localizedDescription } }
                            busy = false
                        }
                    }.disabled(busy || query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    NavigationLink("検索APIの設定") { SearchSettingsView() }
                }
                if busy { ProgressView("検索・ページを確認中") }
                if let error { Text(error).foregroundStyle(.red) }
                if let selected {
                    Section("取得した公式ページ") {
                        Text(selected.summary)
                        if !selected.requiredDocuments.isEmpty { Text("必要書類：" + selected.requiredDocuments) }
                        if !selected.deadline.isEmpty { Text("期限：" + selected.deadline) }
                        Link(selected.title, destination: selected.url)
                        Text("確認日：" + selected.fetchedAt.shortDate)
                        Text("同名制度・年度・対象地域が一致するか確認してください。書類の期限は自動で上書きしません。")
                        ForEach(selected.applicationLinks, id: \.absoluteString) { url in
                            Link("ページ内の申請・様式リンク", destination: url)
                        }
                        if selected.applicationLinks.isEmpty { Text("申請フォームは特定できませんでした。上の公式ページを確認してください。") }
                        Toggle("発行元・制度・対象年度が書類と一致することを確認しました", isOn: $matched)
                        Button("確認した出典を保存") { onSelect(selected); dismiss() }.disabled(!matched)
                    }
                }
                Section("公式ドメインの候補") {
                    ForEach(candidates) { candidate in
                        Button {
                            busy = true; error = nil; selected = nil; matched = false
                            task = Task {
                                do { selected = try await OfficialSearch.inspect(candidate) }
                                catch { if !Task.isCancelled { self.error = error.localizedDescription } }
                                busy = false
                            }
                        } label: {
                            VStack(alignment: .leading, spacing: 7) {
                                Text(candidate.title).font(.headline)
                                Text(URL(string: candidate.url)?.host ?? "").font(.body).foregroundStyle(Palette.muted)
                            }
                        }.disabled(busy)
                    }
                }
            }.font(.body).navigationTitle("公式情報を調べる").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("閉じる") { task?.cancel(); dismiss() } } }
        }.onDisappear { task?.cancel() }
    }
}
