import SwiftUI

struct ProfileView: View {
    @Environment(ReceiptStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    let replay: () -> Void
    @State private var draft = Profile()
    var body: some View {
        NavigationStack {
            Form {
                Section("プロフィール") { TextField("呼び名", text: $draft.name) }
                Section("サンプル情報") {
                    Toggle("大学", isOn: $draft.university)
                    Toggle("自治体", isOn: $draft.city)
                    Toggle("勤務先", isOn: $draft.company)
                }
                Section {
                    NavigationLink("AI・検索設定") { SearchSettingsView() }
                    Button("レシートを再発行") { store.updateProfile(draft); replay(); dismiss() }
                    DisclosureGroup("デモについて") {
                        Text("書類の読み取りと端末への保存ができます。ニュースは架空のサンプルです。自動配信・通知は未実装です。").font(.body)
                    }
                }
            }.font(.body).navigationTitle("設定").navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("閉じる") { dismiss() } }
                    ToolbarItem(placement: .confirmationAction) { Button("保存") { store.updateProfile(draft); dismiss() } }
                }
                .onAppear { draft = store.profile }
        }.tint(Palette.blue)
    }
}
