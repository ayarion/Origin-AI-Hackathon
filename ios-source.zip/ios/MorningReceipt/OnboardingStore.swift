import Foundation
import Observation

enum Stage: Int, Codable, CaseIterable {
    case introduction, age, region, affiliation, permissions, welcome, finished
    var progress: Int { switch self { case .introduction: 0; case .age: 1; case .region: 2; case .affiliation: 3; case .permissions: 4; case .welcome, .finished: 5 } }
}

enum Affiliation: String, Codable, CaseIterable, Identifiable {
    case school = "学校に通っている", work = "働いている", both = "両方", other = "その他"
    var id: String { rawValue }
    var hasSchool: Bool { self == .school || self == .both }
    var hasWork: Bool { self == .work || self == .both }
}

struct OnboardingRecord: Codable, Equatable {
    var stage: Stage = .introduction
    var age = ""
    var region = ""
    var affiliation: Affiliation? = nil
    var school = ""
    var schoolKind = ""
    var employer = ""
    var notificationChoice = ""
    var ageConfirmedAt: Date? = nil
    var welcomeCompleted = false
    var validAge: Int? { Int(age).flatMap { (0...120).contains($0) ? $0 : nil } }
    var canContinue: Bool {
        switch stage {
        case .age: validAge != nil
        case .region: !region.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        case .affiliation: affiliation != nil
        default: true
        }
    }
    func profile(from existing: NewspaperProfile) -> NewspaperProfile {
        var result = existing
        result.age = validAge
        result.ageBand = "指定しない"
        result.region = region
        result.university = affiliation?.hasSchool == true && !school.isEmpty ? school : nil
        result.employer = affiliation?.hasWork == true && !employer.isEmpty ? employer : nil
        result.studentYear = result.university == nil ? nil : (schoolKind.contains("大学") ? "大学生" : "学生")
        if region != existing.region { result.feedURL = "" }
        if region == "兵庫県芦屋市" { result.feedURL = "https://www.city.ashiya.lg.jp/shinchaku/shinchaku.xml" }
        if result.university != existing.university { result.universityFeed = nil }
        if result.university == "甲南大学" { result.universityFeed = "https://www.konan-u.ac.jp/news/sas/feed" }
        if result.employer != existing.employer { result.employerFeed = nil }
        return result
    }
}

@Observable @MainActor final class OnboardingStore {
    var record = OnboardingRecord()
    var error: String?
    var enterHomeDirectly = false
    private let defaults: UserDefaults
    private var loaded = false
    static let key = "tome.onboarding.v1"
    init(defaults: UserDefaults? = nil) {
        if let defaults { self.defaults = defaults }
        else if FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: WidgetBridge.group) != nil,
                let shared = UserDefaults(suiteName: WidgetBridge.group) { self.defaults = shared }
        else { self.defaults = .standard }
        reload()
    }
    func reload() {
        do {
            if let data = defaults.data(forKey: Self.key) { record = try JSONDecoder().decode(OnboardingRecord.self, from: data) }
            loaded = true
            error = nil
        } catch { self.error = "設定を読み込めませんでした。保存済みデータは変更していません。" }
    }
    @discardableResult func save(_ value: OnboardingRecord) -> Bool {
        guard loaded else { error = "設定を読み込めませんでした。保存済みデータは変更していません。"; return false }
        do {
            let data = try JSONEncoder().encode(value)
            defaults.set(data, forKey: Self.key)
            guard defaults.data(forKey: Self.key) == data else { throw CocoaError(.fileWriteUnknown) }
            record = value
            return true
        } catch { self.error = "設定を保存できませんでした。もう一度お試しください。"; return false }
    }
    func finish(profile: NewspaperProfile) -> Bool {
        do {
            let data = try JSONEncoder().encode(profile)
            defaults.set(data, forKey: "tome.paper.profile")
            guard defaults.data(forKey: "tome.paper.profile") == data else { throw CocoaError(.fileWriteUnknown) }
            var value = record; value.stage = .finished; value.welcomeCompleted = true
            guard save(value) else { return false }
            enterHomeDirectly = true
            return true
        } catch { self.error = "設定を保存できませんでした。もう一度お試しください。"; return false }
    }
}

struct SchoolOption: Codable, Identifiable, Sendable {
    let id: String
    let name: String
    let region: String
    let kind: String
}

actor OnboardingCatalog {
    static let shared = OnboardingCatalog()
    private var postal: [String: [String]]?
    private var schools: [SchoolOption]?
    private func resource<T: Decodable>(_ name: String, as: T.Type) throws -> T {
        guard let url = Bundle.main.url(forResource: name, withExtension: "json") ?? Bundle.main.url(forResource: name, withExtension: "json", subdirectory: "OnboardingData") else { throw CocoaError(.fileNoSuchFile) }
        return try JSONDecoder().decode(T.self, from: Data(contentsOf: url))
    }
    func regions(postcode: String) throws -> [String] {
        if postal == nil { postal = try resource("PostalRegions", as: [String: [String]].self) }
        return postal?[postcode] ?? []
    }
    func regions(matching text: String) throws -> [String] {
        if postal == nil { postal = try resource("PostalRegions", as: [String: [String]].self) }
        let query = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return [] }
        return Array(Set((postal ?? [:]).values.flatMap { $0 })).filter { $0.contains(query) }.sorted().prefix(30).map { $0 }
    }
    func schools(matching text: String) throws -> [SchoolOption] {
        if schools == nil { schools = try resource("SchoolDirectory", as: [SchoolOption].self) }
        let query = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return [] }
        return Array((schools ?? []).filter { $0.name.localizedStandardContains(query) }.prefix(20))
    }
    static func digits(_ value: String) -> String {
        value.compactMap { $0.wholeNumberValue }.map(String.init).joined()
    }
}
