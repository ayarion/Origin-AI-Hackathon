import Foundation
import Observation
import WidgetKit
import ActivityKit

struct NewspaperProfile: Codable, Equatable {
    var region = "兵庫県芦屋市"
    var ageBand = "18〜29歳"
    var studentYear: String? = "大学3回生"
    var interests: Set<String> = []
    var feedURL = "https://www.city.ashiya.lg.jp/shinchaku/shinchaku.xml"
    var haptics = true
    var sound = false
    var age: Int? = nil
    var university: String? = nil
    var employer: String? = nil
    var universityFeed: String? = nil
    var employerFeed: String? = nil
    var searchEnabled: Bool? = nil
    var supportNeeds: Set<String>? = nil
    static let ages = ["指定しない", "18歳未満", "18〜29歳", "30〜49歳", "50〜64歳", "65歳以上"]
    static let topics = ["子育て", "学び", "仕事", "暮らし", "健康", "お出かけ"]
    static let supportChoices: [(id: String, title: String)] = [("support-pension-student", "年金の学生手続きが未確認"), ("support-jasso-grant", "学費の負担が気になる"), ("support-jasso-emergency", "家計が急に変わった")]
}

enum NewspaperCuration {
    static var guides: [NewspaperHeadline] { guides(for: NewspaperProfile()) }
    static func day(_ date: Date = .now) -> String {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(identifier: "Asia/Tokyo")!
        // Each edition runs from 06:00 JST to the following morning.
        let c = calendar.dateComponents([.year, .month, .day], from: date.addingTimeInterval(-6 * 3600))
        return String(format: "%04d-%02d-%02d", c.year!, c.month!, c.day!)
    }
    static func keywords(_ profile: NewspaperProfile) -> [String] {
        var values = Array(profile.interests)
        values += [profile.university, profile.employer].compactMap { $0 }.filter { !$0.isEmpty }
        if !(profile.university ?? "").isEmpty { values += ["大学", "学生", "奨学金", "インターン"] }
        if !(profile.employer ?? "").isEmpty { values += ["仕事", "職業", "働き方"] }
        if profile.studentYear?.contains("大学") == true { values += ["大学", "学生", "奨学金", "インターン", "就職"] }
        switch profile.effectiveAgeBand {
        case "18歳未満", "18〜29歳": values += ["学び", "奨学金", "学生", "就職"]
        case "30〜49歳": values += ["仕事", "職業", "住まい"]
        case "50〜64歳": values += ["健康", "仕事", "介護"]
        case "65歳以上": values += ["健康", "高齢", "介護", "年金"]
        default: break
        }
        return Array(Set(values))
    }
    static func score(_ item: NewspaperHeadline, profile: NewspaperProfile) -> Int {
        let text = item.title + item.summary + item.source + item.tags.joined()
        let relevance = keywords(profile).reduce(0) { $0 + (text.contains($1) ? 3 : 0) }
        let urgent = ["締切", "申請", "給付", "支援", "募集"].contains(where: text.contains) ? 4 : 0
        let businessOnly = ["競争入札", "商工業者", "配置予定技術者"].contains(where: text.contains) ? 20 : 0
        let specificCircumstances = item.title.contains("災害救助法") ? 12 : 0
        let supportBoost = item.support == nil ? 0 : 20 + ((profile.supportNeeds ?? []).contains(item.id) ? 25 : 0)
        return relevance + urgent + supportBoost + (item.isGuide ? 0 : 2) - businessOnly - specificCircumstances
    }
    static func select(_ input: [NewspaperHeadline], profile: NewspaperProfile) -> [NewspaperHeadline] {
        var seen: Set<String> = []
        let unique = input.filter {
            guard seen.insert($0.id).inserted, !["競争入札", "配置予定技術者"].contains(where: $0.title.contains) else { return false }
            if !profile.interests.contains("子育て"), ["子育て", "幼稚園", "こども園", "入園", "児童手当"].contains(where: $0.title.contains) { return false }
            if profile.effectiveAgeBand != "65歳以上", !profile.interests.contains("健康"), $0.title.contains("高齢者") { return false }
            return true
        }
        var sourceCounts: [String: Int] = [:]
        return Array(unique.sorted {
            let a = score($0, profile: profile), b = score($1, profile: profile)
            if a != b { return a > b }
            return ($0.publishedAt ?? .distantPast) > ($1.publishedAt ?? .distantPast)
        }.filter { item in
            let count = sourceCounts[item.source, default: 0]
            sourceCounts[item.source] = count + 1
            return count < 6
        }.prefix(18)).map { item in
            var value = item
            let matches = keywords(profile).filter { (item.title + item.summary + item.source + item.tags.joined()).contains($0) }
            value.reason = item.support == nil ? (matches.isEmpty ? (item.isGuide ? "全国向けの制度・暮らしの案内" : "設定した地域の公式配信") : "年齢層・関心との関連：" + Array(Set(matches)).sorted().joined(separator: "・")) : item.reason
            return value
        }
    }
    // Editorial guides, explicitly not newly published news or eligibility decisions.
    static func guides(for profile: NewspaperProfile) -> [NewspaperHeadline] {
        var result: [NewspaperHeadline] = []
        let student = profile.studentYear?.contains("大学") == true || !(profile.university ?? "").isEmpty
        if student && (profile.age.map { $0 >= 20 } ?? (profile.effectiveAgeBand != "18歳未満")) {
            result.append(.init(id: "support-pension-student", title: "学生なら、国民年金の納付を猶予できるかも", summary: "20歳以上の学生向け。未納のままにせず、学生納付特例を確認。", source: "日本年金機構", url: URL(string: "https://www.nenkin.go.jp/tokusetsu/gakusei.html")!, tags: ["支援", "学生", "年金"], reason: "20歳以上の大学生に関係。加入状況・本人所得は未確認です。", isGuide: true, support: .init(benefit: "在学中の国民年金保険料の納付を猶予。免除ではありません。", check: "国民年金の加入状況、本人所得、在学状況を確認。", action: "マイナポータルから申請、または市区町村・年金事務所へ。", documents: "学生証のコピーまたは在学証明書など。", origin: "大学の掲示板以外｜国の制度")))
            result.append(.init(id: "support-jasso-grant", title: "返還不要の給付奨学金・授業料減免を確認", summary: "在学中でも申込み可能。家計や多子世帯などの条件を確認。", source: "日本学生支援機構", url: URL(string: "https://www.jasso.go.jp/shogakukin/moshikomi/zaigaku/yotei.html")!, tags: ["支援", "学生", "奨学金"], reason: "大学に在学中のため。家計・資産・学業等の条件は未確認です。", isGuide: true, support: .init(benefit: "条件により返還不要の給付奨学金や授業料等の減免。", check: "本人と生計維持者の家計・資産、多子世帯の条件、学校の募集時期。", action: "甲南大学の奨学金窓口に在学採用を相談。", documents: "申込時の指定書類は学校の案内で確認。", origin: "大学の掲示板以外｜国の制度")))
            if (profile.supportNeeds ?? []).contains("support-jasso-emergency") {
                result.append(.init(id: "support-jasso-emergency", title: "家計が急変したら、給付奨学金を再確認", summary: "失職などの事由がある場合は、通常の募集を待たずに相談。", source: "日本学生支援機構", url: URL(string: "https://www.jasso.go.jp/shogakukin/moshikomi/rinji/kakei_kyuhen/moushikomi.html")!, tags: ["支援", "学生", "奨学金"], reason: "家計の急変を設定したため。対象事由・発生時期は未確認です。", isGuide: true, support: .init(benefit: "対象事由があれば返還不要の給付奨学金を申請できる可能性。", check: "急変の事由、発生時期、収入・資産などを確認。", action: "甲南大学の奨学金窓口へ早めに相談。", documents: "急変事由と収入を証明する書類など。詳細は大学に確認。", origin: "大学の掲示板以外｜国の制度")))
            }
        }
        return result + [
        .init(id: "guide-child", title: "子育ての支援を、取りこぼさないために", summary: "児童手当の制度と手続きを確認する入口です。対象条件は自治体にも確認してください。", source: "こども家庭庁", url: URL(string: "https://www.cfa.go.jp/policies/kokoseido/jidouteate")!, tags: ["子育て", "支援"], reason: "", isGuide: true),
        .init(id: "guide-disaster", title: "暮らすまちの防災を、今日ひとつ確認", summary: "備えや避難についての公式情報を確認しましょう。これはリアルタイムの警報ではありません。", source: "内閣府 防災情報", url: URL(string: "https://www.bousai.go.jp/")!, tags: ["暮らし", "防災"], reason: "", isGuide: true)
        ]
    }
}

enum NewspaperFeedError: LocalizedError {
    case unsafe, response, malformed, empty
    var errorDescription: String? {
        switch self {
        case .unsafe: "公式自治体のHTTPS RSSを指定してください。"
        case .response: "地域の新着情報を取得できませんでした。通信状態や配信元を確認してください。"
        case .malformed: "この配信形式を読み取れませんでした。RSS 1.0/2.0を指定してください。"
        case .empty: "地域の配信に新着記事がありません。"
        }
    }
}

enum NewspaperFeed {
    static func allowed(_ url: URL) -> Bool {
        guard url.scheme == "https", url.user == nil, url.password == nil, url.port == nil || url.port == 443, let host = url.host?.lowercased() else { return false }
        return [".lg.jp", ".go.jp", ".ac.jp", ".co.jp"].contains(where: host.hasSuffix) || host == "www.city.nerima.tokyo.jp"
    }
    static func fetch(_ url: URL, region: String) async throws -> [NewspaperHeadline] {
        guard allowed(url) else { throw NewspaperFeedError.unsafe }
        let session = URLSession(configuration: .ephemeral, delegate: FeedRedirects(), delegateQueue: nil)
        defer { session.invalidateAndCancel() }
        let (bytes, response) = try await session.bytes(for: URLRequest(url: url, timeoutInterval: 18))
        guard (response as? HTTPURLResponse)?.statusCode == 200, response.url.map(allowed) == true else { throw NewspaperFeedError.response }
        var data = Data()
        for try await byte in bytes { guard data.count < 2_000_000 else { throw NewspaperFeedError.response }; data.append(byte) }
        return try parse(data, source: region)
    }
    static func parse(_ data: Data, source: String) throws -> [NewspaperHeadline] {
        let delegate = FeedParser(source: source)
        let parser = XMLParser(data: data)
        parser.shouldResolveExternalEntities = false
        parser.delegate = delegate
        guard parser.parse() else { throw NewspaperFeedError.malformed }
        guard !delegate.items.isEmpty else { throw NewspaperFeedError.empty }
        return delegate.items
    }
    private final class FeedRedirects: NSObject, URLSessionTaskDelegate {
        func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(request.url.map(NewspaperFeed.allowed) == true ? request : nil) }
    }
    private final class FeedParser: NSObject, XMLParserDelegate {
        let source: String
        var items: [NewspaperHeadline] = []
        var inItem = false
        var field = ""
        var values: [String: String] = [:]
        init(source: String) { self.source = source }
        func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String: String] = [:]) {
            if elementName == "item" { inItem = true; values = [:] }
            if inItem, ["media:thumbnail", "media:content", "enclosure"].contains(elementName),
               let url = attributeDict["url"], attributeDict["type"]?.hasPrefix("image/") == true || elementName != "enclosure" { values["image"] = url }
            field = elementName
        }
        func parser(_ parser: XMLParser, foundCharacters string: String) { if inItem { values[field, default: ""] += string } }
        func parser(_ parser: XMLParser, foundCDATA CDATABlock: Data) { if let text = String(data: CDATABlock, encoding: .utf8) { self.parser(parser, foundCharacters: text) } }
        func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
            guard elementName == "item" else { return }
            inItem = false
            guard items.count < 200, let title = values["title"]?.trimmingCharacters(in: .whitespacesAndNewlines), !title.isEmpty,
                  let url = URL(string: (values["link"] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)), NewspaperFeed.allowed(url) else { return }
            let formatter = DateFormatter(); formatter.locale = Locale(identifier: "en_US_POSIX"); formatter.dateFormat = "EEE, dd MMM yyyy HH:mm:ss Z"
            let dateText = (values["pubDate"] ?? values["dc:date"] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            let date = formatter.date(from: dateText) ?? ISO8601DateFormatter().date(from: dateText)
            // A limited excerpt is sufficient; full article remains on the publisher's site.
            let description = String(OfficialSearchPolicy.plainText(values["description"] ?? "").trimmingCharacters(in: .whitespacesAndNewlines).prefix(140))
            let image = values["image"].flatMap(URL.init(string:)).flatMap { image in NewspaperFeed.allowed(image) && image.host == url.host ? image : nil }
            items.append(.init(id: url.absoluteString, title: String(title.prefix(150)), summary: description, source: source, url: url, publishedAt: date, tags: [values["category"] ?? values["dc:subject"] ?? ""], reason: "", imageURL: image))
        }
    }
}

@Observable @MainActor final class NewspaperStore {
    var profile: NewspaperProfile
    var edition: NewspaperEdition?
    var busy = false
    var activityMessage: String?
    var error: String?
    private let defaults: UserDefaults
    private let shares: Bool
    init(defaults: UserDefaults = .standard, shares: Bool = true) {
        self.defaults = defaults; self.shares = shares && defaults === UserDefaults.standard
        profile = defaults.data(forKey: "tome.paper.profile").flatMap { try? JSONDecoder().decode(NewspaperProfile.self, from: $0) } ?? NewspaperProfile()
        edition = defaults.data(forKey: "tome.paper.edition").flatMap { try? JSONDecoder().decode(NewspaperEdition.self, from: $0) }
        // User-provided profile for this prototype; preserve any explicit edits.
        if self.shares, !defaults.bool(forKey: "tome.paper.konanProfileApplied") {
            if profile.university == nil {
                profile.university = "甲南大学"
                profile.universityFeed = "https://www.konan-u.ac.jp/news/sas/feed"
            }
            if profile.age == nil { profile.age = 21 }
            defaults.set(try? JSONEncoder().encode(profile), forKey: "tome.paper.profile")
            defaults.set(true, forKey: "tome.paper.konanProfileApplied")
            defaults.set(0, forKey: "tome.paper.curationVersion")
        }
    }
    func configure(_ value: NewspaperProfile) {
        let changed = profile.region != value.region || profile.ageBand != value.ageBand || profile.studentYear != value.studentYear || profile.interests != value.interests || profile.feedURL != value.feedURL || profile.age != value.age || profile.university != value.university || profile.employer != value.employer || profile.universityFeed != value.universityFeed || profile.employerFeed != value.employerFeed || profile.searchEnabled != value.searchEnabled || profile.supportNeeds != value.supportNeeds
        profile = value
        defaults.set(try? JSONEncoder().encode(value), forKey: "tome.paper.profile")
        if shares, let data = try? JSONEncoder().encode(value) {
            UserDefaults(suiteName: WidgetBridge.group)?.set(data, forKey: "tome.paper.profile")
        }
        if changed { edition = nil; defaults.removeObject(forKey: "tome.paper.edition"); if shares { NewspaperBridge.write(nil); WidgetCenter.shared.reloadTimelines(ofKind: WidgetBridge.kind) }; Task { await stopActivity() } }
    }
    func prepare(force: Bool = false, now: Date = .now) async {
        guard !busy, !profile.region.isEmpty else { return }
        if !force, edition?.day == NewspaperCuration.day(now), defaults.integer(forKey: "tome.paper.curationVersion") == 5 { return }
        busy = true; defer { busy = false }
        error = nil
        let configuration = profile
        var articles = NewspaperCuration.guides(for: configuration)
        var status = "全国向けの制度案内です。地域の新着情報は未接続です。"
        if let url = URL(string: configuration.feedURL), !configuration.feedURL.isEmpty {
            do {
                let news = try await NewspaperFeed.fetch(url, region: configuration.region)
                articles += news.filter { $0.publishedAt.map { $0 <= now && now.timeIntervalSince($0) < 60 * 86400 } ?? false }
                status = "地域の公式RSSと制度案内から編集。新着のない日もあります。"
            } catch { status = error.localizedDescription + " 全国向けの制度案内のみを表示しています。" }
        }
        for (name, address) in [(configuration.university, configuration.universityFeed), (configuration.employer, configuration.employerFeed)] {
            guard let name, !name.isEmpty, let address, let url = URL(string: address), !address.isEmpty else { continue }
            do {
                let news = try await NewspaperFeed.fetch(url, region: name)
                articles += news.filter { $0.publishedAt.map { $0 <= now && now.timeIntervalSince($0) < 60 * 86400 } ?? false }
            } catch { status += " \(name)の配信を取得できませんでした。" }
        }
        if configuration.searchEnabled == true {
            if SearchCredential.read().isEmpty { status += " 検索キー未設定：公式RSSのみ。" }
            else {
                for query in PersonalizedNews.queries(configuration) {
                    do {
                        let candidates = try await OfficialSearch.search(query, includeCompanies: true)
                        for candidate in candidates.prefix(3) {
                            guard let url = URL(string: candidate.url) else { continue }
                            articles.append(.init(id: url.absoluteString, title: candidate.title, summary: String(OfficialSearchPolicy.plainText(candidate.description ?? "").prefix(140)), source: url.host ?? "公式サイト", url: url, tags: [], reason: "プロフィールに関連する公開情報の検索結果。公開日は未確認。"))
                        }
                    } catch { status += " 検索を取得できませんでした。" }
                }
            }
        }
        let selected = NewspaperCuration.select(articles, profile: configuration)
        var personalized = shares ? await PersonalizedNews.rank(selected, profile: configuration) : (selected, "テスト：ルール選定")
        if shares { personalized.0 = await NewsImageLoader.enrich(personalized.0) }
        status += " " + personalized.1
        guard profile == configuration, !Task.isCancelled else { return }
        if edition?.day != NewspaperCuration.day(now), shares { await stopActivity() }
        let day = NewspaperCuration.day(now)
        let received = defaults.string(forKey: "tome.paper.receivedDay") == day || (edition?.day == day && edition?.opened == true)
        edition = NewspaperEdition(day: day, createdAt: now, region: configuration.region, headlines: personalized.0, status: status, opened: received)
        defaults.set(5, forKey: "tome.paper.curationVersion")
        persist()
    }
    func receive() {
        guard let day = edition?.day else { return }
        defaults.set(day, forKey: "tome.paper.receivedDay")
        edition?.opened = true; persist()
    }
    private func persist() { do { defaults.set(try JSONEncoder().encode(edition), forKey: "tome.paper.edition"); publish() } catch { self.error = "朝刊を保存できませんでした。" } }
    func publish() { guard shares else { return }; NewspaperBridge.write(edition); WidgetCenter.shared.reloadTimelines(ofKind: WidgetBridge.kind) }
    func startActivity() async {
        guard ActivityAuthorizationInfo().areActivitiesEnabled else { activityMessage = "iPhoneの設定でTO:MEのライブアクティビティを許可してください。"; return }
        guard let edition, let state = MorningPaperActivity.ContentState(edition: edition) else { return }
        await stopActivity()
        do {
            _ = try Activity<MorningPaperActivity>.request(attributes: .init(editionID: edition.day), content: ActivityContent(state: state, staleDate: .now.addingTimeInterval(4 * 3600)), pushType: nil)
            activityMessage = "ロック画面に朝刊を表示しました。表示時間はiOSが管理します。"
        } catch { activityMessage = "ライブアクティビティを開始できませんでした。" }
    }
    func stopActivity() async { for activity in Activity<MorningPaperActivity>.activities { await activity.end(nil, dismissalPolicy: .immediate) } }
}
