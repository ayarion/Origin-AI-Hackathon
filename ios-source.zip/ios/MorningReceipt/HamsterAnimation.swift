import SwiftUI
import RiveRuntime

/// The front-facing illustration is reserved for welcome and introduction.
/// Receipt and search interactions keep their authored Rive motion.
struct FrontHamsterView: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var floating = false
    var body: some View {
        Image("FrontHamster")
            .resizable().scaledToFit()
            .offset(y: reduceMotion ? 0 : (floating ? -4 : 4))
            .onAppear {
                guard !reduceMotion else { return }
                withAnimation(.easeInOut(duration: 1.5).repeatForever(autoreverses: true)) { floating = true }
            }
            .onChange(of: reduceMotion) { _, value in
                if value { floating = false }
                else { withAnimation(.easeInOut(duration: 1.5).repeatForever(autoreverses: true)) { floating = true } }
            }
            .accessibilityHidden(true)
    }
}

/// All limb motion and the fall are authored in animation/hamster/scene.rml.
/// SwiftUI only positions the artboard at the moving edge of the paper.
struct HamsterAnimation: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    let falling: Bool
    @StateObject private var animation = RiveViewModel(fileName: "hamster", stateMachineName: "Delivery", fit: .contain, autoPlay: true, loadCdn: false)
    var body: some View {
        animation.view()
            .allowsHitTesting(false).accessibilityHidden(true)
            .onAppear { if reduceMotion { animation.pause() } else { animation.play() } }
            .onChange(of: reduceMotion) { _, value in if value { animation.pause() } else if scenePhase == .active { animation.play() } }
            .onChange(of: falling) { _, value in if value && !reduceMotion { animation.triggerInput("drop") } }
            .onChange(of: scenePhase) { _, value in
                if value == .active && !reduceMotion { animation.play() } else { animation.pause() }
            }
            .onDisappear { animation.pause() }
    }
}

/// Crops the fall runway while keeping the existing Rive motion intact.
struct HamsterCompanion: View {
    var body: some View {
        GeometryReader { geometry in
            HamsterAnimation(falling: false)
                .frame(width: geometry.size.width, height: geometry.size.width * 520 / 240)
                .frame(height: geometry.size.height, alignment: .top).clipped()
        }.allowsHitTesting(false).accessibilityHidden(true)
    }
}

struct ReceiptBarcode: View {
    var body: some View {
        VStack(spacing: 9) {
            Canvas { context, size in
                var x: CGFloat = 0
                for index in 0..<86 {
                    let width: CGFloat = index % 7 == 0 ? 3 : index % 3 == 0 ? 2 : 1
                    if index % 2 == 0 { context.fill(Path(CGRect(x: x / 158 * size.width, y: 0, width: width / 158 * size.width, height: size.height)), with: .color(Palette.ink)) }
                    x += width
                }
            }.frame(height: 30)
            Text("TO:ME · DAILY POST").font(.system(.subheadline, design: .monospaced)).tracking(2)
        }.padding(.horizontal, 20).padding(.top, 14).padding(.bottom, 8).accessibilityLabel("装飾用バーコード")
    }
}
