import SwiftUI

@main struct MorningReceiptApp: App {
    @State private var store = ReceiptStore()
    @State private var paper = NewspaperStore()
    @State private var onboarding = OnboardingStore()
    var body: some Scene { WindowGroup { ToMeLaunchView().environment(store).environment(paper).environment(onboarding) } }
}
enum AppTab: Hashable { case morning, camera, saved }
struct RootView: View {
    @Environment(ReceiptStore.self) private var store
    @Environment(NewspaperStore.self) private var paper
    @Environment(OnboardingStore.self) private var onboarding
    @Environment(\.scenePhase) private var scenePhase
    @State private var selectedTab: AppTab = .morning
    @State private var openedDocument: CapturedDocument?
    @State private var missingDocument = false
    var body: some View {
        ZStack {
            if paper.edition == nil || paper.edition?.opened == false || paper.edition?.day != NewspaperCuration.day() {
                Color.white.ignoresSafeArea()
                if let edition = paper.edition, edition.day == NewspaperCuration.day() {
                    MailboxExperience(edition: edition, haptics: paper.profile.haptics, sound: paper.profile.sound) {
                        withAnimation(.easeInOut(duration: 0.35)) { paper.receive(); selectedTab = .morning }
                    }.id(edition.day)
                } else { ProgressView().tint(Palette.blue) }
            } else { mainTabs }
        }
        .task(id: scenePhase) {
            guard scenePhase == .active else { return }
            while !Task.isCancelled {
                await paper.prepare()
                if onboarding.enterHomeDirectly, paper.edition != nil {
                    paper.receive()
                    onboarding.enterHomeDirectly = false
                }
                do { try await Task.sleep(for: .seconds(30)) } catch { return }
            }
        }
    }
    private var mainTabs: some View {
        TabView(selection: $selectedTab) {
            NavigationStack { NewspaperHome() }
                .tabItem { Label("今日", systemImage: "envelope.open") }.tag(AppTab.morning)
            NavigationStack { CaptureView(onSaved: { selectedTab = .saved }).navigationTitle("取り込む") }
                .tabItem { Label("取り込む", systemImage: "viewfinder") }.tag(AppTab.camera)
            NavigationStack { LibraryView() }
                .tabItem { Label("書類", systemImage: "tray.full") }.tag(AppTab.saved)
        }.tint(Palette.blue)
        .task { store.publishWidgets() }
        .onChange(of: scenePhase) { _, phase in if phase == .active { store.refreshDay(); store.publishWidgets() } }
        .onOpenURL { url in
            guard let route = ToMeRoute(url: url) else { return }
            switch route {
            case .home: openedDocument = nil; selectedTab = .morning
            case .capture: openedDocument = nil; selectedTab = .camera
            case .document(let id):
                selectedTab = .morning
                if let document = store.documents.first(where: { $0.id == id }) { openedDocument = document }
                else { missingDocument = true }
            }
        }
        .sheet(item: $openedDocument) { document in NavigationStack { DocumentDetail(documentID: document.id).toolbar { ToolbarItem(placement: .cancellationAction) { Button("閉じる") { openedDocument = nil } } } } }
        .alert("書類が見つかりません", isPresented: $missingDocument) { Button("閉じる", role: .cancel) {} } message: { Text("ウィジェットを更新しました。ホームから書類を選んでください。") }
        .alert("保存できませんでした", isPresented: Binding(get: { store.storageError != nil }, set: { if !$0 { store.storageError = nil } })) { Button("閉じる", role: .cancel) { store.storageError = nil } } message: { Text(store.storageError ?? "") }
    }
}
