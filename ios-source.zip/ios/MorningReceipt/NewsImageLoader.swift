import Foundation

enum NewsImageLoader {
    static func image(in html: String, base: URL) -> URL? {
        guard let tags = try? NSRegularExpression(pattern: #"(?is)<meta\b[^>]+>"#),
              let attributes = try? NSRegularExpression(pattern: #"(?is)(property|name|content)\s*=\s*["']([^"']*)["']"#) else { return nil }
        for tagMatch in tags.matches(in: html, range: NSRange(html.startIndex..., in: html)) {
            guard let range = Range(tagMatch.range, in: html) else { continue }
            let tag = String(html[range])
            var values: [String: String] = [:]
            for attribute in attributes.matches(in: tag, range: NSRange(tag.startIndex..., in: tag)) {
                guard let name = Range(attribute.range(at: 1), in: tag), let value = Range(attribute.range(at: 2), in: tag) else { continue }
                values[String(tag[name]).lowercased()] = String(tag[value])
            }
            guard ["og:image", "twitter:image"].contains(values["property"] ?? values["name"] ?? ""),
                  let content = values["content"], let url = URL(string: content.replacingOccurrences(of: "&amp;", with: "&"), relativeTo: base)?.absoluteURL,
                  NewspaperFeed.allowed(url), url.host == base.host else { continue }
            return url
        }
        return nil
    }
    static func enrich(_ input: [NewspaperHeadline]) async -> [NewspaperHeadline] {
        var output = input
        await withTaskGroup(of: (Int, URL?).self) { group in
            for (index, article) in input.prefix(6).enumerated() where article.imageURL == nil && !article.isGuide {
                group.addTask { (index, await fetch(article.url)) }
            }
            for await (index, url) in group { output[index].imageURL = url }
        }
        return output
    }
    private static func fetch(_ url: URL) async -> URL? {
        guard NewspaperFeed.allowed(url) else { return nil }
        let configuration = URLSessionConfiguration.ephemeral
        configuration.httpShouldSetCookies = false
        let session = URLSession(configuration: configuration, delegate: ImagePageRedirects(host: url.host ?? ""), delegateQueue: nil)
        defer { session.invalidateAndCancel() }
        do {
            let (bytes, response) = try await session.bytes(for: URLRequest(url: url, timeoutInterval: 8))
            guard (response as? HTTPURLResponse)?.statusCode == 200, response.mimeType?.contains("html") == true,
                  let final = response.url, final.host == url.host, NewspaperFeed.allowed(final) else { return nil }
            var data = Data()
            for try await byte in bytes {
                if data.count >= 250_000 { break }
                data.append(byte)
            }
            guard let html = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .shiftJIS) else { return nil }
            return image(in: html, base: final)
        } catch { return nil }
    }
    private final class ImagePageRedirects: NSObject, URLSessionTaskDelegate {
        let host: String
        init(host: String) { self.host = host }
        func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
            completionHandler(request.url.map { NewspaperFeed.allowed($0) && $0.host == host } == true ? request : nil)
        }
    }
}
