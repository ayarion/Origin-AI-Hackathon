# 端末内検索データ

取得日：2026-09-24。個人の入力値を外部へ送らずに照合します。

- PostalRegions.json: 日本郵便「住所の郵便番号（UTF-8）」2026年8月31日更新版。郵便番号と都道府県・市区町村のみ抽出。町域を削除。
  https://www.post.japanpost.jp/service/search/zipcode/download/utf-zip.html
- SchoolDirectory.json: 文部科学省「学校コード」2026年公開版の大学等・東日本(1)(2)・西日本CSV。廃止済みを除き、名称・学校種・市区町村・学校コードを抽出。
  https://www.mext.go.jp/b_menu/toukei/mext_01087.html

再生成: ios/Tools/BuildOnboardingCatalogs.py に取得元フォルダと出力フォルダを渡します。郵便番号はUTF-8版ZIP、学校一覧はUTF-8 CSVを使用。

学校・自治体の再編や郵便番号の変更に合わせて、アプリ更新時に差し替えてください。候補が見つからない際は市区町村検索・学校名の手入力を利用できます。
