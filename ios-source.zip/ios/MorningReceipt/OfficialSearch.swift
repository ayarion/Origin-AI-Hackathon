import Foundation
import Security
import PDFKit

struct OfficialSource: Codable, Identifiable, Equatable {
    var id: String { url.absoluteString }
    let title: String
    let url: URL
    let fetchedAt: Date
    var summary: String
    var requiredDocuments: String
    var deadline: String
    var applicationLinks: [URL]
    var pageTitle: String? = nil
    var evidenceText: String? = nil
}

enum SearchCredential {
    private static let service = "com.demo.morningreceipt.brave"
    static func read() -> String {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: "search", kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data else { return "" }
        return String(data: data, encoding: .utf8) ?? ""
    }
    static func save(_ key: String) throws {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: "search"]
        let data = Data(key.trimmingCharacters(in: .whitespacesAndNewlines).utf8)
        let update = SecItemUpdate(query as CFDictionary, [kSecValueData as String: data] as CFDictionary)
        if update == errSecItemNotFound {
            var add = query; add[kSecValueData as String] = data
            add[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            guard SecItemAdd(add as CFDictionary, nil) == errSecSuccess else { throw OfficialSearchError.credential }
        } else if update != errSecSuccess { throw OfficialSearchError.credential }
    }
}

enum OfficialSearchError: LocalizedError {
    case missingKey, credential, rejectedURL, invalidResponse, noResults, tooLarge
    var errorDescription: String? {
        switch self {
        case .missingKey: "設定からBrave Search APIキーを登録してください。"
        case .credential: "APIキーを安全に保存できませんでした。"
        case .rejectedURL: "許可された公式サイトではありません。"
        case .invalidResponse: "検索に失敗しました。APIキー・利用枠・通信状態を確認してください。"
        case .noResults: "確認できる公式ページが見つかりませんでした。組織名・制度名を変えて試してください。"
        case .tooLarge: "ページが大きすぎるため解析できません。"
        }
    }
}

enum OfficialSearchPolicy {
    static func articleText(_ html: String) -> String {
        let body = html.range(of: #"(?is)<main\b[^>]*>(.*?)</main>"#, options: .regularExpression).map { String(html[$0]) } ?? html
        return body.replacingOccurrences(of: #"(?is)<(script|style|noscript|nav|header|footer)\b[^>]*>.*?</\1>"#, with: " ", options: .regularExpression)
            .replacingOccurrences(of: #"(?i)</(?:p|div|li|tr|h[1-6]|section)>|<br\s*/?>"#, with: "\n", options: .regularExpression)
            .components(separatedBy: .newlines).map { plainText($0).trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }.joined(separator: "\n")
    }
    static func requirements(in text: String) -> String {
        let lines = text.components(separatedBy: .newlines)
        guard let index = lines.firstIndex(where: { ["必要書類", "提出書類", "添付書類"].contains(where: $0.contains) }) else { return "" }
        var result = [lines[index]]
        for line in lines.dropFirst(index + 1).prefix(6) {
            if ["申請期限", "申請方法", "お問い合わせ", "対象者", "受付期間", "申込方法"].contains(where: line.contains) { break }
            result.append(line)
        }
        return String(result.joined(separator: "\n").prefix(700))
    }
    static func documentURLs(_ text: String) -> [URL] {
        guard let detector = try? NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue) else { return [] }
        return Array(Set(detector.matches(in: text, range: NSRange(text.startIndex..., in: text)).compactMap(\.url).filter { allows($0) && $0.query == nil && $0.fragment == nil })).sorted { $0.absoluteString < $1.absoluteString }
    }
    // Fail closed. Private companies and external application vendors require a later issuer-domain verification flow.
    static func allows(_ url: URL) -> Bool {
        guard url.scheme == "https", url.user == nil, url.password == nil, url.port == nil || url.port == 443,
              let host = url.host?.lowercased() else { return false }
        return [".go.jp", ".lg.jp", ".ac.jp"].contains(where: host.hasSuffix)
    }
    static func plainText(_ html: String) -> String {
        html.replacingOccurrences(of: #"(?is)<(script|style|noscript)\b[^>]*>.*?</\1>"#, with: " ", options: .regularExpression)
            .replacingOccurrences(of: #"(?s)<[^>]+>"#, with: " ", options: .regularExpression)
            .replacingOccurrences(of: "&nbsp;", with: " ").replacingOccurrences(of: "&amp;", with: "&")
            .replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
    }
    static func applicationLinks(_ html: String, base: URL) -> [URL] {
        guard let regex = try? NSRegularExpression(pattern: #"(?is)<a\b[^>]*href\s*=\s*["']([^"']+)["'][^>]*>(.*?)</a>"#) else { return [] }
        var links: [URL] = []
        for match in regex.matches(in: html, range: NSRange(html.startIndex..., in: html)) {
            guard let target = Range(match.range(at: 1), in: html), let label = Range(match.range(at: 2), in: html),
                  ["申請", "申込", "様式", "フォーム"].contains(where: plainText(String(html[label])).contains),
                  let url = URL(string: String(html[target]).replacingOccurrences(of: "&amp;", with: "&"), relativeTo: base)?.absoluteURL,
                  allows(url), !links.contains(url) else { continue }
            links.append(url)
        }
        return Array(links.prefix(5))
    }
}

private final class OfficialRedirectPolicy: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(request.url.map(OfficialSearchPolicy.allows) == true ? request : nil)
    }
}

struct OfficialSearch {
    struct Candidate: Identifiable, Decodable {
        var id: String { url }
        let title: String
        let url: String
        let description: String?
    }
    private struct Response: Decodable {
        struct Web: Decodable { let results: [Candidate]? }
        let web: Web?
    }

    static func search(_ publicQuery: String, includeCompanies: Bool = false) async throws -> [Candidate] {
        let key = SearchCredential.read()
        guard !key.isEmpty else { throw OfficialSearchError.missingKey }
        var components = URLComponents(string: "https://api.search.brave.com/res/v1/web/search")!
        let scope = includeCompanies ? " (site:go.jp OR site:lg.jp OR site:ac.jp OR site:co.jp)" : " (site:go.jp OR site:lg.jp OR site:ac.jp)"
        components.queryItems = [URLQueryItem(name: "q", value: String(publicQuery.prefix(200)) + scope), URLQueryItem(name: "count", value: "8"), URLQueryItem(name: "country", value: "JP"), URLQueryItem(name: "search_lang", value: "ja")]
        var request = URLRequest(url: components.url!, timeoutInterval: 20)
        request.setValue(key, forHTTPHeaderField: "X-Subscription-Token")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let config = URLSessionConfiguration.ephemeral
        config.httpShouldSetCookies = false
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        let (data, response) = try await session.data(for: request)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw OfficialSearchError.invalidResponse }
        let found = try JSONDecoder().decode(Response.self, from: data).web?.results ?? []
        let safe = found.filter { candidate in
            guard let url = URL(string: candidate.url) else { return false }
            return OfficialSearchPolicy.allows(url) || (includeCompanies && NewspaperFeed.allowed(url))
        }
        guard !safe.isEmpty else { throw OfficialSearchError.noResults }
        return safe
    }

    static func inspect(_ candidate: Candidate) async throws -> OfficialSource {
        guard let url = URL(string: candidate.url), OfficialSearchPolicy.allows(url) else { throw OfficialSearchError.rejectedURL }
        let config = URLSessionConfiguration.ephemeral
        config.httpShouldSetCookies = false
        let session = URLSession(configuration: config, delegate: OfficialRedirectPolicy(), delegateQueue: nil)
        defer { session.invalidateAndCancel() }
        let (stream, response) = try await session.bytes(for: URLRequest(url: url, timeoutInterval: 20))
        guard let http = response as? HTTPURLResponse, http.statusCode == 200,
              let finalURL = response.url, OfficialSearchPolicy.allows(finalURL),
              response.mimeType?.contains("html") == true || response.mimeType == "application/pdf" else { throw OfficialSearchError.invalidResponse }
        var data = Data()
        for try await byte in stream {
            guard data.count < 5_000_000 else { throw OfficialSearchError.tooLarge }
            data.append(byte)
        }
        let html: String
        let text: String
        if response.mimeType == "application/pdf" {
            html = ""
            guard let pdf = PDFDocument(data: data) else { throw OfficialSearchError.invalidResponse }
            text = (0..<min(pdf.pageCount, 20)).compactMap { pdf.page(at: $0)?.string }.joined(separator: "\n")
        } else {
            guard let value = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .shiftJIS) else { throw OfficialSearchError.invalidResponse }
            html = value
            text = OfficialSearchPolicy.articleText(html)
        }
        let heading = html.range(of: #"(?is)<h1\b[^>]*>.*?</h1>"#, options: .regularExpression).map { OfficialSearchPolicy.plainText(String(html[$0])) }
            ?? html.range(of: #"(?is)<title\b[^>]*>.*?</title>"#, options: .regularExpression).map { OfficialSearchPolicy.plainText(String(html[$0])) }
            ?? text.components(separatedBy: .newlines).first(where: { !$0.trimmingCharacters(in: .whitespaces).isEmpty }) ?? ""
        let analysis = await LocalDocumentAI.analyze(text)
        return OfficialSource(title: candidate.title, url: finalURL, fetchedAt: .now,
                              summary: analysis.aiSummary ?? "AI要約を利用できません。リンク先の公式ページを確認してください。",
                              requiredDocuments: (analysis.requiredDocuments?.count ?? 0) > 8 ? analysis.requiredDocuments! : OfficialSearchPolicy.requirements(in: text), deadline: analysis.deadlineText,
                              applicationLinks: OfficialSearchPolicy.applicationLinks(html, base: finalURL), pageTitle: heading, evidenceText: String(text.prefix(30000)))
    }
}

enum DocumentResearch {
    // Search only public labels, never the OCR body. Suppress personal-looking labels.
    static func query(for document: CapturedDocument) -> String? {
        let title = document.title.trimmingCharacters(in: .whitespacesAndNewlines)
        let labels = [title, document.issuer.trimmingCharacters(in: .whitespacesAndNewlines)].filter { !$0.isEmpty }
        guard !title.isEmpty, title != "読み取った書類", labels.allSatisfy({ $0.count <= 80 }),
              !labels.contains(where: { label in
                  ["様", "氏名", "住所", "電話", "@", "http", "番号"].contains(where: label.contains)
                  || label.range(of: #"\d{7,}"#, options: .regularExpression) != nil
              }) else { return nil }
        let year = Calendar(identifier: .gregorian).component(.year, from: .now)
        return labels.joined(separator: " ") + " \(year) 申請 必要書類 期限"
    }
    static func investigate(_ input: CapturedDocument) async -> CapturedDocument {
        var document = input
        guard !document.isSample else { document.researchStatus = "サンプル：外部調査なし"; return document }
        var candidates = OfficialSearchPolicy.documentURLs(document.rawText).prefix(2).map {
            OfficialSearch.Candidate(title: document.title, url: $0.absoluteString, description: nil)
        }
        var searchFailure: String?
        if let query = query(for: document) {
            document.publicSearchQuery = query
            if !SearchCredential.read().isEmpty {
                do {
                    let found = try await OfficialSearch.search(query)
                    for candidate in found.prefix(3) where !candidates.contains(where: { $0.url == candidate.url }) { candidates.append(candidate) }
                } catch { searchFailure = error.localizedDescription }
            } else { searchFailure = "検索キー未設定" }
        } else { searchFailure = "制度名・発行元を確認してください" }
        var sources: [OfficialSource] = []
        for candidate in candidates.prefix(3) {
            guard !Task.isCancelled else { return input }
            do { sources.append(try await OfficialSearch.inspect(candidate)) }
            catch { searchFailure = error.localizedDescription }
        }
        guard !Task.isCancelled else { return input }
        document.officialSources = sources
        document.researchStatus = sources.isEmpty ? (searchFailure ?? "公式情報が見つかりません") : "公式ページ取得済み・対象年度は要確認"
        // Never overwrite the scanned deadline with a different year's search result.
        return document
    }
}
