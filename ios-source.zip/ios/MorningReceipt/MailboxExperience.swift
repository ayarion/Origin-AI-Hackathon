import SwiftUI
import CoreHaptics
import AudioToolbox

@MainActor final class MailboxFeedback {
    private var engine: CHHapticEngine?
    private var player: CHHapticPatternPlayer?
    private var lastStep = -1
    private let impact = UIImpactFeedbackGenerator(style: .soft)
    func pull(_ progress: CGFloat, enabled: Bool) {
        guard enabled else { return }
        if lastStep == -1 {
            impact.prepare()
            if CHHapticEngine.capabilitiesForHardware().supportsHaptics {
                do {
                    let engine = try CHHapticEngine(); self.engine = engine; try engine.start()
                    let event = CHHapticEvent(eventType: .hapticContinuous, parameters: [.init(parameterID: .hapticIntensity, value: 0.22), .init(parameterID: .hapticSharpness, value: 0.12)], relativeTime: 0, duration: 8)
                    player = try engine.makePlayer(with: CHHapticPattern(events: [event], parameters: []))
                    try player?.start(atTime: CHHapticTimeImmediate)
                } catch { player = nil }
            }
        }
        let step = Int(progress * 9)
        if step != lastStep { impact.impactOccurred(intensity: 0.25 + progress * 0.55); lastStep = step }
        try? player?.sendParameters([.init(parameterID: .hapticIntensityControl, value: Float(0.3 + progress * 0.65), relativeTime: 0)], atTime: CHHapticTimeImmediate)
    }
    func stop() { try? player?.stop(atTime: CHHapticTimeImmediate); engine?.stop(); player = nil; engine = nil; lastStep = -1 }
    func opened(haptics: Bool, sound: Bool) {
        stop()
        if haptics { UIImpactFeedbackGenerator(style: .rigid).impactOccurred(intensity: 0.8) }
        if sound { AudioServicesPlaySystemSound(1104) }
    }
}

struct MailboxExperience: View {
    let edition: NewspaperEdition
    let haptics: Bool
    let sound: Bool
    let receive: () -> Void
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @State private var progress: CGFloat = 0
    @State private var committed = false
    @State private var feedback = MailboxFeedback()
    @State private var opening: Task<Void, Never>?
    private let blue = Color(red: 0.06, green: 0.23, blue: 0.50)
    var body: some View {
        VStack(spacing: 18) {
            ZStack {
                Ellipse().fill(blue.opacity(0.13)).frame(width: 280, height: 30).blur(radius: 12).offset(y: 170)
                RoundedRectangle(cornerRadius: 32).fill(LinearGradient(colors: [blue.opacity(0.85), blue], startPoint: .topLeading, endPoint: .bottomTrailing)).frame(width: 306, height: 280)
                    .shadow(color: blue.opacity(0.26), radius: 22, y: 16)
                RoundedRectangle(cornerRadius: 20).fill(.black.opacity(0.80)).frame(width: 264, height: 178).offset(y: 20)
                    .overlay { RoundedRectangle(cornerRadius: 20).stroke(.black.opacity(0.35), lineWidth: 8).frame(width: 264, height: 178).offset(y: 20) }
                VStack(spacing: 8) {
                    Text("朝刊").font(.system(size: 26, weight: .black, design: .serif))
                    Rectangle().frame(height: 2)
                    Text(edition.headlines.first?.title ?? "あなたの朝刊").font(.headline).lineLimit(3)
                    HStack(alignment: .top, spacing: 8) {
                        ForEach(0..<2) { _ in VStack(spacing: 5) { ForEach(0..<4) { _ in Rectangle().fill(blue.opacity(0.20)).frame(height: 3) } } }
                    }
                }.foregroundStyle(blue).padding(18).frame(width: 220, height: 205)
                    .background(Color(red: 0.98, green: 0.96, blue: 0.90))
                    .rotationEffect(.degrees(Double(-8 + progress * 8)))
                    .offset(y: committed ? -60 : 58 - progress * 60)
                    .scaleEffect(committed ? 1.16 : 0.80 + progress * 0.20)
                    .opacity(Double(progress))
                    .shadow(color: .black.opacity(0.24), radius: 8, y: 8)
                // Hinged door: perspective reveals a dark inner cavity as the finger pulls down.
                VStack(spacing: 24) {
                    HStack { Text("TO:ME").font(.title2.weight(.black)); Spacer(); Image(systemName: "sun.max") }.padding(.horizontal, 20)
                    Capsule().fill(.black.opacity(0.45)).frame(width: 186, height: 9)
                    Capsule().fill(LinearGradient(colors: [.white.opacity(0.95), .white.opacity(0.55)], startPoint: .top, endPoint: .bottom)).frame(width: 84, height: 12).shadow(color: .black.opacity(0.25), radius: 4, y: 4)
                }.foregroundStyle(.white.opacity(0.9)).frame(width: 278, height: 192)
                    .background(LinearGradient(colors: [blue.opacity(0.8), blue], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 22))
                    .overlay(RoundedRectangle(cornerRadius: 22).stroke(.white.opacity(0.2), lineWidth: 1))
                    .rotation3DEffect(.degrees(reduceMotion ? 0 : Double(progress) * 108), axis: (x: 1, y: 0, z: 0), anchor: .bottom, perspective: 0.5)
                    .opacity(reduceMotion ? Double(1 - progress) : 1)
                    .offset(y: 17)
                Text("DAILY POST").font(.system(.subheadline, design: .rounded).weight(.bold)).tracking(3).foregroundStyle(.white.opacity(0.75)).offset(y: -117)
            }.frame(maxWidth: .infinity).frame(height: 375)
                .scaleEffect(reduceMotion ? 1 : 1 + progress * 0.10)
                .rotation3DEffect(.degrees(reduceMotion ? 0 : Double(progress) * -8), axis: (x: 1, y: 0, z: 0), perspective: 0.6)
                .contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance: 6).onChanged { value in
                    guard !committed else { return }
                    progress = min(1, max(0, value.translation.height / 210))
                    feedback.pull(progress, enabled: haptics)
                }.onEnded { _ in
                    feedback.stop()
                    if progress >= 0.62 { open() } else { withAnimation(.spring(response: 0.5, dampingFraction: 0.65)) { progress = 0 } }
                })
                .accessibilityElement(children: .ignore).accessibilityLabel("ポスト。下に引いて朝刊を受け取る")
                .accessibilityAddTraits(.isButton).accessibilityAction { open() }
        }.padding(.horizontal, 12).frame(maxWidth: .infinity, maxHeight: .infinity).background(.white)
            .onDisappear { feedback.stop(); opening?.cancel() }
            .onChange(of: scenePhase) { _, phase in if phase != .active { feedback.stop() } }
    }
    private func open() {
        guard !committed else { return }
        feedback.opened(haptics: haptics, sound: sound)
        if reduceMotion { receive(); return }
        withAnimation(.spring(response: 0.85, dampingFraction: 0.73)) { committed = true; progress = 1 }
        opening = Task { do { try await Task.sleep(for: .milliseconds(1050)) } catch { return }; receive() }
    }
}
