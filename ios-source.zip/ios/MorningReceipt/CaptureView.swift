import SwiftUI
import PhotosUI
import VisionKit

struct CaptureView: View {
    let onSaved: () -> Void
    private enum ScanMode { case envelope, document }
    @State private var photo: PhotosPickerItem?
    @State private var mode: ScanMode = .envelope
    @State private var camera = false
    @State private var draft: CapturedDocument?
    @State private var envelopePreview: EnvelopePrediction?
    @State private var busy = false
    @State private var error: String?
    var body: some View {
        ScrollView {
            VStack(spacing: 28) {
                Image(systemName: "envelope").font(.system(size: 100, weight: .ultraLight)).foregroundStyle(Palette.blue).frame(width: 190, height: 150)
                Text("封筒をかざして手続きを探す").font(.title2.bold())
                Button { mode = .envelope; camera = true } label: { Label("封筒をかざす", systemImage: "camera") }.buttonStyle(SoftButtonStyle(primary: true))
                PhotosPicker(selection: $photo, matching: .images) { Label("封筒の写真を選ぶ", systemImage: "photo") }
                    .simultaneousGesture(TapGesture().onEnded { mode = .envelope }).buttonStyle(SoftButtonStyle())
                DisclosureGroup("開封後の書類を確認") {
                    VStack(spacing: 16) {
                        Button { mode = .document; camera = true } label: { Label("書類を撮影", systemImage: "doc.viewfinder") }.buttonStyle(SoftButtonStyle())
                        PhotosPicker(selection: $photo, matching: .images) { Label("書類の写真を選ぶ", systemImage: "photo.on.rectangle") }
                            .simultaneousGesture(TapGesture().onEnded { mode = .document }).buttonStyle(SoftButtonStyle())
                        Button("サンプルで試す") { recognize(SampleDocument.imageData(), sample: true) }.font(.body)
                    }.padding(.top, 14)
                }.font(.body)
                if busy { ProgressView("読み取り中") }
            }.padding(28).frame(maxWidth: 550).frame(maxWidth: .infinity).disabled(busy)
        }.background { GlassBackdrop() }
        .onChange(of: photo) { _, item in
            guard let item else { return }
            busy = true
            Task {
                do {
                    guard let data = try await item.loadTransferable(type: Data.self) else { throw OCRFailure.unreadableImage }
                    if mode == .envelope { await processEnvelope([data]) }
                    else { await process(data, sample: false) }
                } catch { self.error = error.localizedDescription; busy = false }
                photo = nil
            }
        }
        .sheet(isPresented: $camera) { DocumentCamera(failure: { message in camera = false; error = message }) { images in
            camera = false
            guard !images.isEmpty else { return }
            busy = true
            Task {
                do {
                    if mode == .envelope { await processEnvelope(images) }
                    else { draft = try await DocumentPipeline.analyze(images) }
                } catch { self.error = error.localizedDescription }
                busy = false
            }
        } }
        .sheet(item: $draft) { document in DocumentReview(document: document, onSaved: onSaved) }
        .sheet(item: $envelopePreview) { prediction in
            EnvelopePreviewView(prediction: prediction) {
                mode = .document
                Task { try? await Task.sleep(for: .milliseconds(400)); camera = true }
            }
        }
        .alert("読み取れませんでした", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) { Button("閉じる") { error = nil } } message: { Text(error ?? "") }
    }
    private func recognize(_ data: Data, sample: Bool) { busy = true; Task { await process(data, sample: sample) } }
    private func process(_ data: Data, sample: Bool) async {
        do { draft = try await DocumentPipeline.analyze([data], sample: sample) }
        catch { self.error = error.localizedDescription }
        busy = false
    }
    private func processEnvelope(_ images: [Data]) async {
        do {
            let results = try await images.prefix(2).asyncMap { try await DocumentOCR.scan($0) }
            let text = results.map(\.text).joined(separator: "\n")
            guard let first = results.first else { throw OCRFailure.unreadableImage }
            var prediction = EnvelopeClassifier.predict(text, imageData: first.imageData)
            prediction.rawText = text
            envelopePreview = prediction
        } catch { self.error = error.localizedDescription }
        busy = false
    }
}

private extension Sequence {
    func asyncMap<T>(_ transform: (Element) async throws -> T) async throws -> [T] {
        var result: [T] = []
        for element in self { result.append(try await transform(element)) }
        return result
    }
}

struct DocumentCamera: UIViewControllerRepresentable {
    let failure: (String) -> Void
    let completion: ([Data]) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(completion, failure: failure) }
    func makeUIViewController(context: Context) -> UIViewController {
        guard VNDocumentCameraViewController.isSupported else {
            let controller = UIViewController()
            let label = UILabel(); label.text = "この端末ではカメラを使えません。\n閉じて写真から取り込んでください。"; label.numberOfLines = 0; label.textAlignment = .center
            label.translatesAutoresizingMaskIntoConstraints = false; controller.view.addSubview(label)
            NSLayoutConstraint.activate([label.centerYAnchor.constraint(equalTo: controller.view.centerYAnchor), label.leadingAnchor.constraint(equalTo: controller.view.leadingAnchor, constant: 24), label.trailingAnchor.constraint(equalTo: controller.view.trailingAnchor, constant: -24)])
            controller.view.backgroundColor = .systemBackground
            return controller
        }
        let controller = VNDocumentCameraViewController(); controller.delegate = context.coordinator; return controller
    }
    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {}
    final class Coordinator: NSObject, VNDocumentCameraViewControllerDelegate {
        let completion: ([Data]) -> Void
        let failure: (String) -> Void
        init(_ completion: @escaping ([Data]) -> Void, failure: @escaping (String) -> Void) { self.completion = completion; self.failure = failure }
        func documentCameraViewControllerDidCancel(_ controller: VNDocumentCameraViewController) { completion([]) }
        func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFailWithError error: Error) { failure(error.localizedDescription) }
        func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFinishWith scan: VNDocumentCameraScan) {
            completion((0..<scan.pageCount).compactMap { scan.imageOfPage(at: $0).jpegData(compressionQuality: 0.9) })
        }
    }
}

struct DocumentReview: View {
    @Environment(ReceiptStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State var document: CapturedDocument
    @State private var searchVisible = false
    @State private var researching = false
    @State private var retry = 0
    let onSaved: () -> Void
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Text(document.title).font(.title.bold())
                    if !document.issuer.isEmpty { Text(document.issuer).font(.body).foregroundStyle(.secondary) }
                    if researching { ProgressView("公式情報を調査中") }
                    ProcedureSummary(document: document)
                    if document.researchStatus == "検索キー未設定" {
                        NavigationLink("公式サイト検索を設定") { SearchSettingsView() }
                            .buttonStyle(SoftButtonStyle(primary: true))
                        Button("設定後に再調査") { retry += 1 }
                            .buttonStyle(SoftButtonStyle())
                            .disabled(researching)
                    }
                    HStack {
                        NavigationLink { EvidenceView(document: document) } label: { Label("原本", systemImage: "doc.text.viewfinder") }
                        Spacer()
                        Button("検索") { searchVisible = true }
                    }.font(.body)
                    DisclosureGroup("読み取りを修正") {
                        VStack(spacing: 18) {
                            field("タイトル", text: $document.title)
                            field("発行元", text: $document.issuer)
                            field("書類の期限", text: $document.deadlineText)
                            field("必要書類", text: Binding(get: { document.requiredDocuments ?? "" }, set: { document.requiredDocuments = $0 }))
                            field("すること", text: $document.nextAction)
                            Button("再調査") { retry += 1 }
                        }.padding(.top, 16).disabled(researching)
                    }
                    DisclosureGroup("解析・検索の詳細") {
                        VStack(alignment: .leading, spacing: 12) {
                            Text(document.analysisStatus ?? "")
                            Text("検索時は制度名・発行元を送信します。画像と全文は検索サービスへ送りません。")
                            if let query = document.publicSearchQuery { Text(query) }
                            NavigationLink("重要箇所の判定") { ImportanceReview(document: $document) }
                        }.font(.body)
                    }
                }.padding(24)
            }.background { GlassBackdrop() }
                .navigationTitle("手続き").navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("閉じる") { dismiss() } }
                    ToolbarItem(placement: .confirmationAction) { Button("保存") {
                        document.reviewedAt = .now; store.importDocument(document); dismiss(); onSaved()
                    }.disabled(researching || document.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
                }
                .task(id: retry) {
                    guard document.researchStatus == nil || retry > 0 else { return }
                    researching = true
                    let result = await DocumentResearch.investigate(document)
                    if !Task.isCancelled { document = result }
                    researching = false
                }
        }.sheet(isPresented: $searchVisible) {
            OfficialSearchView(onSelect: { source in
                var sources = document.officialSources ?? []
                sources.removeAll { $0.id == source.id }; sources.append(source)
                document.officialSources = sources
            }, query: document.publicSearchQuery ?? DocumentResearch.query(for: document) ?? "", documentText: document.rawText)
        }
    }
    private func field(_ title: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).foregroundStyle(Palette.muted)
            TextField("未確認", text: text, axis: .vertical)
        }.font(.body).frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct ProcedureSummary: View {
    let document: CapturedDocument
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Label("書類の内容", systemImage: "doc.text").font(.headline).foregroundStyle(Palette.blue)
            if let summary = document.aiSummary, !summary.isEmpty { Text(summary).font(.body) }
            row("書類に書かれた期限", value: document.deadlineText)
            row("書類に書かれた必要書類", value: document.requiredDocuments ?? "")
            ForEach(document.extractionNotes, id: \.self) { note in Text(note).font(.body).foregroundStyle(.orange) }
            if !document.nextAction.isEmpty { row("手続き", value: document.nextAction) }
            Divider()
            Label("公式サイトの調査", systemImage: "globe.asia.australia").font(.headline).foregroundStyle(Palette.blue)
            if let status = document.researchStatus { Text(status).font(.body).foregroundStyle(.secondary) }
            if (document.officialSources ?? []).isEmpty {
                row("手続きサイト", value: "")
                if document.researchStatus == "検索キー未設定" {
                    Text("書類内に公式URLがない場合、自動検索にはBrave Search APIキーが必要です。")
                        .font(.body).foregroundStyle(.secondary)
                }
            }
            ForEach(document.officialSources ?? []) { source in
                VStack(alignment: .leading, spacing: 14) {
                    Link(destination: source.url) {
                        HStack(alignment: .top) { Text(source.title).font(.headline); Spacer(); Image(systemName: "arrow.up.right") }
                    }
                    Text(source.url.host ?? "").font(.body).foregroundStyle(.secondary)
                    row("掲載期限", value: source.deadline)
                    if let date = ReceiptDeadline.date(source.deadline), date < Calendar.current.startOfDay(for: .now) {
                        Label("掲載期限は経過しています", systemImage: "clock.badge.exclamationmark").font(.body).foregroundStyle(.orange)
                    }
                    row("必要書類", value: source.requiredDocuments)
                    if source.applicationLinks.isEmpty { row("申請フォーム", value: "") }
                    ForEach(source.applicationLinks, id: \.absoluteString) { url in
                        Link(destination: url) { Label("申請・様式", systemImage: "arrow.up.right.square") }.font(.body.weight(.semibold))
                    }
                    Text("取得 " + source.fetchedAt.formatted(date: .abbreviated, time: .shortened)).font(.body).foregroundStyle(.secondary)
                }
                Divider()
            }
        }.frame(maxWidth: .infinity, alignment: .leading).padding(22).softSurface()
    }
    private func row(_ title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.body).foregroundStyle(.secondary)
            Text(value.isEmpty ? "未確認" : value).font(.body.weight(.medium)).textSelection(.enabled)
        }
    }
}
