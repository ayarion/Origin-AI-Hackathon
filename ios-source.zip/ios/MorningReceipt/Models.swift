import Foundation
import Observation
import WidgetKit

enum ArticleCategory: String, Codable, CaseIterable {
    case action = "ACTION", news = "NEWS", chance = "CHANCE"
    var caption: String {
        switch self {
        case .action: "今日やること"
        case .news: "知っておきたいこと"
        case .chance: "使える機会"
        }
    }
    var symbol: String {
        switch self {
        case .action: "clock"
        case .news: "newspaper"
        case .chance: "sparkles"
        }
    }
}

enum SourceKind: String, Codable, CaseIterable {
    case university = "大学", city = "自治体", company = "勤務先"
    var symbol: String {
        switch self {
        case .university: "graduationcap"
        case .city: "building.2"
        case .company: "briefcase"
        }
    }
}

struct Profile: Codable, Equatable {
    var name = "あおい"
    var university = true
    var city = true
    var company = true
    var deliveryHour = 7
    func includes(_ source: SourceKind) -> Bool {
        switch source {
        case .university: university
        case .city: city
        case .company: company
        }
    }
}

struct Article: Identifiable, Codable, Equatable {
    let id: String
    let category: ArticleCategory
    let source: SourceKind
    let title: String
    let summary: String
    let reason: String
    let publisher: String
    let amount: Int?
    let deadlineDays: Int?
    let steps: [String]
    let note: String

    static let samples: [Article] = [
        Article(id: "scholarship", category: .action, source: .university,
                title: "秋の給付型奨学金",
                summary: "在学・所得・口座の確認書類を用意して申請。受給には条件があります。",
                reason: "プロフィールで「大学」を選んでいるため。学年・家計・他の奨学金との併用条件の確認が必要です。",
                publisher: "あさひ大学 学生支援室", amount: 48000, deadlineDays: 6,
                steps: ["募集要項で対象条件を確認する", "在学証明書と所得証明書を用意する", "申請フォームに入力して提出する"],
                note: "必要書類：在学証明書、所得証明書、振込口座の確認書類。支給額と受給資格は審査によって決まります。"),
        Article(id: "city-news", category: .news, source: .city,
                title: "市役所の土曜窓口",
                summary: "来月から第2・第4土曜、9〜12時。住民票など一部の証明書が対象。",
                reason: "プロフィールで「自治体」を選んでいるため。対象となる窓口と取扱業務を確認してください。",
                publisher: "こもれび市 市民窓口課", amount: nil, deadlineDays: nil,
                steps: [], note: "受付は第2・第4土曜日の9:00〜12:00という設定のサンプルです。すべての手続きが対象ではありません。"),
        Article(id: "learning", category: .chance, source: .company,
                title: "秋のスキルアップ講座",
                summary: "対象講座は受講料を全額補助。講座を選んで社内フォームから申込。",
                reason: "プロフィールで「勤務先」を選んでいるため。雇用形態と講座の対象条件の確認が必要です。",
                publisher: "ブルーバード 人材開発室", amount: nil, deadlineDays: 10,
                steps: ["対象講座と補助条件を確認する", "希望する講座を選ぶ", "社内フォームで申し込む"],
                note: "講座ごとに受講料が異なるため、金額の合計には含めていません。")
    ]
}

struct Procedure: Identifiable, Codable, Equatable {
    var id: String
    var title: String
    var source: SourceKind
    var deadline: Date
    var steps: [String]
    var checkedSteps: Set<Int> = []
    var reminderDays: Int? = nil
    var completedAt: Date? = nil
    var isComplete: Bool { completedAt != nil }
}

struct PersistedState: Codable {
    var profile: Profile
    var procedures: [Procedure]
    var openedDay: String?
    var documents: [CapturedDocument]? = nil
}

enum ReceiptGesture {
    static let threshold: CGFloat = 94
    static func shouldTear(vertical: CGFloat) -> Bool { vertical >= threshold }
}

@Observable @MainActor
final class ReceiptStore {
    func attachOfficialSource(_ source: OfficialSource, documentID: UUID) {
        guard let index = documents.firstIndex(where: { $0.id == documentID }) else { return }
        var sources = documents[index].officialSources ?? []
        sources.removeAll { $0.id == source.id }
        sources.append(source)
        documents[index].officialSources = sources
        save()
    }
    var profile: Profile
    var procedures: [Procedure]
    var openedDay: String?
    var today: Date
    var storageError: String?
    var documents: [CapturedDocument]
    private let defaults: UserDefaults
    private let storageKey = "morning-receipt.demo.v1"

    init(defaults: UserDefaults = .standard, now: Date = .now) {
        self.defaults = defaults
        today = Calendar.current.startOfDay(for: now)
        let saved = defaults.data(forKey: storageKey).flatMap { try? JSONDecoder().decode(PersistedState.self, from: $0) }
        profile = saved?.profile ?? Profile()
        procedures = saved?.procedures ?? []
        openedDay = saved?.openedDay
        documents = saved?.documents ?? []
    }

    var dayKey: String { Self.dayKey(today) }
    var hasOpenedToday: Bool { openedDay == dayKey }
    var articles: [Article] { Array(Article.samples.filter { profile.includes($0.source) }.prefix(5)) }
    var receiptDocuments: [CapturedDocument] { Array(documents.filter { !$0.isHandled }.sorted { $0.savedAt > $1.savedAt }.prefix(5)) }
    var attentionDocuments: [CapturedDocument] {
        documents.filter { !$0.isHandled }.sorted {
            if $0.isSample != $1.isSample { return !$0.isSample }
            if ($0.reviewedAt == nil) != ($1.reviewedAt == nil) { return $0.reviewedAt == nil }
            let left = ReceiptDeadline.date($0.deadlineText) ?? .distantFuture
            let right = ReceiptDeadline.date($1.deadlineText) ?? .distantFuture
            return left == right ? $0.savedAt > $1.savedAt : left < right
        }
    }
    var receiptArticles: [Article] { Array(articles.prefix(max(0, 5 - receiptDocuments.count))) }
    var receiptCount: Int { receiptDocuments.count + receiptArticles.count }
    var potentialAmount: Int { articles.compactMap(\.amount).reduce(0, +) }
    var activeProcedures: [Procedure] { procedures.filter { !$0.isComplete }.sorted { $0.deadline < $1.deadline } }
    var completedProcedures: [Procedure] { procedures.filter(\.isComplete).sorted { ($0.completedAt ?? .distantPast) > ($1.completedAt ?? .distantPast) } }
    var upcomingCount: Int {
        activeProcedures.filter { (0...7).contains(daysUntil($0.deadline)) }.count
    }

    static func dayKey(_ date: Date) -> String {
        let c = Calendar.current.dateComponents([.year, .month, .day], from: date)
        return "\(c.year ?? 0)-\(c.month ?? 0)-\(c.day ?? 0)"
    }
    func refreshDay(now: Date = .now) { today = Calendar.current.startOfDay(for: now) }
    func publishWidgets() {
        // Documents stay in the app. The newspaper owns the widget snapshot.
        guard defaults === UserDefaults.standard else { return }
        WidgetBridge.write(.empty)
    }
    func date(after days: Int) -> Date { Calendar.current.date(byAdding: .day, value: days, to: today) ?? today }
    func daysUntil(_ deadline: Date) -> Int {
        Calendar.current.dateComponents([.day], from: today, to: Calendar.current.startOfDay(for: deadline)).day ?? 0
    }
    func openReceipt() { openedDay = dayKey; save() }
    func replay() { openedDay = nil; save() }
    func updateProfile(_ value: Profile) {
        profile = value
        profile.name = String(value.name.trimmingCharacters(in: .whitespacesAndNewlines).prefix(20))
        if profile.name.isEmpty { profile.name = "あなた" }
        save()
    }
    func contains(_ article: Article) -> Bool { procedures.contains { $0.id == article.id } }
    func add(_ article: Article) {
        guard !contains(article), let days = article.deadlineDays, !article.steps.isEmpty else { return }
        procedures.append(Procedure(id: article.id, title: article.title.replacingOccurrences(of: "\n", with: ""), source: article.source, deadline: date(after: days), steps: article.steps))
        save()
    }
    func toggleStep(procedureID: String, index: Int) {
        guard let i = procedures.firstIndex(where: { $0.id == procedureID }),
              procedures[i].steps.indices.contains(index), !procedures[i].isComplete else { return }
        if procedures[i].checkedSteps.contains(index) { procedures[i].checkedSteps.remove(index) }
        else { procedures[i].checkedSteps.insert(index) }
        save()
    }
    func setReminder(procedureID: String, days: Int?) {
        guard let i = procedures.firstIndex(where: { $0.id == procedureID }) else { return }
        procedures[i].reminderDays = days
        save()
    }
    func complete(_ id: String) {
        guard let i = procedures.firstIndex(where: { $0.id == id }),
              procedures[i].checkedSteps.count == procedures[i].steps.count else { return }
        procedures[i].completedAt = .now
        save()
    }
    func reopen(_ id: String) {
        guard let i = procedures.firstIndex(where: { $0.id == id }) else { return }
        procedures[i].completedAt = nil
        save()
    }
    @discardableResult func importDocument(_ document: CapturedDocument) -> UUID {
        var value = document
        if let index = documents.firstIndex(where: { DocumentExtractor.fingerprint($0.rawText) == DocumentExtractor.fingerprint(document.rawText) }) {
            value.id = documents[index].id
            value.isHandled = documents[index].isHandled
            documents[index] = value
        } else { documents.insert(value, at: 0) }
        openedDay = nil
        save()
        return value.id
    }
    func toggleHandled(_ id: UUID) {
        guard let index = documents.firstIndex(where: { $0.id == id }) else { return }
        documents[index].isHandled.toggle()
        save()
    }
    private func save() {
        do {
            let state = PersistedState(profile: profile, procedures: procedures, openedDay: openedDay, documents: documents)
            defaults.set(try JSONEncoder().encode(state), forKey: storageKey)
            storageError = nil
            publishWidgets()
        } catch { storageError = "保存できませんでした。もう一度操作してください。" }
    }
}

extension Date {
    var receiptDate: String { formatted(.dateTime.locale(Locale(identifier: "ja_JP")).month(.twoDigits).day(.twoDigits).weekday(.abbreviated)) }
    var shortDate: String { formatted(.dateTime.locale(Locale(identifier: "ja_JP")).month().day()) }
    var serialDate: String { formatted(.dateTime.locale(Locale(identifier: "en_US_POSIX")).year().month(.twoDigits).day(.twoDigits)) }
}
