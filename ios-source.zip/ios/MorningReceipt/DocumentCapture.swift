import Foundation
import UIKit
import Vision
import ImageIO

struct CapturedDocument: Identifiable, Codable, Equatable {
    var id = UUID()
    var title: String
    var issuer: String
    var deadlineText: String
    var amountText: String
    var nextAction: String
    var rawText: String
    var savedAt = Date.now
    var isHandled = false
    var isSample = false
    var extractionNotes: [String] = []
    var requiredDocuments: String? = nil
    var documentKind: String? = nil
    var aiSummary: String? = nil
    var analysisStatus: String? = nil
    var publicSearchQuery: String? = nil
    var officialSources: [OfficialSource]? = nil
    var pages: [DocumentPage]? = nil
    var importantBlockIDs: [String]? = nil
    var importanceStatus: String? = nil
    var reviewedAt: Date? = nil
    var suggestedAction: String? = nil
    var actionEvidence: String? = nil
    var eligibilityText: String? = nil
    var researchStatus: String? = nil
}

/// Conservative, local extraction. Missing/ambiguous fields remain empty.
enum DocumentExtractor {
    static func fingerprint(_ text: String) -> String {
        normalize(text).components(separatedBy: .whitespacesAndNewlines).joined()
    }
    static func normalize(_ text: String) -> String {
        String(String.UnicodeScalarView(text.unicodeScalars.map { scalar in
            (0xFF01...0xFF5E).contains(scalar.value) ? UnicodeScalar(scalar.value - 0xFEE0)! : scalar
        })).replacingOccurrences(of: "\r", with: "\n")
    }

    static func extract(_ text: String, isSample: Bool = false) -> CapturedDocument {
        let lines = normalize(text).components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        let title = lines.first(where: {
            $0.count <= 60 && ["案内", "通知", "募集", "お知らせ", "申請", "納付", "請求"].contains(where: $0.contains)
                && !["期限", "締切", "必要書類", "方法"].contains(where: $0.contains)
        }) ?? lines.first ?? "読み取った書類"
        let deadlineCandidates = labeledValues(lines, labels: ["納期限", "提出期限", "提出締切", "申込締切", "申請期限", "申込期限", "受付期限", "締切", "締め切り", "支払期限", "回答期限", "期限", "必着", "までに"],
                                              pattern: #"(?:20\d{2}\s*[年/.\-]\s*\d{1,2}\s*[月/.\-]\s*\d{1,2}日?|(?:令和|平成)(?:\d+|元)年\s*\d{1,2}月\s*\d{1,2}日|\d{1,2}[月/]\s*\d{1,2}日?)"#)
        let amountCandidates = labeledValues(lines, labels: ["納付額", "請求額", "支払額", "給付額", "補助額", "金額", "合計"],
                                            pattern: #"(?:[¥￥]\s*[\d,]+|[\d,]+(?:\.\d+)?万?\s*円)"#)
        let actionLine = lines.first(where: { line in
            ["提出方法", "申込方法", "申請方法", "支払方法", "納付方法", "次の行動"].contains(where: line.contains)
        })
        let issuerLine = lines.first(where: { ["発行元", "差出人", "発行者"].contains(where: $0.contains) })
        let issuer = issuerLine.map(stripLabel) ?? lines.last(where: {
            ($0.contains("大学") || $0.contains("市役所") || $0.contains("株式会社") || $0.hasSuffix("課") || $0.hasSuffix("室")) &&
            !$0.contains("期限") && $0.count <= 45
        }) ?? ""
        var notes: [String] = []
        if deadlineCandidates.count > 1 { notes.append("期限が複数あります：" + deadlineCandidates.joined(separator: "・") + "。原文で用途を確認してください。") }
        if amountCandidates.count > 1 { notes.append("金額が複数あります。原文を確認してください。") }
        return CapturedDocument(title: title, issuer: issuer,
                                deadlineText: deadlineCandidates.count == 1 ? deadlineCandidates[0] : "",
                                amountText: amountCandidates.count == 1 ? amountCandidates[0] : "",
                                nextAction: actionLine.map(stripLabel) ?? "",
                                rawText: text, isSample: isSample, extractionNotes: notes,
                                requiredDocuments: requiredDocuments(in: lines),
                                eligibilityText: lines.first(where: { $0.contains("対象者") || $0.contains("対象条件") || $0.contains("申請資格") }).map(stripLabel))
    }

    private static func stripLabel(_ line: String) -> String {
        if let range = line.range(of: #"[:：]\s*"#, options: .regularExpression) {
            return String(line[range.upperBound...]).trimmingCharacters(in: .whitespaces)
        }
        return line
    }
    private static func requiredDocuments(in lines: [String]) -> String? {
        let labels = ["必要書類", "提出書類", "添付書類", "用意するもの"]
        guard let index = lines.firstIndex(where: { line in labels.contains(where: line.contains) }) else { return nil }
        let heading = stripLabel(lines[index])
        if !heading.isEmpty && !labels.contains(heading) { return String(heading.prefix(350)) }
        var values: [String] = []
        for line in lines.dropFirst(index + 1).prefix(8) {
            if ["申請方法", "申込方法", "提出先", "期限", "問い合わせ", "問合せ", "対象者"].contains(where: line.contains) { break }
            let value = line.trimmingCharacters(in: CharacterSet(charactersIn: "・●□■①②③④⑤0123456789. 　"))
            guard !value.isEmpty, value.count <= 70 else { break }
            values.append(value)
        }
        return values.isEmpty ? nil : String(values.joined(separator: "、").prefix(350))
    }
    private static func labeledValues(_ lines: [String], labels: [String], pattern: String) -> [String] {
        guard let expression = try? NSRegularExpression(pattern: pattern) else { return [] }
        var values: [String] = []
        for (index, line) in lines.enumerated() where labels.contains(where: line.contains) {
            // Look at the next line only if this label's own line has no value.
            var matches = expression.matches(in: line, range: NSRange(line.startIndex..., in: line))
                .compactMap { Range($0.range, in: line).map { String(line[$0]) } }
            if matches.isEmpty, index + 1 < lines.count {
                let next = lines[index + 1]
                matches = expression.matches(in: next, range: NSRange(next.startIndex..., in: next))
                    .compactMap { Range($0.range, in: next).map { String(next[$0]) } }
            }
            for match in matches where !values.contains(match) { values.append(match) }
        }
        return values
    }
}

enum OCRFailure: LocalizedError {
    case unreadableImage, noText
    var errorDescription: String? {
        switch self {
        case .unreadableImage: "画像を開けませんでした。別の画像を選んでください。"
        case .noText: "文字が読み取れませんでした。明るい場所で書類全体を写してください。"
        }
    }
}

/// Apple Vision runs on-device. No documents are sent to a server.
enum DocumentOCR {
    static func recognize(_ data: Data) async throws -> String {
        try await scan(data).text
    }
    static func scan(_ data: Data) async throws -> OCRPageResult {
        try await Task.detached(priority: .userInitiated) {
            guard let source = CGImageSourceCreateWithData(data as CFData, nil) else { throw OCRFailure.unreadableImage }
            // Limit memory for high-resolution photos and apply EXIF orientation.
            let options: [CFString: Any] = [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceThumbnailMaxPixelSize: 2400,
                kCGImageSourceCreateThumbnailWithTransform: true
            ]
            guard let image = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) else { throw OCRFailure.unreadableImage }
            let request = VNRecognizeTextRequest()
            request.recognitionLevel = .accurate
            request.recognitionLanguages = ["ja-JP", "en-US"]
            request.usesLanguageCorrection = true
            try VNImageRequestHandler(cgImage: image).perform([request])
            let observations = (request.results ?? []).sorted {
                if abs($0.boundingBox.midY - $1.boundingBox.midY) > 0.015 { return $0.boundingBox.midY > $1.boundingBox.midY }
                return $0.boundingBox.minX < $1.boundingBox.minX
            }
            let text = observations.compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
            guard text.trimmingCharacters(in: .whitespacesAndNewlines).count >= 4 else { throw OCRFailure.noText }
            let blocks = observations.compactMap { observation -> OCRBlock? in
                guard let text = observation.topCandidates(1).first?.string else { return nil }
                return OCRBlock(id: UUID().uuidString, text: text, rect: observation.boundingBox)
            }
            guard let jpeg = UIImage(cgImage: image).jpegData(compressionQuality: 0.85) else { throw OCRFailure.unreadableImage }
            return OCRPageResult(text: text, imageData: jpeg, blocks: blocks)
        }.value
    }
}

/// An actual image fixture, fed through the same OCR pipeline as user photos.
enum SampleDocument {
    @MainActor static func imageData() -> Data {
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let image = UIGraphicsImageRenderer(size: CGSize(width: 1200, height: 1580), format: format).image { context in
            UIColor.white.setFill()
            context.fill(CGRect(x: 0, y: 0, width: 1200, height: 1580))
            let lines: [(String, CGFloat)] = [
                ("サンプル書類", 28),
                ("給付型奨学金のご案内", 52),
                ("発行元：あさひ大学 学生支援室", 34),
                ("学費支援のための給付型奨学金を募集します。", 32),
                ("申請期限：2026年10月30日", 40),
                ("給付額：48,000円", 40),
                ("必要書類：在学証明書、所得証明書", 34),
                ("申請方法：学生ポータルから申請", 34),
                ("受給には学年・所得などの条件があります。", 32),
                ("これは動作確認用の架空の案内です。", 30)
            ]
            var y: CGFloat = 100
            for (text, size) in lines {
                (text as NSString).draw(in: CGRect(x: 80, y: y, width: 1050, height: 140),
                                       withAttributes: [.font: UIFont.systemFont(ofSize: size, weight: size > 40 ? .bold : .regular),
                                                        .foregroundColor: UIColor.black])
                y += size > 40 ? 155 : 122
            }
        }
        return image.pngData() ?? Data()
    }
}
