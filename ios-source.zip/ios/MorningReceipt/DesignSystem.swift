import SwiftUI

enum Palette {
    static let background = Color(red: 0.969, green: 0.945, blue: 0.886)
    static let surface = Color(red: 0.972, green: 0.969, blue: 0.953)
    static let paper = Color(red: 0.973, green: 0.963, blue: 0.939)
    static let ink = Color(red: 0.13, green: 0.16, blue: 0.19)
    static let muted = Color(red: 0.39, green: 0.42, blue: 0.46)
    static let blue = Color(red: 0.043, green: 0.227, blue: 0.561)
    static let sky = Color(red: 0.10, green: 0.32, blue: 0.66)
    static let green = Color(red: 0.05, green: 0.43, blue: 0.38)
}

extension ArticleCategory {
    var color: Color {
        switch self { case .action: Palette.blue; case .news: Palette.muted; case .chance: Palette.green }
    }
    var shortLabel: String {
        switch self { case .action: "申請"; case .news: "お知らせ"; case .chance: "機会" }
    }
}

struct SoftSurface: ViewModifier {
    var radius: CGFloat = 24
    func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.glassEffect(.regular, in: RoundedRectangle(cornerRadius: radius))
        } else {
            content.background(.regularMaterial, in: RoundedRectangle(cornerRadius: radius))
                .overlay(RoundedRectangle(cornerRadius: radius).strokeBorder(.white.opacity(0.7), lineWidth: 1))
        }
    }
}
extension View {
    func softSurface(radius: CGFloat = 24) -> some View { modifier(SoftSurface(radius: radius)) }
}

struct SoftButtonStyle: ButtonStyle {
    var primary = false
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(.headline)
            .frame(maxWidth: .infinity, minHeight: 54)
            .foregroundStyle(primary ? .white : Palette.ink)
            .background {
                if primary {
                    Capsule().fill(LinearGradient(colors: [Palette.sky, Palette.blue, Palette.blue], startPoint: .topLeading, endPoint: .bottomTrailing))
                } else { Capsule().fill(Palette.surface) }
            }
            .overlay(Capsule().strokeBorder(.white.opacity(primary ? 0.25 : 0.95), lineWidth: 1))
            .shadow(color: primary ? Palette.blue.opacity(0.18) : .black.opacity(0.09), radius: configuration.isPressed ? 2 : 8, y: configuration.isPressed ? 1 : 5)
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
    }
}

struct RoundButton: View {
    let symbol: String
    let label: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: symbol).font(.system(size: 19, weight: .medium))
                .frame(width: 46, height: 46).softSurface(radius: 23)
        }.buttonStyle(.plain).accessibilityLabel(label)
    }
}

struct Perforation: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: 0, y: rect.midY))
        p.addLine(to: CGPoint(x: rect.width, y: rect.midY))
        return p
    }
}

/// The cut grows across the machine/paper boundary; the entire paper moves.
struct ReceiptShape: Shape {
    var tearProgress: CGFloat = 0
    var animatableData: CGFloat {
        get { tearProgress }
        set { tearProgress = newValue }
    }
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let tooth: CGFloat = 16
        let tornWidth = rect.width * min(1, max(0, tearProgress))
        p.move(to: CGPoint(x: 0, y: tearProgress > 0 ? 4 : 0))
        for x in stride(from: CGFloat.zero, to: rect.width, by: tooth) {
            p.addLine(to: CGPoint(x: min(x + tooth / 2, rect.width), y: 0))
            p.addLine(to: CGPoint(x: min(x + tooth, rect.width), y: x < tornWidth ? 4 : 0))
        }
        p.addLine(to: CGPoint(x: rect.width, y: rect.height))
        p.addLine(to: CGPoint(x: 0, y: rect.height))
        p.closeSubpath()
        return p
    }
}

struct PaperStock: View {
    var tear: CGFloat = 0
    var body: some View {
        Palette.paper.overlay {
            Canvas { context, size in
                for index in 0..<1400 {
                    let x = CGFloat((index * 73) % 997) / 997 * size.width
                    let y = CGFloat((index * 137) % 991) / 991 * size.height
                    context.fill(Path(ellipseIn: CGRect(x: x, y: y, width: 0.7, height: 1.2)), with: .color(.brown.opacity(0.055)))
                }
            }.allowsHitTesting(false)
        }
        .clipShape(ReceiptShape(tearProgress: tear))
        .shadow(color: .black.opacity(0.15), radius: 20, x: 2, y: 14)
    }
}

struct GlassBackdrop: View {
    var body: some View {
        ZStack {
            Color(uiColor: .systemGroupedBackground)
            Circle().fill(Color.cyan.opacity(0.16)).frame(width: 350, height: 350).blur(radius: 65).offset(x: 160, y: -240)
            Circle().fill(Palette.blue.opacity(0.10)).frame(width: 320, height: 320).blur(radius: 70).offset(x: -180, y: 160)
        }.ignoresSafeArea()
    }
}

struct PaperDivider: View {
    var body: some View {
        Perforation().stroke(Palette.ink.opacity(0.20), style: StrokeStyle(lineWidth: 1, dash: [3, 4])).frame(height: 1)
    }
}

struct EmptyCard: View {
    let symbol: String
    let title: String
    let description: String
    var body: some View {
        VStack(spacing: 18) {
            Image(systemName: symbol).font(.system(size: 36, weight: .light)).foregroundStyle(Palette.blue)
            Text(title).font(.title3.weight(.semibold))
            if !description.isEmpty {
                Text(description).font(.body).foregroundStyle(Palette.muted).multilineTextAlignment(.center)
            }
        }.frame(maxWidth: .infinity).padding(25).softSurface()
    }
}
