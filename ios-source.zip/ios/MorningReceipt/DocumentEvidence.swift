import SwiftUI

struct OCRBlock: Codable, Equatable, Identifiable {
    var id: String
    var text: String
    /// Vision coordinates: normalized, origin at bottom left.
    var rect: CGRect
}
struct DocumentPage: Codable, Equatable, Identifiable {
    var id: String
    var blocks: [OCRBlock]
}
struct OCRPageResult {
    var text: String
    var imageData: Data
    var blocks: [OCRBlock]
}
enum DocumentImages {
    static func url(_ id: String) -> URL? {
        guard UUID(uuidString: id) != nil else { return nil }
        return FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first?
            .appendingPathComponent("DocumentImages", isDirectory: true).appendingPathComponent(id + ".jpg")
    }
    static func save(_ result: OCRPageResult) throws -> DocumentPage {
        let id = UUID().uuidString
        guard let destination = url(id) else { throw OCRFailure.unreadableImage }
        try FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
        try result.imageData.write(to: destination, options: [.atomic, .completeFileProtection])
        return DocumentPage(id: id, blocks: result.blocks)
    }
}

enum DocumentPipeline {
    static func analyze(_ images: [Data], sample: Bool = false) async throws -> CapturedDocument {
        var pages: [DocumentPage] = []
        var texts: [String] = []
        for image in images {
            let result = try await DocumentOCR.scan(image)
            pages.append(try DocumentImages.save(result)); texts.append(result.text)
        }
        var document = await LocalDocumentAI.analyze(texts.joined(separator: "\n"), sample: sample)
        document.pages = pages
        document.importanceStatus = "重要箇所のAI判定は未実行です。送信内容を確認してJevで判定できます。"
        if UserDefaults.standard.bool(forKey: JevImportance.automaticKey) {
            let candidates = JevImportance.candidates(pages.flatMap(\.blocks))
            if candidates.isEmpty {
                document.importanceStatus = "自動送信の候補を特定できませんでした。文章を選んで判定できます。"
            } else {
                do {
                    document.importantBlockIDs = try await JevImportance.judge(candidates)
                    document.importanceStatus = "Jevで候補\(candidates.count)箇所を判定しました。対象外の行も原文で確認してください。"
                } catch { document.importanceStatus = error.localizedDescription }
            }
        }
        return document
    }
}

struct EvidenceView: View {
    let document: CapturedDocument
    @State private var zoomedPage: DocumentPage?
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text(document.importanceStatus ?? "原文を確認してください。").font(.body).foregroundStyle(.secondary)
                ForEach(document.pages ?? []) { page in
                    if let url = DocumentImages.url(page.id), let image = UIImage(contentsOfFile: url.path) {
                        Image(uiImage: image).resizable().aspectRatio(contentMode: .fit)
                            .overlay {
                                GeometryReader { geometry in
                                    ForEach(page.blocks.filter { document.importantBlockIDs?.contains($0.id) == true }) { block in
                                        RoundedRectangle(cornerRadius: 3).fill(.yellow.opacity(0.28))
                                            .overlay(RoundedRectangle(cornerRadius: 3).stroke(.orange, lineWidth: 1))
                                            .frame(width: block.rect.width * geometry.size.width, height: block.rect.height * geometry.size.height)
                                            .position(x: block.rect.midX * geometry.size.width, y: (1 - block.rect.midY) * geometry.size.height)
                                            .accessibilityLabel("重要箇所：" + block.text)
                                    }
                                }
                            }.clipShape(RoundedRectangle(cornerRadius: 12))
                            .onTapGesture { zoomedPage = page }
                            .accessibilityAddTraits(.isButton).accessibilityLabel("原本画像を拡大")
                    } else { Text("このページの画像を開けません。下の原文を確認してください。") }
                }
                DisclosureGroup("読み取った全文") { Text(document.rawText).font(.body).textSelection(.enabled) }
            }.padding(20)
        }.navigationTitle("書類の原文").navigationBarTitleDisplayMode(.inline)
            .sheet(item: $zoomedPage) { page in
                NavigationStack {
                    ZoomableEvidence(page: page, importantIDs: Set(document.importantBlockIDs ?? []))
                        .navigationTitle("ピンチで拡大").navigationBarTitleDisplayMode(.inline)
                        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("閉じる") { zoomedPage = nil } } }
                }
            }
    }
}

struct ZoomableEvidence: UIViewRepresentable {
    let page: DocumentPage
    let importantIDs: Set<String>
    func makeCoordinator() -> Coordinator { Coordinator() }
    func makeUIView(context: Context) -> UIScrollView {
        let scroll = UIScrollView()
        scroll.delegate = context.coordinator
        scroll.maximumZoomScale = 6
        scroll.backgroundColor = .systemBackground
        guard let url = DocumentImages.url(page.id), let image = UIImage(contentsOfFile: url.path) else { return scroll }
        let imageView = UIImageView(image: image)
        imageView.frame = CGRect(origin: .zero, size: image.size)
        for block in page.blocks where importantIDs.contains(block.id) {
            let layer = CAShapeLayer()
            layer.path = CGPath(rect: CGRect(x: block.rect.minX * image.size.width, y: (1 - block.rect.maxY) * image.size.height, width: block.rect.width * image.size.width, height: block.rect.height * image.size.height), transform: nil)
            layer.fillColor = UIColor.systemYellow.withAlphaComponent(0.28).cgColor
            layer.strokeColor = UIColor.systemOrange.cgColor
            imageView.layer.addSublayer(layer)
        }
        scroll.addSubview(imageView)
        scroll.contentSize = image.size
        context.coordinator.imageView = imageView
        return scroll
    }
    func updateUIView(_ view: UIScrollView, context: Context) {
        DispatchQueue.main.async {
            guard let imageView = context.coordinator.imageView, !context.coordinator.fitted, view.bounds.width > 0 else { return }
            let scale = min(view.bounds.width / imageView.bounds.width, view.bounds.height / imageView.bounds.height)
            view.minimumZoomScale = scale; view.zoomScale = scale
            context.coordinator.fitted = true
        }
    }
    final class Coordinator: NSObject, UIScrollViewDelegate {
        var imageView: UIImageView?
        var fitted = false
        func viewForZooming(in scrollView: UIScrollView) -> UIView? { imageView }
    }
}
