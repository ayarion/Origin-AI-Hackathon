import AppKit

// Code-native TO:ME mark: an open envelope containing a short, actionable note.
let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: 1024, pixelsHigh: 1024, bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0)!
NSGraphicsContext.saveGraphicsState()
NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: bitmap)
let context = NSGraphicsContext.current!.cgContext
context.setFillColor(NSColor(red: 0.035, green: 0.20, blue: 0.52, alpha: 1).cgColor)
context.fill(CGRect(x: 0, y: 0, width: 1024, height: 1024))
context.setStrokeColor(NSColor(red: 0.97, green: 0.96, blue: 0.92, alpha: 1).cgColor)
context.setLineWidth(36); context.setLineJoin(.round); context.setLineCap(.round)
context.move(to: CGPoint(x: 240, y: 560)); context.addLine(to: CGPoint(x: 512, y: 770)); context.addLine(to: CGPoint(x: 784, y: 560)); context.strokePath()
context.setFillColor(NSColor(red: 0.97, green: 0.96, blue: 0.92, alpha: 1).cgColor)
context.addPath(CGPath(roundedRect: CGRect(x: 330, y: 420, width: 364, height: 280), cornerWidth: 22, cornerHeight: 22, transform: nil)); context.fillPath()
context.setStrokeColor(NSColor(red: 0.035, green: 0.20, blue: 0.52, alpha: 1).cgColor)
context.setLineWidth(22)
context.move(to: CGPoint(x: 406, y: 615)); context.addLine(to: CGPoint(x: 608, y: 615)); context.strokePath()
context.move(to: CGPoint(x: 406, y: 550)); context.addLine(to: CGPoint(x: 540, y: 550)); context.strokePath()
context.setFillColor(NSColor(red: 0.035, green: 0.20, blue: 0.52, alpha: 1).cgColor)
context.setStrokeColor(NSColor(red: 0.97, green: 0.96, blue: 0.92, alpha: 1).cgColor); context.setLineWidth(36)
context.move(to: CGPoint(x: 240, y: 560)); context.addLine(to: CGPoint(x: 512, y: 390)); context.addLine(to: CGPoint(x: 784, y: 560)); context.addLine(to: CGPoint(x: 784, y: 300)); context.addQuadCurve(to: CGPoint(x: 740, y: 256), control: CGPoint(x: 784, y: 256)); context.addLine(to: CGPoint(x: 284, y: 256)); context.addQuadCurve(to: CGPoint(x: 240, y: 300), control: CGPoint(x: 240, y: 256)); context.closePath(); context.drawPath(using: .fillStroke)
NSGraphicsContext.restoreGraphicsState()
let destination = URL(fileURLWithPath: CommandLine.arguments[1])
try bitmap.representation(using: .png, properties: [:])!.write(to: destination)
