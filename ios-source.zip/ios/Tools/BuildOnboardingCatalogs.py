"""Convert official postal/MEXT downloads into offline onboarding lookup resources."""
import csv
import io
import json
import pathlib
import sys
import zipfile

source = pathlib.Path(sys.argv[1])
destination = pathlib.Path(sys.argv[2])
destination.mkdir(parents=True, exist_ok=True)
postal = {}
with zipfile.ZipFile(source / "postal.zip") as archive:
    rows = csv.reader(io.StringIO(archive.read("utf_ken_all.csv").decode("utf-8-sig")))
    for row in rows:
        region = row[6] + row[7]
        postal.setdefault(row[2], set()).add(region)
with (destination / "PostalRegions.json").open("w") as output:
    json.dump({key: sorted(values) for key, values in postal.items()}, output, ensure_ascii=False, separators=(",", ":"))
regions = sorted({region for values in postal.values() for region in values}, key=len, reverse=True)
schools = {}
for path in sorted(source.glob("*.csv")):
    with path.open(encoding="utf-8-sig") as input_file:
        for row in csv.reader(input_file):
            if len(row) < 10 or len(row[0]) != 13 or not row[0][0].isalpha() or row[9].strip():
                continue
            address = row[6]
            region = next((value for value in postal.get(row[7], []) if address.startswith(value)), None)
            if not region:
                region = next((value for value in regions if address.startswith(value)), row[2])
            schools[row[0]] = {"id": row[0], "name": row[5], "region": region, "kind": row[1]}
with (destination / "SchoolDirectory.json").open("w") as output:
    json.dump(list(schools.values()), output, ensure_ascii=False, separators=(",", ":"))
print(f"Postal codes: {len(postal)}; current schools: {len(schools)}")
