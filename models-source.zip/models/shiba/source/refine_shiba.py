import bpy, math, json
from mathutils import Vector, noise
from pathlib import Path
OUT=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(OUT/'shiba_character.blend'))
rig=bpy.data.objects['Shiba_Rig']
def smooth(a,b,x):
    t=max(0,min(1,(x-a)/(b-a)));return t*t*(3-2*t)
for o in list(bpy.data.objects):
    if o.name.startswith(('Cheek fur ','Chest fur edge ')) or o.name=='Cream chest bib':bpy.data.objects.remove(o,do_unlink=True)
for m in bpy.data.materials:
    if m.name.startswith('Fur | warm chocolate'):
        base=(.11,.046,.023);m.diffuse_color=(*base,1)
        bs=m.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*base,1);bs.inputs['Sheen Weight'].default_value=.025
        ramp=next(n for n in m.node_tree.nodes if n.type=='VALTORGB')
        ramp.color_ramp.elements[0].color=(*(v*.87 for v in base),1);ramp.color_ramp.elements[1].color=(*(v*1.12 for v in base),1)
dark=bpy.data.materials.get('Eyes and nose | espresso');dark.node_tree.nodes.get('Principled BSDF').inputs['Roughness'].default_value=.43
for o in bpy.data.objects:
    if o.name.startswith(('Outer ear','Inner ear')):
        for v in o.data.vertices:v.co.z=2.52+(v.co.z-2.52)*.73
    if o.name in ['Red collar','Gold rounded buckle','Buckle pin']:o.location.z-=.10

def paint(o,values,name):
    att=o.data.attributes.new(name='ivory_mask',type='FLOAT',domain='POINT')
    for p,v in zip(att.data,values):p.value=v
    m=bpy.data.materials['Fur | warm chocolate'].copy();m.name=name
    n=m.node_tree.nodes;ln=m.node_tree.links;bs=n.get('Principled BSDF');ramp=next(nn for nn in n if nn.type=='VALTORGB')
    a=n.new('ShaderNodeAttribute');a.attribute_name='ivory_mask'
    mix=n.new('ShaderNodeMixRGB');mix.blend_type='MIX';mix.inputs[2].default_value=(.86,.795,.68,1)
    ln.new(a.outputs['Fac'],mix.inputs[0]);ln.new(ramp.outputs['Color'],mix.inputs[1]);ln.new(mix.outputs[0],bs.inputs['Base Color'])
    o.data.materials.clear();o.data.materials.append(m)
    for p in o.data.polygons:p.material_index=0

body=bpy.data.objects['Body • continuous sculpt'];values=[]
for v in body.data.vertices:
    p=body.matrix_world@v.co
    edge=.345+.009*noise.noise_vector(p*95).x
    sock=1-smooth(edge-.017,edge+.017,p.z)
    r=(p.x/.325)**2+((p.z-1.25)/.59)**2
    chest=(1-smooth(.83,1.05,r))*(1-smooth(-.84,-.70,p.y))
    belly=(1-smooth(.99,1.07,p.z))*smooth(-.10,.10,p.y)*(1-smooth(.8,.98,p.y))*(1-smooth(.29,.40,abs(p.x)))
    values.append(max(sock,chest,belly))
paint(body,values,'Fur | continuous painted ivory markings')

path=[(.05,1.10,1.56),(.13,1.30,1.73),(.22,1.38,1.96),(.28,1.28,2.17),(.31,1.06,2.23),(.31,.87,2.12),(.29,.84,1.94),(.27,.98,1.84),(.25,1.12,1.90),(.25,1.11,2.025)]
pts=[Vector(p) for p in path]
def cat(a,b,c,d,t):return .5*(2*b+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t)
cs=[]
for i in range(9):
    for j in range(10):cs.append(cat(pts[max(0,i-1)],pts[i],pts[i+1],pts[min(9,i+2)],j/10))
cs.append(pts[-1]);tail=bpy.data.objects['Tail • continuous curled form'];vals=[]
for i,c in enumerate(cs):
    t=i/90;tan=(cs[min(i+1,90)]-cs[max(i-1,0)]).normalized();u=Vector((1,0,0));u=(u-u.dot(tan)*tan).normalized();vv=tan.cross(u).normalized()
    rad=(.17+.025*math.sin(t*math.pi))*(1-.78*max(0,(t-.81)/.19)**1.2)
    for j in range(24):
        a=2*math.pi*j/24;co=c+rad*(math.cos(a)*u+math.sin(a)*vv);tail.data.vertices[i*24+j].co=co
        tip=smooth(.65,.72,t)
        stripe=smooth(.20,.30,t)*(1-smooth(.58,.68,t))*smooth(.15,.72,math.sin(a))
        vals.append(max(tip,stripe))
paint(tail,vals,'Fur | curled tail cream underside')
bpy.context.view_layer.objects.active=rig;rig.select_set(True);bpy.ops.object.mode_set(mode='EDIT')
for b in rig.data.edit_bones:
    if b.name.startswith('ear.'):
        b.head.z=2.52+(b.head.z-2.52)*.73;b.tail.z=2.52+(b.tail.z-2.52)*.73
    if b.name.startswith('tail.'):
        i=int(b.name.split('.')[1])-1;b.head=pts[i];b.tail=pts[i+1]
bpy.ops.object.mode_set(mode='OBJECT')
rig.location.z=-min((body.matrix_world@v.co).z for v in body.data.vertices)
bpy.data.objects['Studio ground'].location.z=0
scene=bpy.context.scene;scene.cycles.samples=24;scene.render.resolution_x=1100;scene.render.resolution_y=1100
scene.camera=bpy.data.objects['Camera • three quarter']
bpy.ops.object.select_all(action='DESELECT');bpy.data.objects['Head • soft Shiba silhouette'].select_set(True);bpy.context.view_layer.objects.active=bpy.data.objects['Head • soft Shiba silhouette']
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'shiba_character.blend'))
print('REFINEMENT SAVED',flush=True)
for name,file in [('Camera • three quarter','hero'),('Camera • front','front'),('Camera • side','side'),('Camera • back','back')]:
    scene.camera=bpy.data.objects[name];scene.render.filepath=str(OUT/'renders'/f'{file}.png');bpy.ops.render.render(write_still=True);print('RENDERED',file,flush=True)
scene.camera=bpy.data.objects['Camera • three quarter'];bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'shiba_character.blend'))
