"""Paint the inner ears directly on their surfaces; refresh delivery views."""
import bpy, math
from pathlib import Path
OUT=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(OUT/'shiba_character.blend'))
def smooth(a,b,x):
    t=max(0,min(1,(x-a)/(b-a)));return t*t*(3-2*t)
for o in list(bpy.data.objects):
    if o.name.startswith('Inner ear'):bpy.data.objects.remove(o,do_unlink=True)
for o in bpy.data.objects:
    if not o.name.startswith('Outer ear'):continue
    att=o.data.attributes.new(name='ear_cream',type='FLOAT',domain='POINT')
    for i,a in enumerate(att.data):
        t=(i//20)/6;angle=2*math.pi*(i%20)/20
        a.value=smooth(.30,.87,-math.sin(angle))*smooth(.07,.25,t)*(1-smooth(.82,.98,t))
    mat=bpy.data.materials['Fur | warm chocolate'].copy();mat.name='Ear | painted ivory inset'
    nodes=mat.node_tree.nodes;links=mat.node_tree.links;bs=nodes.get('Principled BSDF');ramp=next(n for n in nodes if n.type=='VALTORGB')
    at=nodes.new('ShaderNodeAttribute');at.attribute_name='ear_cream'
    mix=nodes.new('ShaderNodeMixRGB');mix.inputs[2].default_value=(.83,.76,.64,1)
    links.new(at.outputs['Fac'],mix.inputs[0]);links.new(ramp.outputs[0],mix.inputs[1]);links.new(mix.outputs[0],bs.inputs['Base Color'])
    o.data.materials.clear();o.data.materials.append(mat)
scene=bpy.context.scene;scene.cycles.samples=24;scene.camera=bpy.data.objects['Camera • three quarter']
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'shiba_character.blend'));print('FINAL MODEL SAVED',flush=True)
for name,file in [('Camera • three quarter','hero'),('Camera • front','front'),('Camera • side','side'),('Camera • back','back')]:
    scene.camera=bpy.data.objects[name];scene.render.filepath=str(OUT/'renders'/f'{file}.png');bpy.ops.render.render(write_still=True);print('VIEW',file,flush=True)
scene.camera=bpy.data.objects['Camera • three quarter'];bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'shiba_character.blend'))
