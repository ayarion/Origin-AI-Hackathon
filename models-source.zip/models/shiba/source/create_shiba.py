import bpy, math, random, json
from pathlib import Path
from mathutils import Vector
from mathutils import noise

OUT=Path(__file__).resolve().parents[1]
random.seed(24)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for c in list(bpy.data.collections):
    if c.name!='Collection':bpy.data.collections.remove(c)
main=bpy.data.collections.get('Collection');main.name='SHIBA • Character'
studio=bpy.data.collections.new('STUDIO • lights and cameras');bpy.context.scene.collection.children.link(studio)
parts=[];bindings={}

def material(name,color,fur=False):
    m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True
    n=m.node_tree.nodes; bs=n.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*color,1)
    bs.inputs['Roughness'].default_value=.82 if fur else .47
    if fur:
        bs.inputs['Specular IOR Level'].default_value=.22
        bs.inputs['Sheen Weight'].default_value=.17
        tex=n.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=38;tex.inputs['Detail'].default_value=3
        ramp=n.new('ShaderNodeValToRGB')
        ramp.color_ramp.elements[0].position=.18;ramp.color_ramp.elements[0].color=(*(v*.79 for v in color),1)
        ramp.color_ramp.elements[1].position=.82;ramp.color_ramp.elements[1].color=(*(min(v*1.12,1) for v in color),1)
        m.node_tree.links.new(tex.outputs['Fac'],ramp.inputs[0]);m.node_tree.links.new(ramp.outputs[0],bs.inputs['Base Color'])
        fine=n.new('ShaderNodeTexNoise');fine.inputs['Scale'].default_value=260;fine.inputs['Detail'].default_value=2
        bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.19;bump.inputs['Distance'].default_value=.018
        m.node_tree.links.new(fine.outputs['Fac'],bump.inputs['Height']);m.node_tree.links.new(bump.outputs[0],bs.inputs['Normal'])
    return m
brown=material('Fur | warm chocolate',(0.235,.112,.066),True)
cream=material('Fur | warm ivory',(.88,.815,.68),True)
inner=material('Ear | soft cream',(.72,.60,.46),True)
dark=material('Eyes and nose | espresso',(.026,.013,.008));dark.node_tree.nodes.get('Principled BSDF').inputs['Roughness'].default_value=.31
mouthmat=material('Smile | deep warm brown',(.045,.018,.011))
pink=material('Tongue | rose',(.73,.19,.26))
red=material('Collar | raspberry',(.64,.058,.105),True)
gold=material('Buckle | honey gold',(.85,.49,.13));gold.node_tree.nodes.get('Principled BSDF').inputs['Metallic'].default_value=.5
toe=material('Paw creases',(.47,.35,.24))

def finish(o,name,mat,bone=None):
    o.name=name
    if mat:o.data.materials.append(mat)
    if o.type=='MESH':
        for p in o.data.polygons:p.use_smooth=True
    parts.append(o)
    if bone:bindings[o.name]=bone
    return o
def ell(name,loc,scale,mat,bone=None,segments=40,rings=24):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments,ring_count=rings,location=loc)
    o=bpy.context.object;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    return finish(o,name,mat,bone)
def join_sculpt(objs,name,mat,voxel=.036,bone=None):
    bpy.ops.object.select_all(action='DESELECT')
    for o in objs:o.select_set(True);parts.remove(o)
    bpy.context.view_layer.objects.active=objs[0];bpy.ops.object.join();o=bpy.context.object;o.name=name
    mod=o.modifiers.new('Continuous sculpt surface','REMESH');mod.mode='VOXEL';mod.voxel_size=voxel;mod.use_smooth_shade=True
    bpy.ops.object.modifier_apply(modifier=mod.name)
    sm=o.modifiers.new('Soften transitions','SMOOTH');sm.factor=.8;sm.iterations=5;bpy.ops.object.modifier_apply(modifier=sm.name)
    o.data.materials.clear();o.data.materials.append(mat)
    return finish(o,name,None,bone)

# One continuous body, shoulders, thighs, lower legs and rounded paws.
bodybits=[ell('torso',(0,.23,1.33),(.56,.92,.58),brown),ell('chest',(0,-.47,1.4),(.53,.55,.64),brown),ell('neck',(0,-.64,1.76),(.49,.43,.52),brown),ell('rump',(0,.90,1.35),(.54,.49,.58),brown)]
for side in [-1,1]:
    x=.425*side
    bodybits += [ell('front shoulder',(x,-.46,1.21),(.235,.27,.40),brown),ell('front leg',(x,-.55,.70),(.166,.19,.53),brown),ell('front ankle',(x,-.59,.34),(.155,.18,.25),brown),ell('front paw',(x,-.70,.175),(.217,.29,.17),brown)]
    bodybits += [ell('haunch',(x,.88,1.02),(.285,.38,.44),brown),ell('hind knee',(x,.97,.66),(.195,.24,.32),brown),ell('hind hock',(x,1.07,.37),(.135,.17,.26),brown),ell('hind paw',(x,1.00,.16),(.206,.285,.16),brown)]
body=join_sculpt(bodybits,'Body • continuous sculpt',brown,.027)
body.data.materials.append(cream)
for p in body.data.polygons:
    c=body.matrix_world@p.center
    # The fine, uneven sock edge is part of the actual mesh material assignment.
    edge=.335+.028*math.sin(c.x*91+c.y*61)+.012*math.sin(c.y*133)
    if c.z<edge or (c.z<1.0 and -.08<c.y<.87 and abs(c.x)<.31 and p.normal.z<-.35):p.material_index=1
sub=body.modifiers.new('Sculpt finish','SUBSURF');sub.levels=1;sub.render_levels=1

# Broad forehead, low cheeks, and a short muzzle match the reference proportions.
head=join_sculpt([ell('cranium',(0,-.84,2.21),(.635,.53,.61),brown),ell('cheek L',(-.40,-.92,2.03),(.30,.37,.34),brown),ell('cheek R',(.40,-.92,2.03),(.30,.37,.34),brown)],'Head • soft Shiba silhouette',brown,.023,'head')
sub=head.modifiers.new('Head finish','SUBSURF');sub.levels=1
face=join_sculpt([ell('cream left',(-.26,-1.215,1.998),(.386,.215,.267),cream),ell('cream right',(.26,-1.215,1.998),(.386,.215,.267),cream),ell('chin',(0,-1.255,1.842),(.387,.20,.18),cream),ell('short muzzle',(0,-1.371,2.074),(.258,.165,.17),cream)],'Face • cream cheeks and muzzle',cream,.017,'head')
sub=face.modifiers.new('Muzzle finish','SUBSURF');sub.levels=1

def tube(name,coords,radius,mat,bone=None,cyclic=False):
    cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=16;cu.bevel_depth=radius;cu.bevel_resolution=4
    s=cu.splines.new('BEZIER');s.bezier_points.add(len(coords)-1)
    for p,co in zip(s.bezier_points,coords):p.co=co;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
    s.use_cyclic_u=cyclic
    o=bpy.data.objects.new(name,cu);main.objects.link(o)
    bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');o=bpy.context.object
    return finish(o,name,mat,bone)

for side in [-1,1]:
    # Very dark inset eyes, with deliberately small highlights.
    e=ell('Eye '+str(side),(side*.267,-1.303,2.303),(.063,.043,.071),dark,'head')
    ell('Eye glint '+str(side),(side*.267-.014,-1.340,2.323),(.012,.006,.012),cream,'head',20,12)
    brow=ell('Ivory eyebrow '+str(side),(side*.270,-1.241,2.478),(.067,.024,.045),cream,'head');brow.rotation_euler.y=side*-.12
    tube('Smile '+str(side),[(0,-1.529,2.027),(side*.072,-1.519,1.974),(side*.154,-1.485,1.967),(side*.205,-1.458,2.008)],.012,mouthmat,'head')
ell('Mouth opening',(0,-1.459,1.930),(.104,.027,.088),mouthmat,'head')
tong=ell('Little pink tongue',(0,-1.494,1.900),(.069,.033,.086),pink,'tongue.01')
tube('Tongue crease',[(0,-1.529,1.948),(0,-1.532,1.920)],.0035,red,'tongue.01')
nose=ell('Soft triangular nose',(0,-1.530,2.105),(.123,.068,.077),dark,'head')
for v in nose.data.vertices:
    if v.co.z<0:v.co.x*=.76
ell('Nose soft highlight',(-.035,-1.591,2.134),(.037,.006,.012),material('Nose sheen',(.115,.069,.041)),'head',24,12)
tube('Philtrum',[(0,-1.551,2.068),(0,-1.536,2.031)],.01,mouthmat,'head')

# Rounded triangular ears with inset, cream inner fur.
def ear(name,side,mat,is_inner=False):
    verts=[];faces=[];rings=7;segs=20
    widths=[1,.98,.86,.67,.44,.21,.035]
    for i in range(rings):
        t=i/(rings-1)
        z=(2.60 if is_inner else 2.52)+t*(.44 if is_inner else .65)
        cx=side*(.415+.085*t); cy=-.819+(.018*t)
        for j in range(segs):
            a=2*math.pi*j/segs
            xx=(.128 if is_inner else .222)*widths[i]*math.cos(a)
            yy=(.027 if is_inner else .157)*widths[i]*math.sin(a)
            verts.append((cx+xx,cy+yy-(.148 if is_inner else 0),z))
    for i in range(rings-1):
        for j in range(segs):a=i*segs+j;b=i*segs+(j+1)%segs;faces.append((a,b,b+segs,a+segs))
    faces.append(tuple(range(segs-1,-1,-1)));faces.append(tuple((rings-1)*segs+j for j in range(segs)))
    me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);main.objects.link(o)
    finish(o,name,mat,'ear.'+('L' if side==-1 else 'R'))
    su=o.modifiers.new('Rounded ear edges','SUBSURF');su.levels=2
    return o
for side in [-1,1]:ear('Outer ear '+str(side),side,brown);ear('Inner ear '+str(side),side,cream,True)

# The bib is a tapered sculpt with individually rounded small fur tips.
bib=ell('Cream chest bib',(0,-.936,1.290),(.325,.126,.505),cream,'chest')
for v in bib.data.vertices:
    if v.co.z<0:v.co.x*=1+.9*v.co.z
for i in range(14):
    z=1.64-i*.06;side=-1 if i%2 else 1;x=side*(.29*(1-((z-1.30)/.52)**2)**.5 if abs(z-1.3)<.52 else .05)
    o=ell('Chest fur edge %02d'%i,(x,-.943,z),(.052,.065,.098),cream,'chest',24,16);o.rotation_euler.y=side*-.42
for side in [-1,1]:
    for i in range(7):
        z=2.12-i*.055;x=side*(.57+(.045 if i<3 else -.018*i))
        tuft=ell('Cheek fur '+str(side)+' '+str(i),(x,-1.195,z),(.088,.095,.051),cream,'head',24,16)
        tuft.rotation_euler.y=side*(.25+i*.045)

# Soft red collar follows the neck, with the original small gold buckle.
collarpts=[(.485*math.cos(t),-.650+.434*math.sin(t),1.745+.055*math.sin(t)) for t in [i*2*math.pi/24 for i in range(24)]]
tube('Red collar',collarpts,.053,red,'neck.01',True)
bc=(0,-1.102,1.685)
corners=[(-.070,-1.116,1.723),(.070,-1.116,1.723),(.070,-1.116,1.651),(-.070,-1.116,1.651)]
tube('Gold rounded buckle',corners,.012,gold,'neck.01',True)
tube('Buckle pin',[(0,-1.130,1.686),(.070,-1.130,1.686)],.008,gold,'neck.01')

# A continuous tapered tail sweep: a genuine 3D curl, with an ivory tip.
tail_path=[(.05,1.10,1.56),(.12,1.33,1.79),(.20,1.43,2.06),(.28,1.41,2.34),(.33,1.22,2.54),(.35,.96,2.58),(.35,.74,2.44),(.34,.69,2.23),(.32,.83,2.10),(.30,1.00,2.14)]
def catmull(a,b,c,d,t):return .5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t)
tp=[Vector(p) for p in tail_path];centers=[]
for i in range(len(tp)-1):
    for j in range(10):centers.append(catmull(tp[max(i-1,0)],tp[i],tp[i+1],tp[min(i+2,len(tp)-1)],j/10))
centers.append(tp[-1]);verts=[];faces=[];segs=24
for i,c in enumerate(centers):
    t=i/(len(centers)-1); tangent=(centers[min(i+1,len(centers)-1)]-centers[max(i-1,0)]).normalized()
    u=Vector((1,0,0));u=(u-u.dot(tangent)*tangent).normalized();v=tangent.cross(u).normalized()
    r=(.18+.061*math.sin(t*math.pi))*(1-.81*max(0,(t-.78)/.22)**1.2)
    for j in range(segs):
        a=2*math.pi*j/segs;co=c+r*(math.cos(a)*u+math.sin(a)*v);verts.append(tuple(co))
for i in range(len(centers)-1):
    for j in range(segs):a=i*segs+j;b=i*segs+(j+1)%segs;faces.append((a,b,b+segs,a+segs))
faces.append(tuple(range(segs-1,-1,-1)));faces.append(tuple((len(centers)-1)*segs+j for j in range(segs)))
me=bpy.data.meshes.new('Curled tail surface');me.from_pydata(verts,[],faces);me.update();tail=bpy.data.objects.new('Tail • continuous curled form',me);main.objects.link(tail);finish(tail,tail.name,brown,'tail');tail.data.materials.append(cream)
for p in tail.data.polygons:
    idx=sum(v//segs for v in p.vertices)/len(p.vertices)/(len(centers)-1)
    if idx>.70+.02*math.sin(p.index*1.3):p.material_index=1
su=tail.modifiers.new('Tail silky silhouette','SUBSURF');su.levels=1

for side in [-1,1]:
    for y in [-.70,1.0]:
        for dx in [-.066,.065]:
            x=side*.425+dx
            tube('Paw toe crease',[(x,y-.25,.185),(x,y-.252,.227),(x,y-.216,.271)],.0045,toe,'fore.'+('L' if side==-1 else 'R')+'.paw' if y<0 else 'hind.'+('L' if side==-1 else 'R')+'.paw')

# Editable 46 bone rig, with real mesh skinning and named groups.
bpy.ops.object.armature_add(enter_editmode=True,location=(0,0,0));rig=bpy.context.object;rig.name='Shiba_Rig';arm=rig.data;arm.name='Shiba anatomy';arm.edit_bones.remove(arm.edit_bones[0])
spec={}
def bone(name,a,b,parent=None):
    eb=arm.edit_bones.new(name);eb.head=a;eb.tail=b
    if parent:eb.parent=arm.edit_bones[parent]
    spec[name]=(Vector(a),Vector(b));return eb
bone('root',(0,0,.06),(0,0,.36));bone('pelvis',(0,.87,1.16),(0,.58,1.32),'root')
bone('spine.01',(0,.58,1.32),(0,.18,1.38),'pelvis');bone('spine.02',(0,.18,1.38),(0,-.22,1.43),'spine.01');bone('chest',(0,-.22,1.43),(0,-.56,1.55),'spine.02')
bone('neck.01',(0,-.56,1.55),(0,-.69,1.83),'chest');bone('neck.02',(0,-.69,1.83),(0,-.8,2.04),'neck.01');bone('head',(0,-.8,2.04),(0,-.93,2.49),'neck.02')
bone('jaw',(0,-1.09,1.95),(0,-1.40,1.94),'head');bone('tongue.01',(0,-1.46,1.97),(0,-1.49,1.90),'jaw');bone('tongue.02',(0,-1.49,1.90),(0,-1.49,1.84),'tongue.01')
for side,label in [(-1,'L'),(1,'R')]:
    par='head'
    for i in range(3):
        n=f'ear.{label}.{i+1:02}';bone(n,(side*(.415+.085*i/3),-.81,2.52+.65*i/3),(side*(.415+.085*(i+1)/3),-.81,2.52+.65*(i+1)/3),par);par=n
    bone('brow.'+label,(side*.26,-1.20,2.40),(side*.27,-1.20,2.49),'head')
    bone('cheek.'+label,(side*.37,-1.14,2.07),(side*.56,-1.16,1.99),'head')
    x=side*.425
    for limb,pts,par in [('fore',[(x,-.46,1.32),(x,-.51,.88),(x,-.57,.48),(x,-.60,.22),(x,-.84,.17)],'chest'),('hind',[(x,.84,1.25),(x,.91,.77),(x,1.09,.48),(x,1.07,.20),(x,.84,.15)],'pelvis')]:
        for i,suffix in enumerate(['upper','lower','ankle','paw']):
            n=f'{limb}.{label}.{suffix}';bone(n,pts[i],pts[i+1],par);par=n
par='pelvis'
for i in range(len(tp)-1):
    n=f'tail.{i+1:02}';bone(n,tp[i],tp[i+1],par);par=n
bpy.ops.object.mode_set(mode='OBJECT');rig.show_in_front=True;rig.data.display_type='OCTAHEDRAL'

def segdist(p,a,b):
    d=b-a;t=max(0,min(1,(p-a).dot(d)/d.length_squared));return (p-a-t*d).length
def skin(o,names,rigid=False):
    groups={n:o.vertex_groups.new(name=n) for n in names}
    for v in o.data.vertices:
        p=o.matrix_world@v.co
        if rigid:groups[names[0]].add([v.index],1,'REPLACE')
        else:
            near=sorted(names,key=lambda n:segdist(p,*spec[n]))[:4]
            weights=[1/(segdist(p,*spec[n])+.055)**4 for n in near];total=sum(weights)
            for n,w in zip(near,weights):groups[n].add([v.index],w/total,'REPLACE')
    mod=o.modifiers.new('Shiba skin','ARMATURE');mod.object=rig
    o.parent=rig
torso=[n for n in spec if n in ['pelvis','spine.01','spine.02','chest','neck.01','neck.02'] or n.startswith(('fore.','hind.'))]
for o in parts:
    if o.type!='MESH':continue
    tag=bindings.get(o.name)
    if o==body:skin(o,torso)
    elif tag=='tail':skin(o,[n for n in spec if n.startswith('tail.')])
    elif tag and tag.startswith('ear.'):skin(o,[n for n in spec if n.startswith(tag+'.')])
    else:skin(o,[tag if tag in spec else 'head'],True)

rig['reference']='User supplied painted brown Shiba model sheet; standing pose, original palette and proportions.'
rig['notes']='46 deformation bones. Rest pose is the authored standing model. Head, muzzle and eyes remain rigid to preserve facial proportions.'

def move_collection(o,c):
    for old in list(o.users_collection):old.objects.unlink(o)
    c.objects.link(o)
floor=material('Studio | warm sand',(.48,.42,.34))
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.015));ground=bpy.context.object;ground.name='Studio ground';ground.data.materials.append(floor);move_collection(ground,studio)
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
def area(name,loc,power,size,color):
    data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='DISK';data.size=size;data.color=color
    o=bpy.data.objects.new(name,data);studio.objects.link(o);o.location=loc;aim(o,(0,0,1.4))
area('Large soft key',(-3.5,-4.5,6),620,4.5,(1,.88,.76));area('Front fill',(4,-3,3.5),400,4,(.80,.89,1));area('Soft rim',(1.5,3.5,5),780,3,(1,.91,.80))
def camera(name,loc,target,scale):
    d=bpy.data.cameras.new(name);d.type='ORTHO';d.ortho_scale=scale;d.lens=60;o=bpy.data.objects.new(name,d);studio.objects.link(o);o.location=loc;aim(o,target);return o
hero=camera('Camera • three quarter',(5,-7,3.5),(0,.1,1.53),4.25)
front=camera('Camera • front',(0,-8,2.7),(0,0,1.53),4.1)
side=camera('Camera • side',(8,0,2.8),(0,0,1.52),4.15)
back=camera('Camera • back',(4,7,3.1),(0,.1,1.53),4.2)
scene=bpy.context.scene;scene.camera=hero;scene.render.engine='CYCLES';scene.cycles.samples=48;scene.cycles.use_denoising=True;scene.cycles.device='CPU'
scene.world.color=(.24,.24,.24);scene.render.resolution_x=1400;scene.render.resolution_y=1400;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX';scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
scene['Model']='Painted Shiba - editable sculpt and armature';scene['Bone count']=len(spec)
bpy.ops.object.select_all(action='DESELECT');head.select_set(True);bpy.context.view_layer.objects.active=head
for screen in bpy.data.screens:
    for a in screen.areas:
        if a.type=='VIEW_3D':
            a.spaces.active.region_3d.view_distance=5.7;a.spaces.active.region_3d.view_location=Vector((0,0,1.5));a.spaces.active.region_3d.view_rotation=hero.rotation_euler.to_quaternion();a.spaces.active.shading.type='MATERIAL'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'shiba_character.blend'))
(OUT/'model-info.json').write_text(json.dumps({'bones':len(spec),'mesh_objects':len(parts),'bone_names':list(spec)},indent=2))
for cam,file in [(hero,'hero'),(front,'front'),(side,'side'),(back,'back')]:
    scene.camera=cam;scene.render.filepath=str(OUT/'renders'/f'{file}.png');bpy.ops.render.render(write_still=True)
scene.camera=hero;bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'shiba_character.blend'))
print('SHIBA COMPLETE',len(spec),'bones')
