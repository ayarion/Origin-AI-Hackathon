# 正面向きハムスター

Built-in image_genでユーザー提供のキャラクター設定画を参照し、新たに透過PNGを生成しました。

Prompt: Generate a single full-body front-facing hamster matching the front view in the reference character sheet: round gray body #9CA3AF, ivory face and belly #F7F7F5, pink ears and nose #F7C8D1, small vertical eyes and clean navy outlines #0B3A8F. Relaxed paws, standing naturally, friendly sleepy expression. Simple high-quality 2D Japanese character illustration. No paper, no hanging pose, no scene, no text, no other characters. Fully transparent background with clean alpha and 8% margins.
