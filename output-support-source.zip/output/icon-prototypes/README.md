# TO:ME icon prototypes

Built-in image generation, using the supplied gray hamster character sheet as an identity reference. These are visual prototypes only; the installed app icon has not been replaced.

- `hamster-ivory.png`: A — front-facing, ivory, flat illustration.
- `hamster-blue.png`: B — three-quarter pose, navy-blue, flat illustration.
- `hamster-soft.png`: C — close-up, soft sculpted finish. Requires final square background/export preparation before use as an app icon.

## Prompt set

A: One square app icon prototype for TO:ME, no text. Character reference: chubby gray hamster, ivory cheeks and belly, small long navy eyes without highlights, pink ears and nose, fine navy contour. Front-facing hamster holding an ivory document in both paws, gently nibbling its upper corner, tiny clear bite notch. Flat Japanese editorial illustration, bold readable silhouette, warm ivory background, restrained navy #0B3A8F and gray #9CA3AF. No outer rounded mask, border, phone mockup, captions. Readable at 60px.

B: Same character identity. Rich solid cobalt-navy background #0B3A8F; three-quarter profile holding a large ivory document diagonally, nibbling its corner, two small paper crumbs. Graphic flat illustration, strong contrast, minimal shapes, no lettering or watermark. Large readable silhouette.

C: Same character identity. Close-up head and small paws holding a folded ivory document, biting the upper edge with a semicircle notch. Soft sculpted clay/frosted ceramic low-relief illustration, diffuse shadows, ivory and pale blue luminous background, navy accents. Calm, friendly, harmonious with liquid glass UI. No photoreal fur or phone mockup.
