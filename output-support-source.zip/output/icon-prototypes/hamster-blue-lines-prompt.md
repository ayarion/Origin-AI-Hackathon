# 採用アイコン

Built-in image_genでhamster-blue.pngを編集。書類に3本線を加え、アプリ用に1024×1024へ変換。

Prompt: Make ONLY one change: add exactly THREE dark navy parallel rounded text-like lines to the blank cream paper the hamster is biting. Lines aligned to the tilted paper top and centered within paper, with generous margins; bottom line a little shorter. Preserve hamster, pose, facial features, thick navy outlines, paper bite, colors, background, framing and composition unchanged. No actual letters, no extra details. Square full-bleed opaque app icon, no rounded outer corners.
