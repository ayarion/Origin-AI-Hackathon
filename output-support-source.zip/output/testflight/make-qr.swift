import AppKit
import CoreImage.CIFilterBuiltins

let url = "https://testflight.apple.com/join/DkWgxXCc"
let filter = CIFilter.qrCodeGenerator()
filter.message = Data(url.utf8)
filter.correctionLevel = "H"
guard let image = filter.outputImage?.transformed(by: CGAffineTransform(scaleX: 16, y: 16)) else { fatalError("QRフィルタが画像を返しませんでした") }
guard let qr = CIContext().createCGImage(image, from: image.extent),
      let context = CGContext(data: nil, width: qr.width + 128, height: qr.height + 128,
                              bitsPerComponent: 8, bytesPerRow: 0,
                              space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
    fatalError("QR画像を作成できませんでした")
}
context.setFillColor(NSColor.white.cgColor)
context.fill(CGRect(x: 0, y: 0, width: qr.width + 128, height: qr.height + 128))
context.interpolationQuality = .none
context.draw(qr, in: CGRect(x: 64, y: 64, width: qr.width, height: qr.height))
guard let bordered = context.makeImage(),
      let data = NSBitmapImageRep(cgImage: bordered).representation(using: .png, properties: [:]) else {
    fatalError("PNGを作成できませんでした")
}
try data.write(to: URL(fileURLWithPath: "/Users/ookurayouko/Documents/ChatGPT/origin/output/testflight/TO-ME-TestFlight-QR.png"))
